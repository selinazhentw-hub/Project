import extra, mainmenu


def markToGpa(mark):
    if mark >= 90:
        return 4.0
    elif mark >= 85:
        return 3.7
    elif mark >= 80:
        return 3.3
    elif mark >= 75:
        return 3.0
    elif mark >= 70:
        return 2.7
    elif mark >= 65:
        return 2.3
    elif mark >= 60:
        return 2.0
    elif mark >= 55:
        return 1.7
    elif mark >= 50:
        return 1.3
    else:
        return 0.0


def getValidInput(prompt, minVal, maxVal, inputType=float):
    while True:
        try:
            value = inputType(input(prompt))
            if minVal <= value <= maxVal:
                return value
            print(f"Value must be between {minVal} and {maxVal}")
        except ValueError:
            print("Invalid input. Please enter a valid number.")


def calculateSemesterGpa():
    totalQualityPoints = 0
    totalCredits = 0

    numSubjects = int(getValidInput("Enter number of subjects: ", 1, 20, int))

    for i in range(numSubjects):
        print(f"\nSubject {i + 1}:")
        mark = getValidInput("Enter exam marks (0-100): ", 0, 100)

        gpa = markToGpa(mark)
        totalQualityPoints += gpa * 4
        totalCredits += 4

    return totalQualityPoints, totalCredits


def main():
    cumulativeQuality = 0
    cumulativeCredits = 0

    while True:
        print("\n=== New Semester ===")
        semQuality, semCredits = calculateSemesterGpa()

        # Calculate semester GPA
        sem_gpa = semQuality / semCredits
        print(f"\nSemester GPA: {sem_gpa:.2f}")

        # Update cumulative totals
        cumulativeQuality += semQuality
        cumulativeCredits += semCredits

        # Calculate CGPA
        cgpa = cumulativeQuality / cumulativeCredits
        print(f"Current CGPA: {cgpa:.2f}")


def displayRecords(path):
    success, errorMessage, dictionary = extra.loadDatabase(path, False)
    if not success:
        print(f'\33[31m{errorMessage}\33[0m')
        teacher()
        return
    else:
        for i in dictionary:
            count = 0
            for j in dictionary[i]:
                count += 1

                words = j.split("_")
                for letter in range(0, len(words)):
                    words[letter] = words[letter].capitalize()
                new_attribute = " ".join(words)
                new_attribute = new_attribute.strip("@")
                if type(dictionary[i][j]) is list:
                    displayList(new_attribute, dictionary[i][j])
                elif type(dictionary[i][j]) is dict:
                    print(f"| {new_attribute}: {dictionary[i][j][list(dictionary[i][j].keys())[0]]}", end=' ')
                else:
                    print(f"| {new_attribute}: {dictionary[i][j]}", end=' ')
                if count == len(dictionary[i]):
                    print("|")


def findRecord(path, key):
    success = True
    dictionary = {}

    try:
        open(path, "r")
    except FileNotFoundError as e:
        success = False
        return success, e, None
    else:
        with open(path, "r", encoding='utf-8-sig') as database:
            header = database.readline().strip().split(",")
            count = 0
            lines = database.readlines()
            extra.readRecord(dictionary, header, lines, True)

    return success, None, dictionary[key]


def displayList(attribute, givenList):
    print(f"| {attribute}: ", end=" ")
    for i in range(0, len(givenList)):
        if i == len(givenList) - 1:
            print(f"{givenList[i]}", end="")
        else:
            print(f"{givenList[i]}", end=", ")


def course_creation_management(teacher_id):
    print("\n--- Course Creation and Management ---")
    print("1 - Course Creation")
    print("2 - Course Management")
    print("3 - Class Creation")
    print("4 - Class Management")
    print("5 - Exit")

    action = input("Enter a number between the option to lead to the part you needed: ").strip()
    if action == "1":
        success, error, database = extra.loadDatabase("coursedb.csv", False)
        if success:
            print(database)
        else:
            print(f"Error: {error}")
        course_id = input("Enter course id: ").strip()
        course_name = input("Enter course name: ").strip()
        database[course_id] = {
            "course_id": course_id,
            "course_name": course_name,
            "class_name": [],
            "scheduledb.csv": [],
            "assignments": []
        }

        ignoreList = ["course_id", "course_name"]
        success = extra.modifyRecord(database, course_id, ignoreList)
        if not success:
            course_creation_management(teacher_id)
            return

        success, error = extra.saveData(database, "coursedb.csv")
        if success:
            print("Data saved successfully.")
        else:
            print(f"Error: {error}")

    elif action == "2":

        course_id_update = input("Enter Course id to update: ").strip()
        course_name = input("Enter Course name to update: ").strip()

        success, error, database = extra.loadDatabase("coursedb.csv", False)
        if success:
            print("Data loaded successfully.")
        else:
            print(f"Error: {error}")

        if course_id_update in database:
            database[course_id_update]["course_name"] = course_name
            print("Course updated successfully")
        else:
            print(f"Course '{course_id_update}' not found.")

        success, error = extra.saveData(database, "coursedb.csv")
        if success:
            print("Data saved successfully.")
        else:
            print(f"Error: {error}")

    elif action == "3":
        success, error, database = extra.loadDatabase("classdb.csv", False)
        if success:
            print(database)
        else:
            print(f"Error: {error}")
        class_id = input("Enter class ID: ").strip()

        success, error, record = findRecord("classdb.csv", class_id)
        if not success:
            print(error)
            course_creation_management(teacher_id)
            return

        success = extra.modifyRecord(database, class_id, None)
        if not success:
            print(error)
            course_creation_management(teacher_id)
            return

        success, error = extra.saveData(database, "classdb.csv")
        if success:
            print("Data saved successfully.")
        else:
            print(f"Error: {error}")

    elif action == "4":
        class_ID_update = input("Enter Class ID to update: ").strip()

        success, error, database = extra.loadDatabase("classdb.csv", False)
        if not success:
            print(error)
            course_creation_management(teacher_id)
            return

        try:
            database[class_ID_update]
        except KeyError as e:
            print(f"Class '{class_ID_update}' not found.")
            course_creation_management(teacher_id)
            return

        success = extra.modifyRecord(database, class_ID_update, None)
        if not success:
            course_creation_management(teacher_id)
            return

        success, error = extra.saveData(database, "classdb.csv")
        if success:
            print("Data saved successfully.")
        else:
            print(f"Error: {error}")

    elif action == "5":
        teacher(teacher_id)
        return
    else:
        print("This dosen't belong to any single code in our system")
        teacher(teacher_id)
        return

    course_creation_management(teacher_id)


def student_enrolment(teacher_id):
    print("\n--- Student Enrolment ---")
    print("1 - Enroll Student")
    print("2 - Remove Student")
    print("3 - Exit")

    action = input("Enter a number between the option to lead to the part you needed: ").strip()
    if action == "1":
        studentdatabase = displayRecords("studentdb.csv")
        student_id = input("Enter student id: ")
        success, errorMessage, record = findRecord("studentdb.csv", student_id)
        if not success:
            print(f"Error: {errorMessage}")
        else:
            print("Record found: ", record)

        success, error, teacherdatabase = extra.loadDatabase("teacherdb.csv", False)
        success, errorMessage, record = findRecord("teacherdb.csv", teacher_id)

        if student_id in studentdatabase:
            studentdatabase[student_id]["coursedb.csv"]["course_id"] = teacherdatabase[teacher_id]["coursedb.csv"][
                "course_id"]
            success, error = extra.saveData(studentdatabase, "studentdb.csv")
            if not success:
                print(error)


    elif action == "2":
        success, error, studentdatabase = extra.loadDatabase("studentdb.csv", False)
        success, error, teacherdatabase = extra.loadDatabase("teacherdb.csv", False)

        student_id = input("Enter student ID: ").strip()

        if studentdatabase[student_id] != None:
            if studentdatabase[student_id]["coursedb.csv"]["course_id"] == teacherdatabase[teacher_id]["coursedb.csv"][
                "course_id"]:
                del database[student_id]
                print("Student removed successfully.")
            else:
                print(f"Student '{studentdatabase[student_id]["student_name"]}' does not belong to your course.")
        else:
            print(
                f"Student '{studentdatabase[student_id]["student_name"]}' not found in course '{teacherdatabase[teacher_id]["coursedb.csv"]["course_name"]}")

        success, error = extra.saveData(studentdatabase, "studentdb.csv")
        if success:
            print("Data saved successfully.")
        else:
            print(f"Error: {error}")

    elif action == "3":
        teacher(teacher_id)
        return
    else:
        print("This dosen't belong to any single code in our system")
        teacher(teacher_id)
        return

    student_enrolment(teacher_id)


def grading_assessment(teacher_id):
    # Grading and Assessment function for handling assignments and exams
    print("\n--- Grading and Assessment ---")
    print("1 - Subject grading")
    print("2 - Type in student semester gpa")
    print("3 - Exit")

    action = input("Enter a number to choose the part you need: ").strip()

    success, error, database = extra.loadDatabase("gradingdb.csv", False)

    if action == "1":
        gradingID = input("Enter grading ID: ").strip()
        studentID = input("Enter student ID: ").strip()
        StudentName = input("Enter student name: ").strip()
        classID = input("Enter class ID: ").strip()
        className = input("Enter class name: ").strip()

        subject_marks = getValidInput("Enter subject marks (0-100): ", 0, 100)

        subject_gpa = markToGpa(subject_marks)

        feedback = input("Enter feedback: ").strip()

        database[gradingID] = {
            "studentdb.csv": {"student_id": studentID,
                              "student_name": StudentName},
            "classdb.csv": {"class_id": classID,
                            "class_name": className},
            "subject_marks": subject_marks,
            "subject_gpa@": subject_gpa,
            "feedback": feedback
        }

        success, error = extra.saveData(database, "gradingdb.csv")
        if success:
            print("Assignment grading data saved successfully.")
        else:
            print(f"Error: {error}")
    elif action == "2":
        student_id = input("Enter student id: ")
        success, errorMessage, record = findRecord("studentdb.csv", student_id)
        if not success:
            print(f"Error: {errorMessage}")
            grading_assessment(teacher_id)
            return

        success, error, studentdatabase = extra.loadDatabase("studentdb.csv", False)
        print("Record found: ", record)

        ignoreList = ["student_id", "student_name", "@student_contact", "coursedb.csv", "enrolment_status",
                      "academic_performance", "emergency_contact_name", "@emergency_contact", "relationship_to_student",
                      "fees_outstanding", "fees_paid", "next_payment_date", "userdb.csv"]
        success = extra.modifyRecord(studentdatabase, student_id, ignoreList)
        if not success:
            print(f"Error: {error}")
            grading_assessment(teacher_id)
            return

        success, error = extra.saveData(database, "gradingdb.csv")
        if success:
            print("Student gpa recorded.")
        else:
            print(f"Error: {error}")

    elif action == "3":
        teacher(teacher_id)
        return

    else:
        print("This doesn't belong to any single code in our system")
        return

    grading_assessment(teacher_id)


def attendance_tracking(teacher_id):
    print("\n--- Attendance Tracking ---")
    print("1 - Record")
    print("2 - Enter Event")
    print("3 - Exit")

    action = input("Enter a number between the option to lead to the part you needed: ").strip()

    if action == "1":
        success, error, database = extra.loadDatabase("attendance_trackingdb.csv", False)
        if not success:
            print(error)
            attendance_tracking(teacher_id)
            return

        attendance_id = input("Enter attendance ID: ").strip()
        student_id = input("Enter student ID: ").strip()
        class_id = input("Enter class ID: ").strip()
        date = input("Enter date: ").strip()
        status = input("Enter status(Present/Absent): ").strip()

        database[attendance_id] = {
            "studentdb.csv": {"student_id": student_id},
            "classdb.csv": {"class_id": class_id},
            "eventsdb.csv": "N/A",
            "date": date,
            "status": status
        }

        success, error = extra.saveData(database, "attendance_trackingdb.csv")
        if success:
            print("Attendance tracking successfully.")
        else:
            print(f"Error: {error}")

    elif action == "2":
        success, error, database = extra.loadDatabase("attendance_trackingdb.csv", False)
        if not success:
            print(error)
            attendance_tracking(teacher_id)
            return

        attendance_id = input("Enter attendance ID: ").strip()
        student_id = input("Enter student ID: ").strip()
        event_id = input("Enter event ID: ").strip()
        date = input("Enter date: ").strip()
        status = input("Enter status(Present/Absent): ").strip()

        database[attendance_id] = {
            "studentdb.csv": {"student_id": student_id},
            "classdb.csv": "N/A",
            "eventsdb.csv": {"EventID": event_id},
            "date": date,
            "status": status
        }

        success, error = extra.saveData(database, "attendance_trackingdb.csv")
        if success:
            print("Data saved successfully.")
        else:
            print(f"Error: {error}")

    elif action == "3":
        teacher(teacher_id)
        return
    else:
        print("This dosen't belong to any single code in our system")
        teacher(teacher_id)
        return

    attendance_tracking(teacher_id)


def report_generation(teacher_id):
    print("\n--- Report Generation ---")
    print("1 - Performance ")
    print("2 - Participation")
    print("3 - Exit")

    action = input("Enter a number between the option to lead to the part you needed: ").strip()

    if action == "1":
        success, error, database = extra.loadDatabase("studentdb.csv", False)

        for i in database:
            print(
                f"| {i} | Student Name: {database[i]["student_name"]} | Academic Performance: {database[i]["academic_performance"]} |")

    elif action == "2":
        displayRecords("attendance_trackingdb.csv")

    elif action == "3":
        teacher(teacher_id)
        return
    else:
        print("This dosen't belong to any single code in our system")
        teacher(teacher_id)
        return

    report_generation(teacher_id)


def logout():
    print("Thank you for using our systems! ")
    mainmenu.homepage()


def teacher(teacher_id):
    print("\n--- Main Menu ---")
    print("1 - Course Creation and Management")
    print("2 - Student Enrolment")
    print("3 - Grading and Assessment")
    print("4 - Attendance Tracking")
    print("5 - Report generation ")
    print("6 - Logout")

    action = input("Enter a number between the option to lead to the part you needed: ")

    if action == "1":
        course_creation_management(teacher_id)
        teacher(teacher_id)
        return
    if action == "2":
        student_enrolment(teacher_id)
        teacher(teacher_id)
        return
    if action == "3":
        grading_assessment(teacher_id)
        teacher(teacher_id)
        return
    if action == "4":
        attendance_tracking(teacher_id)
        teacher(teacher_id)
        return
    if action == "5":
        report_generation(teacher_id)
        teacher(teacher_id)
        return

    if action == "6":
        logout()
        return

    else:
        print("This dosen't belong to any single code in our system")
        teacher(teacher_id)