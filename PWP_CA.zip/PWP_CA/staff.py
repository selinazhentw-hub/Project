import extra, mainmenu

def staff():
    print("==============================================================================")
    print("1 - Student Records")
    print("2 - Timetables")
    print("3 - Resource Allocation")
    print("4 - Events")
    print("5 - Communication")
    print("6 - Logout")
    print("==============================================================================")
    print("")
    print("")

    print("==================================")
    action = input("Please select an option: ")

    if action == "1":
        SR() #Student Records
        return
    elif action == "2":
        TT() #TimeTables
        return
    elif action == "3":
        RA() #Resource Allocation
        return
    elif action == "4":
        EV() #Events
        return
    elif action == "5":
        CM() #Communication
        return
    elif action == "6":
        mainmenu.homepage()
    else:
        print("Wrong input, please try again")
        staff()
        return



def SR():
    print("==============================================================================")
    print("Student Records selected")
    print("1 - Add Student")
    print("2 - Edit Student Record")
    print("3 - Remove Student Record")
    print("4 - View a Student Record")
    print("5 - Back")
    print("==============================================================================")
    print("")
    print("")

    print("==================================")
    action1 = input("Please select an option: ")
    if action1 == "1":

        def addStudentRecord():

            success, error, studentDB = extra.loadDatabase("studentdb.csv", False)
            print("==================================")
            print(f"Add new student record")

            success, error = extra.modifyRecord(studentDB, "unknown",None)
            print("==============================================================================")
            StudentID = input("Enter Student ID or Exit to go back: ").strip()
            if StudentID == "Exit":
                SR()
                return
            else:
                student_name = input("Enter Student name: ").strip()
                student_contact = input("Enter Student contact: ").strip()
                coursedb = input("Enter Student course: ").strip()
                enrolment_status = input("Enter Student enrolment status(Success/Pending/Fail): ").strip()
                academic_performance = input("Enter Student Academic Performance: ").strip()
                #
                emergency_contact_name = input("Enter Student emergency contact name: ").strip()
                emergency_contact = input("Enter Student emergency contact: ").strip()
                relationship_to_student = input("Enter Student emergency contact relationship to student: ").strip()
                fees_outstanding = input("Enter Outstanding Fees: ").strip()
                fees_paid = input("Paid Fees: ").strip()
                next_payment_date = input("Next Payment Date: ").strip()
                username = input("Create login username(Eg-Jack123): ").strip()
                password = input("Create login password(Eg-Pass123): ").strip()
                student_sem_gpa = "N/A"
                print("==============================================================================")
                studentDB[StudentID] = {"StudentName": student_name,
                                        "StudentContact":  student_contact,
                                        "Course": coursedb,
                                        "EnrolmentStatus": enrolment_status,
                                        "AcademicPerformance": academic_performance,
                                        "EmergencyContactName": emergency_contact_name,
                                        "EmergencyContact": emergency_contact,
                                        "RelationshipToStudent": relationship_to_student,
                                        "OutstandingFees": fees_outstanding,
                                        "PaidFees":  fees_paid,
                                        "NextPaymentDate": next_payment_date,
                                        "userdb": username,
                                        "StudentSemGPA": student_sem_gpa}

                print(f"Student {student_name} registered successfully!")

                saveSuccess, error = extra.saveData(studentDB, "studentdb.csv")

                if saveSuccess:
                    print("Changes saved successfully.")
                else:
                    print(f"Error saving data: {error}")

                success, error, userDB = extra.loadDatabase("userdb.csv", False)

                userDB[username] = {"password": password}

                saveSuccess, error = extra.saveData(userDB, "userdb.csv")  #Save userDB
                if saveSuccess:
                    print("User credentials saved successfully.")
                else:
                    print(f"Error saving user credentials: {error}")

                SR()

        addStudentRecord()
        return

    elif action1 == "2":
        print("==================================")
        print("Edit Student Record")
        print("==================================")
        def editStudentRecord(path, student):

            success, error, dictionary = extra.loadDatabase(path, False)

            if student not in dictionary:
                print("==============================================================================")
                print(f"{student} not found.")
                print("==============================================================================")
                SR()
                return

            current_row = dictionary[student]

            attribute_names = {"student_id": "Student ID","student_name": "Student Name","@student_contact": "Student Contact","coursedb": "Course ID","enrolment_status": "Enrolment Status","academic_performance": "Academic Performance",
                               "emergency_contact_name": "Emergency Contact Name","@emergency_contact": "Emergency Contact","relationship_to_student": "Relationship To Student","fees_outstanding": "Fees Outstanding","fees_paid": "Fees Paid","next_payment_date": "Next Payment Date","userdb": "Username","student_sem_gpa": "Student Semester GPA"}
            print("==================================")
            print("Available attributes to edit:")
            for key, value in current_row.items():
                if key == "coursedb.csv" and isinstance(value, dict) and "CourseID" in value:
                    readable_key = attribute_names.get("CourseID", "Course ID")
                    print(f"{readable_key}: {value['CourseID']}")
                elif isinstance(value, dict):
                    continue
                else:
                    readable_key = attribute_names.get(key, key)
                    print(f"{readable_key}: {value}")
            print("==================================")
            attributes_to_edit = input("Enter attributes to edit(Eg: Student Name) or enter Exit to go back: ").strip()
            print("==================================")

            if attributes_to_edit == "Exit":
                SR()
                return

            attributes_to_edit = attributes_to_edit.split(",")

            for key in attributes_to_edit:
                key = key.strip()
                original_key = next((dbkey for dbkey, newkey in attribute_names.items() if newkey == key), key)
                if original_key in current_row and not isinstance(current_row[original_key], dict):
                    old_value = current_row[original_key]
                    new_input = input(f"Enter new value for {key} (Current: {old_value}): ")
                    current_row[original_key] = new_input
                else:
                    print(f"{key} is not a valid attribute.")

            saveSuccess, error = extra.saveData(dictionary, path)
            if saveSuccess:
                print("==================================")
                print("Record updated successfully!")
                print("==================================")
                editStudentRecord("studentdb.csv", student)
            else:
                print(f"Error saving data: {error}")

        student = input("Enter Student ID to edit or enter Exit to go back: ").strip()
        print("==============================================================================")
        if student == "Exit":
            SR()
            return
        else:
            editStudentRecord("studentdb.csv", student)
        SR()
        return

    elif action1 == "3":
        print("==================================")
        print("Student withdrawal process management")
        print("==================================")

        def deleteRecord(path, record_id):
            success, error, dictionary = extra.loadDatabase("studentdb.csv", False)

            if record_id in dictionary:
                del dictionary[record_id]
                print(f"Record {record_id} has been deleted successfully.")

            saveSuccess, error = extra.saveData(dictionary, "studentdb.csv")
            if saveSuccess:
                print("Database updated successfully.")
            else:
                print(f"Error saving data: {error}")

        record_id = input("Enter Student ID to delete or Exit to go back: ").strip()
        if record_id == "Exit":
            SR()
            return
        else:
            deleteRecord("studentdb.csv", record_id)
            SR()
            return

    elif action1 == "4":
        print("==================================")
        def viewSingleRecord(student_id):
            with open("studentdb.csv", "r") as events:
                lines = events.readlines()[1:]

            for sentence in lines:
                data = sentence.strip().split(',')
                if data[0] == student_id:
                    student_id,student_name,student_contact,coursedb,enrolment_status,academic_performance,emergency_contact_name,emergency_contact,relationship_to_student,fees_outstanding,fees_paid,next_payment_date,userdb,student_sem_gpa = data
                    print(f"Student ID: {student_id}, Student Name: {student_name}, Student Contact: {student_contact}, Course: {coursedb}, Enrolment Status: {enrolment_status}, Academic Performance: {academic_performance}, Emergency Contact Name: {emergency_contact_name}")
                    print(f"Emergency Contact: {emergency_contact}, Relationship To Student: {relationship_to_student}, Outstanding Fees: {fees_outstanding}, Fees Paid: {fees_paid}, Next Payment Date: {next_payment_date}, Student Semester GPA: {student_sem_gpa}")
                    return

            print(f"No Student with Student ID: {student_id}")

        student_id = input("Enter Student ID to view or Exit to go back: ").strip()
        if student_id == "Exit":
            SR()
            return
        else:
            viewSingleRecord(student_id)
            SR()

    elif action1 == "5":
        staff()
        return
    else:
        print("Wrong input, please try again")
        SR()
        return

def TT():
    print("==============================================================================")
    print("Timetable Management")
    print("1 - Add class")
    print("2 - Edit class")
    print("3 - Remove class")
    print("4 - View all classes")
    print("5 - View all classrooms")
    print("6 - View all Lecturers")
    print("7 - Back")
    print("==============================================================================")

    action2 = input("Please select an option: ")
    print("==================================")
    if action2 == "1":
        def addClass():

            success, error, classDB = extra.loadDatabase("classdb.csv", False)

            print(f"Add class to record")
            print("==================================")
            success, error = extra.modifyRecord(classDB, "unknown", None)
            ClassID = input("Enter Class ID or Exit to go back: ").strip()
            if ClassID == "Exit":
                TT()
                return
            else:
                class_name = input("Enter Class Name: ").strip()
                classroomdb = input("Enter Venue ID: ").strip()
                teacherdb = input("Enter Lecturer ID: ").strip()
                date = input("Enter Date: ").strip()
                start_time = input("Enter Start Time: ").strip()
                duration = input("Enter Duration: ").strip()

                classDB[ClassID] = {"class_name": class_name,
                                        "classroomdb": classroomdb,
                                        "teacherdb": teacherdb,
                                        "date": date,
                                        "start_time": start_time,
                                        "duration": duration}

                print("==================================")
                print(f"Class {class_name} registered successfully!")
                print("==================================")

                saveSuccess, error = extra.saveData(classDB, "classdb.csv")

                if saveSuccess:
                    print("Changes saved successfully.")
                    TT()
                    return
                else:
                    print(f"Error saving data: {error}")

        addClass()
        return

    elif action2 == "2":
        def editClass(path, classes):

            success, error, dictionary = extra.loadDatabase(path, False)

            if classes not in dictionary:
                print(f"{classes} not found.")
                TT()
                return

            current_row = dictionary[classes]

            attribute_names = {"class_id": "Class ID", "class_name": "Class Name", "classroomdb": "Venue ID",
               "teacherdb": "Lecturer ID", "date": "Date", "start_time": "Start Time",
               "duration@": "Duration"}

            print("==============================================================================")
            print("Available classes to edit:")
            for key, value in current_row.items():
                if key == "teacherdb.csv" and isinstance(value, dict) and "teacher_id" in value:
                    readable_key = attribute_names.get("teacherdb", "Lecturer ID")
                    print(f"{readable_key}: {value['teacher_id']}")
                elif key == "classroomdb.csv" and isinstance(value, dict) and "venue_id" in value:
                    readable_key = attribute_names.get("classroomdb", "Venue ID")
                    print(f"{readable_key}: {value['venue_id']}")
                elif isinstance(value, dict):
                    continue  # Skip other nested dictionaries
                else:
                    readable_key = attribute_names.get(key, key)  # Use mapped name if available
                    print(f"{readable_key}: {value}")

            print("==============================================================================")
            attributes_to_edit = input("Enter attributes to edit(Eg: Class Name) or enter Exit to go back: ").strip()

            if attributes_to_edit == "Exit":
                TT()
                return

            attributes_to_edit = attributes_to_edit.split(",")

            for key in attributes_to_edit:
                key = key.strip()

                original_key = next((dbkey for dbkey, newkey in attribute_names.items() if newkey == key), key)

                if original_key in current_row and not isinstance(current_row[original_key], dict):
                    old_value = current_row[original_key]
                    new_input = input(f"Enter new value for {key} (Current: {old_value}): ")
                    current_row[original_key] = new_input
                else:
                    print(f"{key} is not a valid attribute.")

            saveSuccess, error = extra.saveData(dictionary, path)
            if saveSuccess:
                print("Record updated successfully!")
                editClass("classdb.csv", classes)
            else:
                print(f"Error saving data: {error}")

        classid = input("Enter Class ID to edit or enter Exit to go back: ").strip()
        if classid == "Exit":
            TT()
            return
        else:
            editClass("classdb.csv", classid)

        return

    elif action2 == "3":
        def deleteRecord(path, record_id):
            success, error, dictionary = extra.loadDatabase("classdb.csv", False)

            if record_id in dictionary:
                del dictionary[record_id]
                print(f"Record {record_id} has been deleted successfully.")

            saveSuccess, error = extra.saveData(dictionary, "classdb.csv")
            if saveSuccess:
                print("Database updated successfully.")
            else:
                print(f"Error saving data: {error}")

        record_id = input("Enter Class ID to delete or Exit to go back: ").strip()
        if record_id == "Exit":
            TT()
            return
        else:
            deleteRecord("classdb.csv", record_id)
            TT()
            return

    elif action2 == "4":

        with open("classdb.csv", "r") as classes:
            line = classes.readlines()[1:]

        for sentence in line:
            class_id,class_name,classroomdb,teacherdb,date,start_time,duration = sentence.strip().split(',')
            print(f"Class ID: { class_id}, Class Name: {class_name}, Venue ID: {classroomdb}, Lecturer ID: {teacherdb}, Date: {date}, Start Time: {start_time} Duration: {duration}")
        TT()

    elif action2 == "5":

        with open("classroomdb.csv", "r") as classroom:
            line = classroom.readlines()[1:]

        for sentence in line:
            venue_id, capacity = sentence.strip().split(',')
            print(
                f"Venue ID: {venue_id}, Capacity: {capacity}")
        TT()

    elif action2 == "6":
        with open("teacherdb.csv", "r") as teacher:
            line = teacher.readlines()[1:]

        for sentence in line:
            teacher_id,teacher_name,age,contact_number,userdb,coursedb,classdb = sentence.strip().split(',')
            print(
                f"Lecturer ID: {teacher_id}, Lecturer Name: {teacher_name}, Age: {age}, Contact Number: {contact_number}, Course ID: {coursedb}, Class ID: {classdb}")
        TT()

    elif action2 == "7":
        staff()
        return

    else:
        print("Wrong input, please try again")
        SR()
        return

def RA():
    print("==============================================================================")
    print("1 - View all Resources")
    print("2 - Allocate Resources")
    print("3 - Release Resources")
    print("4 - View all Classrooms")
    print("5 - Back")
    print("==============================================================================")

    action3 = input("Please Select an option: ")
    print("==================================")
    if action3 ==  "1":

        success, error, resources = extra.loadDatabase("resourcesdb.csv", False)

        print("Available Resources:")
        for res_id, res in resources.items():
            if res["status"] == "Available":  # Checking by key instead of index
                print(f"{res_id} - {res['resource_name']} ({res['category']})")

        print("Allocated Resources:")
        for res_id, res in resources.items():
            if res["status"] == "Allocated":  # Checking by key instead of index
                print(f"{res_id} - {res['resource_name']} ({res['category']}) - Assigned to: {res['assigned_to']}")
        RA()
        return

    elif action3 == "2":
        success, error, resources = extra.loadDatabase("resourcesdb.csv", False)

        resource_id = input("Enter Resource ID to allocate: ").strip()
        venue_id = input("Enter Venue ID : ").strip()

        if resource_id in resources and resources[resource_id]["status"] == "Available":
            resources[resource_id]["status"] = "Allocated"
            resources[resource_id]["assigned_to"] = venue_id  # Assigning the venue

            success, error = extra.saveData(resources, "resourcesdb.csv")
            if success:
                print(f"Resource {resources[resource_id]['resource_name']} ({resources[resource_id]['category']}) allocated to {venue_id}.")
                RA()

            else:
                print(f"Error saving data: {error}")
        else:
            print("Error: Resource not found or already allocated.")

    elif action3 == "3":

        success, error, resources = extra.loadDatabase("resourcesdb.csv", False)

        resource_id = input("Enter Resource ID to release: ").strip()

        if resource_id in resources and resources[resource_id]["status"] == "Allocated":
            resources[resource_id]["status"] = "Available"
            resources[resource_id]["assigned_to"] = "None"

            success, error = extra.saveData(resources, "resourcesdb.csv")
            print(f"Resource {resources[resource_id]['resource_name']} ({resources[resource_id]['category']}) is now available.")
            RA()
            return

        else:
            print("Error: Resource not found or already available.")
            RA()
            return

    elif action3 == "4":

        with open("classroomdb.csv", "r") as classroom:
            line = classroom.readlines()[1:]

        for sentence in line:
            venue_id, capacity = sentence.strip().split(',')
            print(f"Venue ID: {venue_id}, Capacity: {capacity}")
        RA()

    elif action3 == "5":
        staff()
        return

    else:
        print("Wrong input, please try again")
        RA()
        return



def EV():
    print("==============================================================================")
    print("Events selected")
    print("1 - Show all events")
    print("2 - Add an event")
    print("3 - Edit an event")
    print("4 - Remove an event")
    print("5 - Back")
    print("==============================================================================")

    action4 = input("Please choose an option: ")
    print("==================================")

    if action4 == "1":

        with open("eventsdb.csv", "r") as events:
            line = events.readlines()[1:]

        for sentence in line:
            event_id,event_name,event_type,date,start_time,end_time = sentence.strip().split(',')
            print(
                f"Event ID: {event_id}, Event Name: {event_name}, Event Type: {event_type}, Date: {date}, Start Time: {start_time}, End Time: {end_time}")

        EV()

    elif action4 == "2":

        def addEvent():

            success, error, eventsDB = extra.loadDatabase("eventsdb.csv", False)

            if not success:
                print(f"Error loading database: {error}")
                return

            print(f"Add to record")
            success, error = extra.modifyRecord(eventsDB, "unknown", None)
            EventID = input("Enter Event ID or Exit to go back: ").strip()
            if EventID == "Exit":
                TT()
                return
            else:
                EventName = input("Enter Event name: ").strip()
                EventType = input("Enter Event Type(Seminar/Conference/Extracurricular/Academic): ").strip()
                Date = input("Enter Date: ").strip()
                StartTime = input("Enter Start Time: ").strip()
                EndTime = input("Enter End Time: ").strip()

                eventsDB[EventID] = {"EventName": EventName,
                                     "EventType": EventType,
                                     "Date": Date,
                                     "StartTime": StartTime,
                                     "EndTime": EndTime}

                print(f"{EventName} added successfully!")

                saveSuccess, error = extra.saveData(eventsDB, "eventsdb.csv")

                if saveSuccess:
                    print("Changes saved successfully.")
                    EV()
                else:
                    print(f"Error saving data: {error}")

        addEvent()

    elif action4 == "3":
        def editEvent(path, event):

            success, error, dictionary = extra.loadDatabase(path, False)

            if event not in dictionary:
                print(f"{event} not found.")
                EV()
                return

            current_row = dictionary[event]

            attribute_names = {"event_id": "Event ID","event_name": "Event Name","event_type": "Event Type","date": "Date","start_time": "Start Time","end_time": "End Time"}

            print("==============================================================================")
            print("Available attributes to edit:")
            for key, value in current_row.items():
                readable_key = attribute_names.get(key, key)
                print(f"{readable_key}: {value}")

            attributes_to_edit = input("Enter attributes to edit(Eg: Event Type) or enter Exit to go back: ").strip()

            if attributes_to_edit == "Exit":
                EV()
                return

            attributes_to_edit = attributes_to_edit.split(",")

            for key in attributes_to_edit:
                key = key.strip()
                original_key = next((dbkey for dbkey, newkey in attribute_names.items() if newkey == key), key)
                if original_key in current_row:
                    old_value = current_row[original_key]
                    new_input = input(f"Enter new value for {key} (Current: {old_value}): ")
                    current_row[original_key] = new_input
                else:
                    print(f"{key} is not a valid attribute.")

            saveSuccess, error = extra.saveData(dictionary, path)
            if saveSuccess:
                print("Record updated successfully!")
                editEvent("eventsdb.csv", event)
            else:
                print(f"Error saving data: {error}")

        event = input("Enter Event ID to edit or enter Exit to go back: ").strip()
        if event == "Exit":
            EV()
            return
        else:
            editEvent("eventsdb.csv", event)

        return

    elif action4 == "4":
        def deleteEvent(path, event):
            success, error, dictionary = extra.loadDatabase("eventsdb.csv", False)

            if event in dictionary:
                del dictionary[event]
                print(f"{event} has been deleted successfully.")

            else:
                print(f"{event} not found.")
                EV()
                return

            saveSuccess, error = extra.saveData(dictionary, "eventsdb.csv")
            if saveSuccess:
                print("Database updated successfully.")
                EV()
            else:
                print(f"Error saving data: {error}")

        event = input("Enter Event to delete or Exit to go back: ").strip()
        if event == "Exit":
            EV()
            return
        else:
            deleteEvent("studentdb.csv", event)
            return


    elif action4 == "5":
        staff()
        return
    else:
        print("Wrong input, please try again")
        EV()

def CM():
    print("==============================================================================")
    print("Communications selection")
    print("1 - Students")
    print("2 - Parents")
    print("3 - Faculty")
    print("4 - Back")
    print("==============================================================================")

    action5 = input("Please select an option: ")
    print("==================================")

    if action5 == "1":
        print("Students selected")
        print("1 - View all Students contacts")
        print("2 - View single Student's contact")
        print("3 - Back")
        action51 = input("Please select an option: ")
        if action51 == "1":

            print("==============================================================================")

            with open("studentdb.csv", "r") as studentcontacts:
                lines = studentcontacts.readlines()  # Read all lines
                lines = lines[1:]  # Skip the header row

                for line in lines:
                    data = line.strip().split(',')  # Split by comma

                    # Ensure there are at least 3 columns
                    if len(data) >= 3:
                        student_id,student_name,student_contact = data[:3]  # Extract only the first 3 values
                        print(f"Student ID: {student_id}, Student Name: {student_name}, Contact: {student_contact}")
                    else:
                        print(f"Error: Incomplete row -> {data}")
                CM()


        elif action51 == "2":

            def view_single_student(student_id):
                with open("studentdb.csv", "r") as studentcontacts:
                    lines = studentcontacts.readlines()[1:]  # Skip header row

                    for line in lines:
                        data = line.strip().split(',')

                        if data[0] == student_id:  # Check if StudentID matches
                            student_id,student_name,student_contact = data[:3]  # Extract only needed fields
                            print("==================================")
                            print(f"Student ID: {student_id}, Student Name: {student_name}, Contact: {student_contact}")
                            return  # Stop searching once found

                print(f"No student found with ID: {student_id}")  # If not found

            student_id = input("Enter Student ID to search or Exit to go back: ").strip()
            if student_id == "Exit":
                CM()
                return
            view_single_student(student_id)
            CM()

        elif action51 == "3":
            CM()
            return

        else:
            print("Wrong input, please try again")
            CM()
            return

    elif action5 == "2":
        print("==============================================================================")
        print("Parents selected")
        print("1 - View all Parents contacts")
        print("2 - View single Parent's contact")
        print("3 - Add Parent Contact")
        print("4 - Edit Parent Contact")
        print("5 - Delete Parent Contact")
        print("6 - Back")
        print("==============================================================================")

        action52 = input("Please select an option: ")
        if action52 == "1":

            print("==============================================================================")

            with open("parentsdb.csv", "r") as parentcontacts:
                lines = parentcontacts.readlines()  # Read all lines
                lines = lines[1:]  # Skip the header row

                for line in lines:
                    data = line.strip().split(',')  # Split by comma

                    # Ensure there are at least 4 columns (so contact number exists)
                    if len(data) >= 5:
                        parent_id = data[0]
                        first_name = data[1]
                        contact = data[4]
                        print(f"Parent ID: {parent_id}, Parent Name: {first_name}, Contact: {contact}")
                    else:
                        print(f"Error")
                CM()

        elif action52 == "2":

            def view_single_parent(parent_id):
                with open("parentsdb.csv", "r") as parentscontacts:
                    lines = parentscontacts.readlines()[1:]  # Skip header row

                    for line in lines:
                        data = line.strip().split(',')

                        if data[0] == parent_id:  # Check if StudentID matches
                            parent_id = data[0]
                            first_name = data[1]
                            contact = data[4]
                            print("==================================")
                            print(f"Parent ID: {parent_id}, Parent Name: {first_name}, Contact: {contact}")
                            return  # Stop searching once found

                print(f"No parent found with ID: {parent_id}")  # If not found

            parent_id = input("Enter Parent ID to search or Exit to go back: ").strip()
            if parent_id == "Exit":
                CM()
                return
            view_single_parent(parent_id)
            CM()

        elif action52 == "3":
            def addParent():

                success, error, parentDB = extra.loadDatabase("parentsdb.csv", False)

                if not success:
                    print(f"Error loading database: {error}")
                    return

                print("==================================")
                print(f"Add to record")
                success, error = extra.modifyRecord(parentDB, "unknown", None)
                parent_id = input("Enter Parent ID or Exit to go back: ").strip()
                if parent_id == "Exit":
                    CM()
                    return
                else:
                    first_name = input("Enter First name: ").strip()
                    sur_name = input("Enter Sur Name: ").strip()
                    age = input("Enter Age: ").strip()
                    contact = input("Enter Contact: ").strip()

                    parentDB[parent_id] = {"first_name": first_name,
                                         "sur_name": sur_name,
                                         "age": age,
                                         "contact": contact}

                    print(f"{first_name} added successfully!")

                    saveSuccess, error = extra.saveData(parentDB, "parentsdb.csv")

                    if saveSuccess:
                        print("Changes saved successfully.")
                        CM()
                    else:
                        print(f"Error saving data: {error}")

            addParent()

        elif action52 == "4":
            def editParent(path, parent):

                success, error, dictionary = extra.loadDatabase(path, False)

                if parent not in dictionary:
                    print(f"{parent} not found.")
                    return

                current_row = dictionary[parent]

                attribute_names = {
                    "parent_id": "Parent ID",
                    "first_name": "First Name",
                    "sur_name": "Sur Name",
                    "age": "Age",
                    "contact": "Contact"}

                print("Available attributes to edit:")
                for key, value in current_row.items():
                    readable_key = attribute_names.get(key, key)
                    print(f"{readable_key}: {value}")

                attributes_to_edit = input("Enter attributes to edit(Eg: First Name) or enter Exit to go back: ").strip()

                if attributes_to_edit == "Exit":
                    CM()
                    return

                attributes_to_edit = attributes_to_edit.split(",")

                for key in attributes_to_edit:
                    key = key.strip()
                    original_key = next((dbkey for dbkey, newkey in attribute_names.items() if newkey == key), key)

                    if original_key in current_row:
                        old_value = current_row[original_key]
                        new_input = input(f"Enter new value for {key} (Current: {old_value}): ")
                        current_row[original_key] = new_input
                    else:
                        print(f"{key} is not a valid attribute.")

                saveSuccess, error = extra.saveData(dictionary, path)
                if saveSuccess:
                    print("Record updated successfully!")
                    print("==================================")
                    editParent("parentsdb.csv", parent)
                else:
                    print(f"Error saving data: {error}")

            parent = input("Enter Parent ID to edit or enter Exit to go back: ").strip()
            if parent == "Exit":
                CM()
                return
            else:
                editParent("parentsdb.csv", parent)

            return

        elif action52 == "5":
            def deleteParent(path, parent):
                success, error, dictionary = extra.loadDatabase("parentsdb.csv", False)

                if parent in dictionary:
                    del dictionary[parent]
                    print(f"{parent} has been deleted successfully.")

                saveSuccess, error = extra.saveData(dictionary, "parentsdb.csv")
                if saveSuccess:
                    print("Database updated successfully.")
                    CM()
                else:
                    print(f"Error saving data: {error}")

            parent = input("Enter Parent ID to delete or Exit to go back: ").strip()
            if parent == "Exit":
                CM()
                return
            else:
                deleteParent("parentsdb.csv", parent)
                return

        elif action52 == "6":
            CM()
            return
        else:
            print("Wrong input, please try again")
            CM()
            return

    elif action5 == "3":
        print("Faculty selected")
        print("1 - View all Lecturer contacts")
        print("2 - View single Lecturer's contact")
        print("3 - View all Staff contacts")
        print("4 - View single Staff's contact")
        print("5 - Back")
        action53 = input("Please select an option: ")
        if action53 == "1":

            print("==============================================================================")

            with open("teacherdb.csv", "r") as teacherscontacts:
                lines = teacherscontacts.readlines()  # Read all lines
                lines = lines[1:]  # Skip the header row

                for line in lines:
                    data = line.strip().split(',')  # Split by comma

                    # Ensure there are at least 4 columns (so contact number exists)
                    if len(data) >= 4:
                        teacher_id,teacher_name,age,contact_number = data[:4]  # Extract the first 4 values
                        print(f"Lecturer ID: {teacher_id}, Lecturer Name: {teacher_name}, Contact: {contact_number}")
                    else:
                        print(f"Error")

            CM()

        elif action53 == "2":

            def view_single_lecturer(teacherid):
                with open("teacherdb.csv", "r") as teachercontacts:
                    lines = teachercontacts.readlines()[1:]  # Skip header row

                    for line in lines:
                        data = line.strip().split(',')

                        if data[0] == teacherid:
                            teacher_id = data[0]
                            teacher_name = data[1]
                            contact_number = data[3]
                            print("==============================================================================")
                            print(f"Lecturer ID: {teacher_id}, Lecturer Name: {teacher_name}, Contact: {contact_number}")
                            return

                print(f"No Lecturer found with ID: {teacherid}")  # If not found

            # Example usage
            teacherid = input("Enter Lecturer ID to search or Exit to go back: ").strip()
            if teacherid == "Exit":
                CM()
                return
            view_single_lecturer(teacherid)
            CM()

        elif action53 == "3":
            print("==============================================================================")
            with open("staffdb.csv", "r") as staffcontacts:
                lines = staffcontacts.readlines()  # Read all lines
                lines = lines[1:]  # Skip the header row

                for line in lines:
                    data = line.strip().split(',')  # Split by comma

                    # Ensure there are at least 4 columns (so contact number exists)
                    if len(data) >= 4:
                        staff_id,first_name,age,contact = data[:4]  # Extract the first 4 values
                        print(f"Staff ID: {staff_id}, Staff Name: {first_name}, Contact: {contact}")
                    else:
                        print(f"Error")

            CM()

        elif action53 == "4":
            def view_single_staff(staffid):
                with open("staffdb.csv", "r") as staffcontacts:
                    lines = staffcontacts.readlines()[1:]  # Skip header row

                    for line in lines:
                        data = line.strip().split(',')

                        if data[0] == staffid:
                            staff_id = data[0]
                            first_name = data[1]
                            contact = data[3]
                            print("==============================================================================")
                            print(f"Staff ID: {staff_id}, Staff Name: {first_name}, Contact: {contact}")
                            return  # Stop searching once found

                print(f"No Staff found with ID: {staffid}")  # If not found

            # Example usage
            staffid = input("Enter Staff ID to search or Exit to go back: ").strip()
            if staffid == "Exit":
                CM()
                return
            view_single_staff(staffid)
            CM()

        elif action53 == "5":
            CM()
            return
        else:
            print("Wrong input, please try again")
            CM()
            return

    elif action5 == "4":
        staff()
        return
    else:
        print("Wrong input, please try again")
        CM()
        return