import extra, mainmenu

def dataBestLength(givenDictionary):
    tempDictionary = givenDictionary.copy()
    tempDictionary = tempDictionary[list(tempDictionary.keys())[0]]

    countDictionary = tempDictionary.copy()
    for i in countDictionary:
        countDictionary[i] = 0

    for record in givenDictionary:
        for attribute in givenDictionary[record]:
            found_data = countDictionary[attribute]
            current_data = givenDictionary[record][attribute]

            if type(givenDictionary[record][attribute]) is int:
                new_data = str(givenDictionary[record].copy()[attribute])

                if len(new_data) > found_data:
                    countDictionary[attribute] = len(new_data)
            elif type(current_data) is list:
                length = 0
                for i in current_data:
                    try:
                        int(i)
                    except (ValueError, TypeError):
                        if type(i) is dict:
                            length += len(i[list(i.keys())[0]])
                        else:
                            length += len(i)
                    else:
                        new_data = str(i)
                        length += len(new_data)
                length += (2 * (len(current_data)-1))

                if length > found_data:
                    countDictionary[attribute] = length
            elif type(current_data) is dict:
                if len(current_data[list(current_data.keys())[0]]) > found_data:
                    countDictionary[attribute] = len(current_data[list(current_data.keys())[0]])
            else:
                if len(current_data) > found_data:
                    countDictionary[attribute] = len(current_data)

    return countDictionary

def displayDict(attribute, givenDictionary):
    print()
    print(f"| \033[1m{attribute}\033[0m")

def displayList(attribute, givenList):
    print(f"| \033[1m{attribute}\033[0m: ", end=" ")
    for i in range(0, len(givenList)):
        if i == len(givenList) - 1:
            if attribute[-6:] == "db.Csv":
                print(f"\033[1m{givenList[i][list(givenList[i].keys())[0]]}\033[0m", end=" ")
            else:
                print(f"\033[1m{givenList[i]}\033[0m", end=" ")
        else:
            if attribute[-6:] == "db.Csv":
                print(f"\033[1m{givenList[i][list(givenList[i].keys())[0]]}\033[0m", end=", ")
            else:
                print(f"\033[1m{givenList[i]}\033[0m", end=", ")


def displayRecords(path, message, ignoreList, includeID):
    success, errorMessage, dictionary = extra.loadDatabase(path, False)
    if not success:
        print(f'\33[31m{errorMessage}\33[0m')
        admin()
        return

    print(f"\033[93m{message}\033[0m")

    if includeID != False:
        try:
            dictionary[includeID]
        except KeyError:
            print("\033[31mCouldn't find ID in database.\033[0m")
            admin()
        else:
            dictionary = {includeID: dictionary[includeID]}

    if len(dictionary) < 1:
        print("\033[31mNo data recorded in database.\033[0m")
        return dictionary

    bestLength = dataBestLength(dictionary.copy())

    idBestLength = 0
    for i in dictionary:
        if len(i) > idBestLength:
            idBestLength = len(i)

    for i in dictionary:
        count = 0
        print(f"| \033[1m{i}\033[0m ", end="")
        print(" " * (idBestLength - len(i)), end="")

        for j in dictionary[i]:
            if ignoreList:
                if not j in ignoreList:
                    count += 1

                    words = j.split("_")
                    new_attribute = " ".join(words)
                    new_attribute = new_attribute.strip("@").title()
                    if type(dictionary[i][j]) is list:
                        displayList(new_attribute, dictionary[i][j])
                    elif type(dictionary[i][j]) is dict:
                        new_attribute = new_attribute.split("db.Csv")[0]
                        record = dictionary[i][j]
                        key = list(record.keys())[0]

                        print(f"| \033[1m{new_attribute}\033[0m: {record[list(record.keys())[0]]}",end=' ')
                    else:
                        print(f"| \033[1m{new_attribute}\033[0m: {dictionary[i][j]}", end=' ')

                    current_data = dictionary[i][j]
                    new_data = (dictionary[i])[j]
                    if type(current_data) is int:
                        new_data = str(current_data)
                    elif type(current_data) is list:
                        new_data = ""
                        for k in current_data:
                            current_list_data = k
                            if type(k) is int:
                                current_list_data = str(current_list_data)
                            elif type(k) is dict:
                                current_list_data = k[list(k.keys())[0]]
                            new_data += current_list_data
                            new_data += ", "
                    elif type(current_data) is dict:
                        new_data = list(current_data.values())[0]

                    if len(new_data) > 0:
                        print(" " * (bestLength[j] - len(new_data)), end='')
                    else:
                        print("N/A ", end='')
                        print(" " * (bestLength[j] - 3), end='')

                    if count == len(dictionary[i]) or count == len(dictionary[i])-len(ignoreList):
                        print("|")
                        break
            else:
                count += 1

                words = j.split("_")
                new_attribute = " ".join(words)
                new_attribute = new_attribute.strip("@").title()
                if type(dictionary[i][j]) is list:
                    displayList(new_attribute, dictionary[i][j])
                elif type(dictionary[i][j]) is dict:
                    new_attribute = new_attribute.split("db.Csv")[0]
                    record = dictionary[i][j]
                    key = list(record.keys())[0]

                    print(f"| \033[1m{new_attribute}\033[0m: {record[list(record.keys())[0]]}",end=' ')
                else:
                    print(f"| \033[1m{new_attribute}\033[0m: {dictionary[i][j]}", end=' ')

                current_data = dictionary[i][j]
                new_data = (dictionary[i].copy())[j]
                if type(current_data) is int:
                    new_data = str(current_data)
                elif type(current_data) is list:
                    new_data = ""
                    for k in current_data:
                        current_list_data = k
                        if type(k) is int:
                            current_list_data = str(current_list_data)
                        elif type(k) is dict:
                            current_list_data = k[list(k.keys())[0]]
                        new_data += current_list_data
                        new_data += ", "
                    new_data = new_data[:(len(new_data)-2)]
                elif type(current_data) is dict:
                    new_data = current_data[list(current_data.keys())[0]]

                if len(new_data) > 0:
                    print(" " * (bestLength[j] - len(new_data)), end='')
                else:
                    print("N/A ", end='')
                    print(" " * (bestLength[j] - 2), end='')

                if count == len(dictionary[i]):
                    print("|")
                    break


    return dictionary

def createNewRecord(dictionary, new_name):
    length = len(list(dictionary)[0][2:])
    amount = str(len(dictionary))
    newID = list(dictionary)[0][:2] + ("0" * (length - len(amount))) + str(int(amount) + 1)

    found_record = dictionary[list(dictionary)[0]].copy()
    dictionary.update({newID:found_record})

    current_row = dictionary[newID]
    for i in current_row:
        if type(current_row[i]) is list:
            current_row[i] = []
        elif type(current_row[i]) is dict:
            success, errorMessage, newDictionary = extra.loadDatabase(i, False)
            if success:
                try:
                    newDictionary[list(newDictionary)[0]]
                except (KeyError, IndexError) as e:
                    system_administration()
                    return

                current_row[i] = newDictionary[list(newDictionary)[0]]
                for j in current_row[i]:
                    if type(current_row[i][j]) is list:
                        current_row[i][j] = []
                    else:
                        current_row[i][j] = "N/A"
            else:
                print(f'\033[31m{errorMessage}\033[0m')
        elif type(current_row[i]) is int:
            current_row[i] = 0
        else:
            current_row[i] = "N/A"

    dictionary[newID][list(dictionary[newID])[0]] = new_name
    return dictionary[newID], newID

def sa_action(action):
    roles = ["Admin", "Student", "Teacher", "Staff", "Return"]

    if action == "1":
        displayRecords("userdb.csv", "「 ✦ All user records ✦ 」", None, False)
        print("1 - Yes")
        print("2 - No")
        while True:
            action2 = input("Find a certain user: ").strip()
            if action2 == "2":
                break
            elif action2 == "1":
                user = input("Enter username (Type '/' to return): ").strip()
                if user == "/":
                    sa_action(action)
                else:
                    userDetails, roleDetails, errorMessage = extra.checkUserExistence(user)
                    if errorMessage:
                        print(errorMessage)
                        break
                    userDictionary = userDetails[1]
                    print(f"| \033[1m{user}\033[0m | \033[1mPassword\033[0m: {userDictionary[user]["password"]} |")
                break

            else:
                print('\033[31m!! Warning: please enter the number based on the option you want to choose. !!\033[0m')

    elif action == "2":
        admindict = displayRecords("admindb.csv", "「 ✦ All admin records ✦ 」", None, False)
        ignoreList = ["gradingdb.csv"]
        studentdict = displayRecords("studentdb.csv", "「 ✦ All student records ✦ 」", ignoreList, False)
        teacherdict = displayRecords("teacherdb.csv", "「 ✦ All teacher records ✦ 」", None, False)
        staffdict = displayRecords("staffdb.csv", "「 ✦ All staff records ✦ 」", None, False)

        print("1 - Admin")
        print("2 - Student")
        print("3 - Teacher")
        print("4 - Staff")
        print("5 - None")
        while True:
            action2 = input("Filter: ")
            if action2 == "5":
                break

            try:
                int(action2)
            except (ValueError, TypeError):
                print('\033[31m!! Warning: please enter the number based on the option you want to choose. !!\033[0m')
            else:
                if int(action2) >= 1 and int(action2) <= 4:
                    displayRecords(f"{roles[int(action2)-1].lower()}db.csv", f"「 ✦ All {roles[int(action2)-1].lower()} records ✦ 」", None, False)
                    break

    elif action == "3":

        for i in range(0, len(roles)):
            print(f"{i+1} - {roles[i]}")
        role = input("Please enter the number based on the role for new user: ").strip()
        try:
            int(role)
        except ValueError:
            print('\033[31m!! Warning: please enter the number based on the option you want to choose. !!\033[0m')
            sa_action(action)
            return
        else:
            if (int(role)-1) < len(roles) and (int(role)-1) >= 0:
                role = int(role)
            else:
                print('\033[31m!! Warning: please enter the number based on the option you want to choose. !!\033[0m')
                sa_action(action)
        if role == 5:
            system_administration()
            return

        success, errorMessage, roleDictionary = extra.loadDatabase(f"{roles[role-1].lower()}db.csv", False)
        if not success:
            print(f"\033[31m{errorMessage}\033[0m")
            system_administration()
            return
        success, errorMessage, userDictionary = extra.loadDatabase("userdb.csv", False)
        if not success:
            print(f"\033[31m{errorMessage}\033[0m")
            system_administration()
            return

        print(f"Please enter details for \033[95mnew user\033[0m in {roles[role-1].lower()} database.")
        print("Enter '/' to return")
        new_name = input("Enter \033[1mname\033[0m: ").strip()
        if new_name == "/":
            sa_action(action)
            return

        record, id = createNewRecord(roleDictionary, new_name)
        success, errorMessage = extra.saveData(roleDictionary, f"{roles[role - 1].lower()}db.csv")
        if not success:
            print(f"\033[31m{errorMessage}\033[0m")
            system_administration()
            return

        ignoreList = ["admin_name", "student_name", "cgpa", "teacher_name", "First_Name", "userdb.csv"]
        success = extra.modifyRecord(roleDictionary, id, ignoreList)
        if not success:
            sa_action(action)
            return

        valid = False
        print(f"Please enter details for \033[95mnew user\033[0m in user database.")
        print("Enter '/' to return.")
        while valid == False:
            new_username = input("Enter \033[1musername\033[0m: ").strip()
            try:
                userDictionary[new_username]
            except (KeyError, TypeError) as e:
                try:
                    assert len(new_username) >= 1
                except AssertionError:
                    print("Username cannot be empty.")
                else:
                    valid = True
            else:

                if new_username == "/":
                    sa_action(action)
                    return

                print("Username already exists.")

        symbols = "!$%&'()*+,-./:;<=>?@[]^_`{|}~."
        symbols += "#"
        valid = False
        print("Password should contain symbols and is no shorter than 8 letters.")
        while valid == False:
            new_password = input("Enter \033[1mpassword\033[0m: ").strip()
            try:
                assert len(new_password) > 7
            except AssertionError:
                print("Password should be longer than 8 letters.")
            else:
                if any(s in symbols for s in new_password):
                    if not new_password.isalnum():
                        print("\033[36mPassword accepted ✅\033[0m")
                        valid = True
                    else:
                        print("Password should contain symbols and is no shorter than 8 letters.")
                else:
                    print("Password should contain at least one symbol.")

        userDictionary[new_username] = {"password" : new_password}
        record["userdb.csv"] = new_username
        success, errorMessage = extra.saveData(roleDictionary, f"{roles[role - 1].lower()}db.csv")
        if not success:
            print(f"\033[31m{errorMessage}\033[0m")
        success, errorMessage = extra.saveData(userDictionary, "userdb.csv")
        if not success:
            print(f"\033[31m{errorMessage}\033[0m")

    elif action == "4":
        user = input("Enter \033[1musername\033[0m in user database or \033[1mID\033[0m in role database (Enter '/' to return): ").strip()
        if user == "/":
            system_administration()
            return

        userDetails, roleDetails, errorMessage = extra.checkUserExistence(user)
        if errorMessage:
            print(f"\033[31m{errorMessage}\033[0m")
        else:
            if not roleDetails[3]:
                print(f"\033[31mCouldn't find user.\033[31m")
                sa_action(action)
                return

            path = roleDetails[0]
            roleDictionary = roleDetails[1]
            roleID = roleDetails[2]

            ignoreList = ["cgpa", "userdb.csv"]
            success = extra.modifyRecord(roleDictionary, roleID, ignoreList)
            if not success:
                system_administration()
                return

            success, errorMessage = extra.saveData(roleDictionary, path)
            if not success:
                print(f"\033[31m{errorMessage}\033[0m")

    else:
        user = input(
            "Enter \033[1musername\033[0m in user database or \033[1mID\033[0m in role database (Enter '/' to return): ").strip()
        if user == "/":
            system_administration()
            return

        userDetails, roleDetails, errorMessage = extra.checkUserExistence(user)
        if errorMessage:
            print(f"\033[31m{errorMessage}\033[0m")
        else:
            userDictionary = userDetails[1]
            userID = userDetails[2]

            path = roleDetails[0]
            roleDictionary = roleDetails[1]
            roleID = roleDetails[2]

            success, errorMessage, userDictionary = extra.loadDatabase("userdb.csv", False)
            if not success:
                print(f"\033[31m{errorMessage}\033[0m")
            else:
                userDictionary.pop(user)
                roleDictionary.pop(roleID)
                success, errorMessage = extra.saveData(roleDictionary, path)
                if not success:
                    print(f"\033[31m{errorMessage}\033[0m")
                success, errorMessage = extra.saveData(userDictionary, "userdb.csv")
                if not success:
                    print(f"\033[31m{errorMessage}\033[0m")

    print(f"\033[36mSuccessfully performed option.\033[0m")
    system_administration()
    return

def system_administration():
    #'\033[31m!! Warning: please enter the number based on the option you want to choose. !!\033[0m'

    print("1 - View user database")
    print("2 - View all records")
    print("3 - Create new user")
    print("4 - Modify user credentials")
    print("5 - Remove existing user")
    print("6 - Return")

    action2 = input("Please enter the number based on the option you want to choose: ").strip()
    if action2 == "1":
        print("\033[96mYou have chosen to view user database.\033[0m")
        sa_action(action2)
        return
    elif action2 == "2":
        print("\033[96mYou have chosen to view all database records.\033[0m")
        sa_action(action2)
        return
    elif action2 == "3":
        print(f"\033[96mYou have chosen to create a new user.\033[0m")
        sa_action(action2)
        return
    elif action2 == "4":
        print(f"\033[96mYou have chosen to modify a user.\033[0m")
        sa_action(action2)
        return
    elif action2 == "5":
        print(f"\033[96mYou have chosen to delete a new user.\033[0m")
        sa_action(action2)
        return #Delete user

    elif action2 == "6":
        admin()
        return
    else:
        print('\033[31m!! Warning: please enter the number based on the option you want to choose. !!\033[0m')
        system_administration()
        return

    system_administration()
    return

def sm_action(action):
    if action == "1":
        studentDictionary = displayRecords("studentdb.csv", "「 ✦ All student details ✦ 」", None, False)

        print("1 - Yes")
        print("2 - No")
        while True:
            action2 = input("Find a certain student: ").strip()
            if action2 == "2":
                break
            elif action2 == "1":
                student = input("Enter student ID (Type '/' to return): ").strip()
                if student == "/":
                    sa_action(action)
                else:
                    userDetails, roleDetails, errorMessage = extra.checkUserExistence(student)
                    if errorMessage:
                        print(errorMessage)
                        student_management()
                        return

                    displayRecords(roleDetails[0],"「 ✦ Student details ✦ 」", None, roleDetails[2])
                break

            else:
                print('\033[31m!! Warning: please enter the number based on the option you want to choose. !!\033[0m')

    elif action == "2":
        user = input("Enter \033[1mstudent ID\033[0m or \033[1musername\033[0m in user database: ").strip()
        userDetails, roleDetails, errorMessage = extra.checkUserExistence(user)
        if errorMessage:
            print(f"\033[31m{errorMessage}\033[0m")
            student_management()
            return
        else:
            path = roleDetails[0]
            roleDictionary = roleDetails[1]
            roleID = roleDetails[2]
            ignoreList = ["userdb.csv"]
            success = extra.modifyRecord(roleDictionary, roleID, ignoreList)
            if not success:
                student_management()
                return

            success, errorMessage = extra.saveData(roleDictionary, path)
            if not success:
                print(f"\033[31m{errorMessage}\033[0m")
    elif action == "3":
        user = input("Enter \033[1mstudent ID\033[0m: ").strip()
        success, errorMessage, dictionary = extra.loadDatabase("studentdb.csv", False)
        if not success:
            print(f"\033[31m{errorMessage}\033[0m")
        else:
            try:
                dictionary[user]
            except KeyError:
                print(f"\033[31m!! Error in finding student ID. !!\033[0m")
                sm_action(action)
            else:
                print(f"| \033[1m{user}\033[0m | \033[1mStudent Name\033[0m: {dictionary[user]["student_name"]} | \033[1mEnrolment Status\033[0m: {dictionary[user]["enrolment_status"]} |")

    else:
        user = input("Enter \033[1mstudent ID\033[0m: ").strip()
        success, errorMessage, dictionary = extra.loadDatabase("studentdb.csv", False)
        if not success:
            print(f"\033[31m{errorMessage}\033[0m")
        else:
            try:
                dictionary[user]
            except KeyError:
                print(f"\033[31m!! Error in finding student ID. !!\033[0m")
                sm_action(action)
                return
            else:
                print(
                    f"| \033[1m{user}\033[0m | \033[1mStudent Name\033[0m: {dictionary[user]["student_name"]} | \033[1mAcademic Peformance\033[0m: {dictionary[user]["academic_performance"]} |")


    print(f"\033[36mSuccessfully performed option.\033[0m")
    student_management()
    return

def student_management():

    print("1 - View all records of student details")
    print("2 - Update student details")
    print("3 - Display student enrolment status")
    print("4 - Display student academic performance")
    print("5 - Return")

    action2 = input("Please enter the number based on the option you want to choose: ").strip()
    if action2 == "1":
        print(f"\033[96mYou have chosen to view all records of student details.\033[0m")
        sm_action(action2)
        return
    if action2 == "2":
        print(f"\033[96mYou have chosen to update student details.\033[0m")
        sm_action(action2)
        return
    elif action2 == "3":
        print(f"\033[96mYou have chosen to display student enrolment status.\033[0m")
        sm_action(action2)
        return #Display student enrolment status
    elif action2 == "4":
        print(f"\033[96mYou have chosen to display student academic performance.\033[0m")
        sm_action(action2)
        return #Display student academic performance
    elif action2 == "5":
        admin()
        return
    else:
        print('\033[31m!! Warning: please enter the number based on the option you want to choose. !!\033[0m')
        student_management()
        return

    student_management()

def cm_action(action):
    if action == "1":
        displayRecords("coursedb.csv", "「 ✦ All courses ✦ 」", None, False)
    elif action == "2":
        success, errorMessage, courseDictionary = extra.loadDatabase("coursedb.csv", False)
        if not success:
            print(errorMessage)
            course_management()
            return

        new_id = input(f"Enter course ID (Type '/' to return): ").strip()
        if new_id == "/":
            course_management()
            return

        record, id = createNewRecord(courseDictionary, new_id)
        courseDictionary[new_id] = record
        courseDictionary.pop(id)
        success = extra.modifyRecord(courseDictionary, new_id, None)
        if not success:
            course_management()
            return

        success, errorMessage = extra.saveData(courseDictionary, "coursedb.csv")
        if not success:
            print(f"\033[31m{errorMessage}\033[0m")
            course_management()
            return

    elif action == "3":
        course = input("Enter \033[1mcourse ID\033[0m (Type '/' to return): ").strip()
        if course == "/":
            course_management()
            return
        success, errorMessage, dictionary = extra.loadDatabase("coursedb.csv", False)
        if not success:
            print(f"\033[31m{errorMessage}\033[0m")
            course_management()
            return

        try:
            dictionary[course]
        except KeyError:
            print(f"\033[31m!! Error in finding course ID. !!\033[0m")
            cm_action(action)
        else:
            new_id = input("Enter \033[1mnew ID\033[0m: ")
            if len(new_id) == 0:
                cm_action(action)
                return

            print(f"Please enter details for \033[95mnew course\033[0m in course database.")
            success = extra.modifyRecord(dictionary, course, None)
            if not success:
                cm_action(action)
                return

            dictionary[new_id] = dictionary[course]
            dictionary.pop(course)
            success, errorMessage = extra.saveData(dictionary, "coursedb.csv")
            if not success:
                print(errorMessage)
                cm_action(action)
                return
    elif action == "4":
        course = input("Enter \033[1mcourse ID\033[0m in course database (Type '/' to return): ").strip()
        if course == "/":
            course_management()
            return

        success, errorMessage, path, courseDictionary, dictID = extra.checkDBExistence(course)
        if not success:
            print(f"\033[31m{errorMessage}\033[0m")
        else:
            courseDictionary.pop(course)
            success, errorMessage = extra.saveData(courseDictionary, path)
            if not success:
                print(f"\033[31m{errorMessage}\033[0m")
    else:
        ignoreList = ["scheduledb.csv", "assignments"]
        courseDictionary = displayRecords("coursedb.csv", "「 ✦ All course records ✦ 」", ignoreList, False)
        while True:
            course = input("Enter \033[1mcourse ID\033[0m in course database (Type '/' to return): ").strip()
            if course == "/":
                course_management()
                return
            try:
                courseDictionary[course]
            except KeyError:
                print("\033[31m !! Course not found in database. !! \033[0m")
            else:
                break

        teacherDictionary = displayRecords("teacherdb.csv", "「 ✦ All teacher records ✦ 」", None, False)
        while True:
            teacher = input("Enter \033[1mteacher ID\033[0m in course database (Type '/' to return): ").strip()
            if teacher == "/":
                course_management()
                return
            try:
                teacherDictionary[teacher]
            except KeyError:
                print("\033[31m !! Teacher not found in database. !! \033[0m")
            else:
                break

        teacherDictionary[teacher]["coursedb.csv"] = course

        success, errorMessage = extra.saveData(teacherDictionary, "teacherdb.csv")
        if not success:
            print(f"\033[31m{errorMessage}\033[0m")

    print(f"\033[36mSuccessfully performed option.\033[0m")
    course_management()

def course_management():
    #with open("courses_database.csv", "r", encoding="utf-8") as courses_db:
        #courses_db.read()

    print("1 - View all course offerings")
    print("2 - Create course offering")
    print("3 - Update course offering")
    print("4 - Delete course offering")
    print("5 - Assign teacher to course")
    print("6 - Return")

    action2 = input("Please enter the number based on the option you want to choose: ").strip()
    if action2 == "1":
        print(f"\033[96mYou have chosen to view all course offerings.\033[0m")
        cm_action(action2)
        return #Create course offering
    elif action2 == "2":
        print(f"\033[96mYou have chosen to create course offering.\033[0m")
        cm_action(action2)
        return #Update course offering
    elif action2 == "3":
        print(f"\033[96mYou have chosen to update course offering.\033[0m")
        cm_action(action2)
        return #Delete course offering
    elif action2 == "4":
        print(f"\033[96mYou have chosen to delete course offering.\033[0m")
        cm_action(action2)
        return #Assign teacher to course
    elif action2 == "5":
        print(f"\033[96mYou have chosen to assign a teacher to a course.\033[0m")
        cm_action(action2)
        return
    elif action2 == "6":
        admin()
        return
    else:
        print('\033[31m!! Warning: please enter the number based on the option you want to choose. !!\033[0m')
        course_management()
        return

    course_management()

def minutesToHours(minutes):
    hours = 0
    minutes = minutes

    while minutes >= 60:
        minutes -= 60
        hours += 1

    return hours, minutes

def checkClassOverlap(record1, record2):
    success = True

    currentClass_Time = record1["StartTime"].split(":")
    currentClass_StartHour = int(currentClass_Time[0])
    currentClass_StartMinute = int(currentClass_Time[1])
    duration = record1["Duration@"].strip("H")
    currentClass_Minutes = int(float(duration) * 60) - 1
    currentClass_EndMinute = currentClass_StartMinute + currentClass_Minutes
    newHours, newMinutes = minutesToHours(currentClass_EndMinute)

    currentClass_EndHour = currentClass_StartHour + newHours
    currentClass_EndMinute = newMinutes
    while currentClass_EndHour >= 24:
        currentClass_EndHour -= 24

    secondClass_Time = record2["StartTime"].split(":")
    secondClass_StartHour = int(secondClass_Time[0])
    secondClass_StartMinute = int(secondClass_Time[1])
    duration = record2["Duration@"].strip("H")
    secondClass_Minutes = int(float(duration) * 60)
    secondClass_EndMinute = secondClass_StartMinute + secondClass_Minutes
    newHours, newMinutes = minutesToHours(secondClass_EndMinute)

    secondClass_EndHour = secondClass_StartHour + newHours
    secondClass_EndMinute = newMinutes
    while secondClass_EndHour >= 24:
        secondClass_EndHour -= 24

    currentClass_Date = record1["Date"].split("-")
    currentClass_Date = list(map(int, currentClass_Date))
    secondClass_Date = record2["Date"].split("-")
    secondClass_Date = list(map(int, secondClass_Date))
    if currentClass_Date[0] != secondClass_Date[0]:
        return success, None
    elif currentClass_Date[1] != secondClass_Date[1]:
        return success, None
    elif currentClass_Date[2] != secondClass_Date[2]:
        return success, None

    if record1["classroomdb.csv"] != record2["classroomdb.csv"]:
        return success, None

    if currentClass_StartHour > currentClass_EndHour:
        secondClass_StartHour += 24
        secondClass_EndHour += 24
        if currentClass_EndHour < 24:
            currentClass_EndHour += 24
    if currentClass_StartHour <= secondClass_EndHour and currentClass_StartHour >= secondClass_StartHour:
        if currentClass_StartMinute <= secondClass_EndMinute:
            success = False
            return success, f"\033[31m !! Class time overlaps with other class times. Please check the full list of classes again."
        else:
            success = True
    else:
        success = True

    if secondClass_StartHour <= currentClass_EndHour and secondClass_StartHour >= currentClass_StartHour:
        if secondClass_StartMinute <= currentClass_EndMinute:
            success = False
            return success, f"\033[31m !! Class time overlaps with other class times. Please check the full list of classes again."
        else:
            success = True
    else:
        success = True

    return success, None


def cs_action(action):
    if action == "1":
        displayRecords("classdb.csv", "「 ✦ All class records ✦ 」", None, False)
    elif action == "2":
        while True:
            classID = input("Enter \033[1mclass ID\033[0m (Type '/' to return): ").strip()
            if classID == "/":
                class_schedule()
                return

            success, errorMessage, path, classDictionary, classID = extra.checkDBExistence(classID)
            if not success:
                print(f"\033[31m{errorMessage}\033[0m")
            else:
                break

        ignoreList = ["ClassID", "ClassName"]
        success = extra.modifyRecord(classDictionary, classID, ignoreList)
        if not success:
            course_management()
            return

        success, errorMessage, path, classroomDictionary, classroomID = extra.checkDBExistence(classDictionary[classID]["classroom.csv"][0])
        if not success:
            print(errorMessage)
            class_schedule()
            return

        current_record = classDictionary[classID]
        for record in classDictionary:
            success, errorMessage = checkClassOverlap(current_record, classDictionary[record])
            if not success:
                print(f"\033[31m{errorMessage}\033[0m")
                cs_action(action)
                break
                return

        success, errorMessage = extra.saveData(classDictionary, "classdb.csv")
        if not success:
            print(f"\033[31m{errorMessage}\033[0m")
    elif action == "3":
        displayRecords("resourcesdb.csv", "「 ✦ All resource records ✦ 」", None, False)
    else:
        resourcesDictionary = displayRecords("resourcesdb.csv", "「 ✦ All resource records ✦ 」", None, False)
        classroomDictionary = displayRecords("classroomdb.csv", "「 ✦ All classroom records ✦ 」", None, False)

        while True:
            resourceID = input("Enter \033[1mresource ID\033[0m (Type '/' to return): ").strip()
            if resourceID == "/":
                class_schedule()
                return

            success, errorMessage, path, classDictionary, resourceID = extra.checkDBExistence(resourceID)
            if not success:
                print(f"\033[31m{errorMessage}\033[0m")
            else:
                break

        ignoreList = ["status"]
        success = extra.modifyRecord(resourcesDictionary, resourceID, ignoreList)
        if not success:
            class_schedule()
            return

        for resource in resourcesDictionary:
            if resourcesDictionary[resource]["assigned_to"] == resourcesDictionary[resourceID]["assigned_to"] and resource != resourceID:
                print(f"\033[31mResource ID {resourceID} has the same classroom assignment as {resource}.\033[0m")
                class_schedule()
                return

            if resourcesDictionary[resource]["assigned_to"] != "None":
                try:
                    classroomDictionary[resourcesDictionary[resource]["assigned_to"]]
                except KeyError:
                    print(
                        f"\033[31mResource ID {resource} contains a classroom in 'assigned_to' that doesn't exist.\033[0m")
                    class_schedule()
                    return


            if resourcesDictionary[resource]["assigned_to"] == "None":
                resourcesDictionary[resource]["status"] = "Available"
            else:
                resourcesDictionary[resource]["status"] = "Allocated"

        success, errorMessage = extra.saveData(resourcesDictionary, "resourcesdb.csv")
        if not success:
            print(f"\033[31m{errorMessage}\033[0m")

    print(f"\033[36mSuccessfully performed option.\033[0m")
    class_schedule()

def class_schedule():
    #with open("classes_database", "r", encoding="utf-8") as classes_db:
        #classes_db.read()

    print("1 - View all class schedules")
    print("2 - Update class schedule")
    print("3 - View all resources")
    print("4 - Update resource details")
    print("5 - Return")

    action2 = input("Please enter the number based on the option you want to choose: ").strip()
    if action2 == "1":
        print(f"\033[96mYou have chosen to view all class schedules.\033[0m")
        cs_action(action2)
        return #Modify class schedule
    elif action2 == "2":
        print(f"\033[96mYou have chosen to update class schedule.\033[0m")
        cs_action(action2)
        return
    elif action2 == "3":
        print(f"\033[96mYou have chosen to view all resources.\033[0m")
        cs_action(action2)
        return
    elif action2 == "4":
        print(f"\033[96mYou have chosen to update resouce details.\033[0m")
        cs_action(action2)
        return
    elif action2 == "5":
        admin()
        return
    else:
        print('\033[31m!! Warning: please enter the number based on the option you want to choose. !!\033[0m')
        class_schedule()
        return

    class_schedule()

def rg_action(action):
    if action == "1":
        ignoreList = ["@student_contact", "coursedb.csv", "enrolment_status", "emergency_contact_name", "@emergency_contact", "relationship_to_student", "fees_oustanding", "fees_paid", "next_payment_date", "userdb.csv"]
        displayRecords("studentdb.csv", "「 ✦ Student academic performance records ✦ 」", ignoreList, False)
    elif action == "2":
        displayRecords("attendance_trackingdb.csv", "「 ✦ Student attendance records ✦ 」", None, False)
        while True:
            print("1 - Class")
            print("2 - Event")
            action2 = input("Filter (Type '/' to return): ").strip()
            if action2 == "/":
                break
            elif action2 == "1":
                ignoreList = ["eventsdb.csv"]

                success, errorMessage, attendanceDictionary = extra.loadDatabase("attendance_trackingdb.csv", False)
                if not success:
                    print(f"\033[31m{errorMessage}\033[0m")
                    report_generation()
                    return

                print("\033[93m「 ✦ Student class attendance records ✦ 」\033[0m")
                foundRecords = 0

                for record in attendanceDictionary:
                    if attendanceDictionary[record]["classdb.csv"] != "N/A":
                        currentRecord = attendanceDictionary[record]
                        foundRecords += 1
                        if currentRecord["status"] == "Present":
                            print(f"| \033[1m{record}\033[0m | \033[1mStudent ID\033[0m: {currentRecord["studentdb.csv"]["student_id"]} | \033[1mClass ID\033[0m: {currentRecord["classdb.csv"]["class_id"]} | \033[1mDate\033[0m: {currentRecord["date"]} | \033[1mStatus\033[0m: {currentRecord["status"]} |")
                        else:
                            print(f"| \033[1m{record}\033[0m | \033[1mStudent ID\033[0m: {currentRecord["studentdb.csv"]["student_id"]} | \033[1mClass ID\033[0m: {currentRecord["classdb.csv"]["class_id"]} | \033[1mDate\033[0m: {currentRecord["date"]} | \033[1mStatus\033[0m: {currentRecord["status"]}  |")

                if foundRecords < 1:
                    print("\033[31mNo data recorded in database.\033[0m")

            elif action2 == "2":
                ignoreList = ["classdb.csv"]

                success, errorMessage, attendanceDictionary = extra.loadDatabase("attendance_trackingdb.csv", False)
                if not success:
                    print(f"\033[31m{errorMessage}\033[0m")
                    report_generation()
                    return

                print("\033[93m「 ✦ Student event attendance records ✦ 」\033[0m")
                foundRecords = 0

                for record in attendanceDictionary:
                    if attendanceDictionary[record]["eventsdb.csv"] != "N/A":
                        currentRecord = attendanceDictionary[record]
                        foundRecords += 1
                        if currentRecord["status"] == "Present":
                            print(f"| \033[1m{record}\033[0m | \033[1mStudent ID\033[0m: {currentRecord["studentdb.csv"]["student_id"]} | \033[1mEvent ID\033[0m: {currentRecord["eventsdb.csv"]["event_id"]} | \033[1mDate\033[0m: {currentRecord["date"]} | \033[1mStatus\033[0m: {currentRecord["status"]} |")
                        else:
                            print(f"| \033[1m{record}\033[0m | \033[1mStudent ID\033[0m: {currentRecord["studentdb.csv"]["student_id"]} | \033[1mEvent ID\033[0m: {currentRecord["eventsdb.csv"]["event_id"]} | \033[1mDate\033[0m: {currentRecord["date"]} | \033[1mStatus\033[0m: {currentRecord["status"]}  |")

                if foundRecords < 1:
                    print("\033[31mNo data recorded in database.\033[0m")
            else:
                print('\033[31m!! Warning: please enter the number based on the option you want to choose. !!\033[0m')
    else:
        while True:
            print("1 - Student")
            print("2 - Institution")
            action2 = input("Enter \033[1mselection\033[0m (Type '/' to return): ").strip()
            if action2 == "/":
                break
            elif action2 == "1":
                ignoreList = ["@student_contact", "coursedb.csv", "cgpa", "enrolment_status", "academic_performance", "emergency_contact_name", "@emergency_contact", "relationship_to_student", "userdb.csv"]
                displayRecords("studentdb.csv", "\033[93m「 ✦ Financial report for students ✦ 」\033[0m", ignoreList, False)
            elif action2 == "2":
                success, errorMessage, institutionDictionary = extra.loadDatabase("institutiondb.csv", False)
                if not success:
                    print(f"\033[31m{errorMessage}\033[0m")
                else:
                    institution = institutionDictionary["IN1"]
                    print(f"\033[93m「 ✦ Financial report for {institution["institution_name"]} ✦ 」\033[0m")

                    ignoreList = ["id", "institution_name"]
                    for attribute in institution:
                        if not attribute in ignoreList:
                            words = attribute.split("_")
                            new_attribute = " ".join(words)
                            new_attribute = new_attribute.strip("@").title()
                            print(f"・・・・・・ {new_attribute} ・・・・・・")
                            print(" " * 8, end="")
                            print(f"RM {institution[attribute]}")
            else:
                print('\033[31m!! Warning: please enter the number based on the option you want to choose. !!\033[0m')

    print(f"\033[36mSuccessfully performed option.\033[0m")
    report_generation()

def report_generation():
    print("1 - Generate student academic performance report")
    print("2 - Generate student attedance report")
    print("3 - Generate financial report")
    print("4 - Return")

    action2 = input("Please enter the number based on the option you want to choose: ").strip()
    if action2 == "1":
        print(f"\033[96mYou have chosen to generate student academic performance report.\033[0m")
        rg_action(action2)
        return #Display all student academic performance report
    elif action2 == "2":
        print(f"\033[96mYou have chosen to generate student attendance report.\033[0m")
        rg_action(action2)
        return #Display all student attendance report
    elif action2 == "3":
        print(f"\033[96mYou have chosen to generate institution financial report.\033[0m")
        rg_action(action2)
        return #Display institution financial report
    elif action2 == "4":
        admin()
        return
    else:
        print('\033[31m!! Warning: please enter the number based on the option you want to choose. !!\033[0m')
        report_generation()
        return

    report_generation()

actions = {"1": ["System Administration",
                 system_administration],
           "2": ["Student Management",
                 student_management],
           "3": ["Course Management",
                 course_management],
           "4": ["Class Schedule",
                 class_schedule],
           "5": ["Report Generation",
                 report_generation],
           }

def admin():
    while True:
        for i in actions:
            print(f"{i} - {actions[i][0]}")
        print("6 - Logout")

        action = input("Please enter the number based on the option you want to choose: ").strip()
        try:
            actions[action]
        except KeyError:
            if action == "6":
                print("1 - Yes")
                print("2 - No")
                action2 = input("Do you want to terminate program? ")
                if action2 == "1":
                    exit()
                elif action2 == "2":
                    mainmenu.homepage()
                else:
                    print('\033[31m!! Warning: please enter the number based on the option you want to choose. !!\033[0m')
                    admin()
                    return
            else:
                print('\033[31m!! Warning: please enter the number based on the option you want to choose. !!\033[0m')
        else:
            print(f"\033[96mYou have chosen {actions[action][0]}.\033[0m")
            actions[action][1]()
            return