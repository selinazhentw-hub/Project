import extra, mainmenu

#Student main page
def student(studID):
    print("1 - View Personal Information\n2 - View All Class Timetables\n3 - About Courses\n4 - View Grades\n5 - Submit Feedback\n6 - Logout")

    action = input("\033[34mSelect an option by entering a number (1, 2, 3, 4 or 5): \033[0m")

    if action == "1":
        spinfo(studID)
    elif action == "2":
        classtime(studID)
    elif action == "3":
        courselist(studID)
    elif action == "4":
        semgrades(studID)
    elif action == "5":
        sf(studID)
    elif action == "6":
        confirmation(studID)
    else:
        print("\033[41mInvalid option!\033[0m")
        student(studID)

#View personal information
def spinfo(studID):
    ignoreList = ['coursedb.csv', 'gradingdb.csv', 'enrolment_status', 'userdb.csv', 'student_sem_gpa']

    attributes = {"student_name": "Name",
                  "@student_contact": "Personal Contact Number",
                  "academic_performance": "Academic Performance",
                  "emergency_contact_name": "Emergency Contact Name",
                  "@emergency_contact": "Emergency Contact Number",
                  "relationship_to_student": "Emergency Contact's Relationship to Student",
                  "fees_outstanding": "Fees - Outstanding",
                  "fees_paid": "Fees - Paid",
                  "next_payment_date": "Next Payment Date"}

    success, errorMessage, dictionary = extra.loadDatabase("studentdb.csv", False)

    if not success:
        print(f'{errorMessage}')
        student(studID)

    else:
        for i in dictionary:
            if i == studID:
                print('\033[35m','~ Student ID: ',i,'~\033[0m')
                for j in dictionary[i]:
                    if j not in ignoreList:
                        new_attributes = attributes.get(j, j)

                        print(f"{new_attributes}: {dictionary[i][j]}")

    action = input("\033[34mPress ENTER to edit information // Enter '0' for main menu: \033[0m")

    if action == "0":
        student(studID)
    else:
    #Update information
        ignoreList = ['coursedb.csv', 'gradingdb.csv', 'enrolment_status', 'academic_performance', 'fees_outstanding', 'fees_paid', 'next_payment_date', 'userdb.csv']
        success = extra.modifyRecord(dictionary, studID, ignoreList)

        if not success:
            print(f'{errorMessage}')
            spinfo(studID)
        else:
            print("\033[42m\033[30m>>>>> Update successful <<<<<\033[0m\033[0m")
            extra.saveData(dictionary, "studentdb.csv")
            action = input("\033[31m----- Press ENTER to return -----\033[0m")
            student(studID)

def classtime(studID):

    attributes = {"class_name": "Class",
                  "classroomdb.csv": "Classroom",
                  "teacherdb.csv": "Teacher",
                  "date": "Date",
                  "start_time": "Start Time",
                  "duration@": "Duration"}

    success, errorMessage, dictionary = extra.loadDatabase("classdb.csv", False)

    if not success:
        print(f'{errorMessage}')
        student(studID)
    else:
        for i in dictionary:
            print('\033[35m', '~ Class ID:', i, '~', '\033[0m')
            for j in dictionary[i]:
                new_attributes = attributes.get(j, j)

                if j == "classroomdb.csv":
                    print(f"Venue: {dictionary[i][j].get('VenueID', 'N/A')}")

                elif j == "teacherdb.csv":
                    print(f"Teacher: {dictionary[i][j].get('teacher_name', 'N/A')}")

                else:
                    print(f"{new_attributes}: {dictionary[i][j]}")
        action = input("\033[31m----- Press ENTER to return -----\033[0m")
        student(studID)

#About courses
def courselist(studID):
    print("1 - Enroll\n2 - View Course Materials")
    action = input("\033[34mWhat would you like to do? (1 or 2 // Enter 0 to RETURN): \033[0m")

    #Enroll
    if action == "1":

        attributes = {"course_id" : "Course ID",
                      "course_name" : "Course",
                      "class_name" : "Classes to attend"}

        ignoreList = ["scheduledb.csv", "assignments"]

        success, errorMessage, dictionary = extra.loadDatabase("coursedb.csv", False)

        if not success:
            print(f"{errorMessage}")
            courselist(studID)
        else:
            for i in dictionary:
                print('\033[35m', 'Course ID:', i, '\033[0m')
                for j in dictionary[i]:
                    if j not in ignoreList:
                        new_attributes = attributes.get(j,j)
                        if j == "course_name":
                            print(f"<{new_attributes}: {dictionary[i][j]}>")
                        if j == "class_name":
                            print(f"<{new_attributes}: {', '.join(dictionary[i][j])}>")
            courseid = input("\033[34mEnter the Course ID of the course you wish to enroll (Enter '0' to RETURN): \033[0m")
            if courseid == "0":
                courselist(studID)
            if len(courseid) == 0:
                print("\033[41mInvalid option!\033[0m")
                courselist(studID)
            elif courseid in dictionary:
                success, errorMessage, studentdictionary = extra.loadDatabase("studentdb.csv", False)
                if not success:
                    print(f"{errorMessage}")
                    courselist(studID)

                studentdictionary[studID]['coursedb.csv'] = courseid

                success, errorMessage = extra.saveData(studentdictionary, "studentdb.csv")
                if not success:
                    print(f"{errorMessage}")
                    courselist(studID)
                else:
                    extra.saveData(studentdictionary, "studentdb.csv")
                    print("\033[42m\033[30m>>>>> Enrolment successful <<<<<\033[0m\033[0m")

                action = input("\033[31m----- Press ENTER to return -----\033[0m")
                student(studID)
            else:
                print("\033[41mInvalid option!\033[0m")
                courselist(studID)

    #View course materials
    elif action == "2":
        dlcm(studID)

    #Return to student main page
    elif action == "0":
        student(studID)
    else:
        print("\033[41mInvalid option!\033[0m")
        courselist(studID)

#Download course materials
def dlcm(studID):
    ignoreList = ["scheduledb.csv"]
    attributes = {"course_name": "Course",
                  "class_name": "Class",
                  "assignments": "Assignments"}

    success, errorMessage, dictionary = extra.loadDatabase("coursedb.csv", studID)
    if not success:
        print(f"{errorMessage}")
        courselist(studID)
    else:
        for i in dictionary:
            for j in dictionary[i]:
                if j not in ignoreList:
                    new_attributes = attributes.get(j, j)
                    print(f"{new_attributes} : {dictionary[i][j]}")

    print("1 - Download all lecture notes\n2 - Download all assignments\n3 - Download all announcements\n4 - Back")
    action = input("\033[34mSelect an option: \033[0m")
    if action == "1" or action == "2" or action == "3":
        print("\033[42m\033[30m>>>>> Download successful <<<<<\033[0m\033[0m")
        action = input("\033[31m----- Press ENTER to return -----\033[0m")
        student(studID)
    elif action == "4":
        student(studID)
    else:
        print("\033[41mInvalid option!\033[0m")
        dlcm(studID)

#View grades
def semgrades(studID):
    ignoreList = ["grading_id", "studentdb.csv", "subject_marks"]

    displayList = ["@student_sem_gpa"]

    attributes = {"subject_gpa@": "Subject GPA",
                  "feedback": "Teacher's Comments",
                  "@student_sem_gpa" : "Semester GPA"}

    success, errorMessage, dictionary = extra.loadDatabase("gradingdb.csv", False)
    if not success:
        print(f'{errorMessage}')
        student(studID)

    else:
        for i in dictionary:
            if dictionary[i]["studentdb.csv"]["student_id"] == studID:
                for j in dictionary[i]:
                    if j not in ignoreList:
                        new_attributes = attributes.get(j, j)
                        if j == "classdb.csv":
                            print("\033[35m⏳ SEMESTER 1 ⏳\033[0m")
                            print(f"Class ID: {dictionary[i][j]["class_id"]}")
                        else:
                            print(f"{new_attributes} : {dictionary[i][j]}")

    success, errorMessage, dictionary = extra.loadDatabase("studentdb.csv", False)
    if not success:
        print(f'{errorMessage}')
        student(studID)

    else:
        for i in dictionary:
            if i == studID:
                for j in dictionary[i]:
                    if j in displayList: #Display GPA
                        new_attributes = attributes.get(j, j)
                        print(f"{new_attributes}: {dictionary[i][j]}")

    action = input("\033[31m----- Press ENTER to return -----\033[0m")
    student(studID)


#Submit feedback
def sf(studID):
    print("1 - Teacher\n2 - Class\n3 - Overall Academic Experience")
    action = input("\033[34mWhat would you like to feedback on? (Enter '0' to RETURN): \033[0m")

    if action == "1":
        teacherfb(studID)

    elif action == "2":
        classfb(studID)

    elif action == "3":
        overallfb(studID)

    elif action == "0":
        student(studID)

    else:
        print("\033[41mInvalid option!\033[0m")
        sf(studID)

def teacherfb(studID):
    displayList = ['teacher_name']
    attributes = {'teacher_name': 'Teacher Name'}
    success, errorMessage, dictionary = extra.loadDatabase("teacherdb.csv", False)
    if not success:
        print(f'{errorMessage}')
        student(studID)
    else:
        for i in dictionary:
            for j in dictionary[i]:
                if j in displayList:
                    new_attributes = attributes.get(j, j)
                    print(f"<{new_attributes}: {dictionary[i][j]}>")
    teacher = input("\033[34mWho is the feedback for? (Enter 0 to go back): \033[0m")

    teacherList = []
    for i in dictionary:
        teacherList.append(dictionary[i]["teacher_name"])
    if teacher == "0":
        student(studID)
    elif len(teacher) == 0:
        print("\033[31mPlease specify a teacher you wish to feedback about.\033[0m")
        teacherfb(studID)
    elif teacher in teacherList:
        rate = input(f"\033[34mRate {teacher} from 0(worst) to 10(best): \033[0m")
        numList = ["0", "1", "2", "3", "4", "5", "6", "7", "8", "9", "10"]
        if len(rate) == 0:
            print("\033[31mPlease enter a rating.\033[0m")
            teacherfb(studID)
        elif rate not in numList:
            print("\033[41mInvalid input!\033[0m")
            teacherfb(studID)
        else:
            improve = input(f"\033[34mWhat can be done to improve your experience with {teacher}'s teachings: \033[0m")
            if len(improve) == 0:
                print("\033[41mInvalid input!\033[0m")
                teacherfb(studID)

        with open("feedbackdb.csv", "a", encoding="utf-8-sig") as fb:
            fb.write(f"\n{teacher},N/A,N/A,{rate},{improve}")
            print("\033[34mSubmitted. Thank you for your valuable feedback ^v^\033[0m")
            final(studID)
    else:
        print("\033[31mPlease specify a teacher you wish to feedback about.\033[0m")
        sf(studID)

def classfb(studID):
    displayList = ["class_name"]
    attributes = {'class_name': 'Class'}
    success, errorMessage, dictionary = extra.loadDatabase("classdb.csv", False)
    if not success:
        print(f'{errorMessage}')
        student(studID)
    else:
        for i in dictionary:
            for j in dictionary[i]:
                if j in displayList:
                    new_attributes = attributes.get(j, j)
                    print(f"<{new_attributes}: {dictionary[i][j]}>")
    classname = input("\033[34mWhich class is the feedback about? (Enter 0 to go back): \033[0m")
    classList = []
    for i in dictionary:
        classList.append(dictionary[i]["class_name"])
    if classname == "0":
        student(studID)
    elif len(classname) == 0:
        print("\033[31mPlease specify a class you wish to feedback about.\033[0m")
        classfb(studID)
    elif classname in classList:

        rate = input(f"\033[34mRate {classname} from 0(worst) to 10(best): \033[0m")
        numList = ["0", "1", "2", "3", "4", "5", "6", "7", "8", "9", "10"]
        if len(rate) == 0:
            print("\033[31mPlease enter a rating.\033[0m")
            classfb(studID)
        elif rate not in numList:
            print("\033[41mInvalid input!\033[0m")
            classfb(studID)
        else:
            improve = input(f"\033[34mWhat can be done to improve your experience during {classname}: \033[0m")
            if len(improve) == 0:
                print("\033[41mInvalid input!\033[0m")
                classfb(studID)

        with open("feedbackdb.csv", "a", encoding="utf-8-sig") as fb:
            fb.write(f"\nN/A,{classname},N/A,{rate},{improve}")
            print("\033[34mSubmitted. Thank you for your valuable feedback ^v^\033[0m")
            final(studID)
    else:
        print("\033[31mPlease specify a class you wish to feedback about.\033[0m")
        classfb(studID)

def overallfb(studID):
    numList = ["0", "1", "2", "3", "4", "5", "6", "7", "8", "9", "10"]
    overall = input("\033[34mRate your overall academic experience from 0(worst) to 10(best) (Enter '/' to go back): \033[0m")
    if overall == "/":
        student(studID)
    elif len(overall) == 0:
        print("\033[31mPlease enter a rating.\033[0m")
        overallfb(studID)
    elif overall not in numList:
        print("\033[41mInvalid input!\033[0m")
        overallfb(studID)
    else:
        improve = input(f"\033[34mWhat can be done to improve your overall experience here: \033[0m")
        if len(improve) == 0:
            print("\033[41mInvalid input!\033[0m")
            overallfb(studID)
        else:
            with open("feedbackdb.csv", "a", encoding="utf-8-sig") as fb:
                fb.write(f"\nN/A,N/A,{overall},N/A,{improve}")
                print("\033[34mSubmitted. Thank you for your valuable feedback ^v^\033[0m")
                final(studID)

def final(studID):
    print("1 - Submit another feedback\n2 - Home\n3 - Logout")
    action = input("Select 1, 2 or 3: ")
    if action == "1":
        sf(studID)
    elif action == "2":
        student(studID)
    elif action == "3":
        confirmation(studID)
    else:
        print("\033[41mInvalid option!\033[0m")
        final(studID)

def confirmation(studID):
    confirm = input("\033[33mDo you want to end the program? (Yes/No): \033[0m")
    if confirm == "Yes":
        print("\033[7mClosing program...\033[0m")
        exit()
    elif confirm == "No":
        print("\033[42m\033[30m>>>>> Logout successful <<<<<\033[0m")
        mainmenu.homepage()
    else:
        print("\033[31mPlease enter 'Yes' or 'No'.\033[0m")
        confirmation(studID)