import extra, admin, student, teacher, staff

#Main page
def homepage():
    print("——————————————————————————————————————————————————————————————")
    print("-------------• 📑 WELCOME TO EDU MANAGEMENT ✍️ •-------------")
    print("——————————————————————————————————————————————————————————————")
    print("1 - Sign Up\n2 - Login")
    action = input("\033[33mEnter an option (1 or 2): \033[0m")

    if action == "1":
        signup()
    elif action == "2":
        login()
        # Admin - Username: zxzx01 - Password: zxzxzx01#
        # Student - Username: alicia01 - Password: aliali23*
        # Teacher - Username: emi_ly - Password: emily*321
        # Staff - Username: NicholasC46 - Password: P@ssw0rd7x!
    else:
        print("\033[41mInvalid option!\033[0m")
        homepage()

#User signup page
def signup():
    user = input("\033[33mUsername (Enter '0' to RETURN): \033[0m")
    if user == "0":
        homepage()
    if len(user) == 0:
        print("\033[31mPlease enter a username.\033[0m")
        signup()
    else:
        #Checks whether the username exists
        userDetails, roleDetails, error = extra.checkUserExistence(user)
        if not error:
            print(f"\033[31mUsername already exists. Please enter a different username.\033[0m")
            homepage()
            return

        else:
            print("Username accepted ✅")
            success, errorMessage, userDictionary = extra.loadDatabase("userdb.csv", False)
            if not success:
                print(f"\033[31m{errorMessage}\033[0m")
                homepage()
                return

            password(userDictionary, user)

#Set password
def password(userDictionary, username):
    symbols = "!$%&'()*+,-./:;<=>?@[]^_`{|}~."
    symbols += "#"

    print("\033[33mPassword should contain symbols and is no shorter than 8 letters.\033[m")

    pwd = input("\033[33mPassword: \033[0m")

    #Password should be longer than 7 letters and has a combination of symbols, alphabets, and numbers
    if len(pwd) > 7 and any(s in symbols for s in pwd) and not pwd.isalnum():
        print("\033[32mPassword accepted ✅\033[0m")

        userDictionary[username] = {"password":pwd}
        success, errorMessage = extra.saveData(userDictionary, "userdb.csv")

        if not success:
            print(f'\033[31m{errorMessage}\033[0m')
            signup()
        else:
            print("\033[32mSign up successful ✅\033[0m")
            print("1 - Admin\n2 - Student\n3 - Teacher\n4 - Staff")
            role(username)
    else:
        password(userDictionary, username)

def indexList(listGiven):
    newList = listGiven.copy()

    for i in range(0, len(newList)):
        newList[i] = str(listGiven.index(newList[i]))

    return newList

#User selects a role after signing up
def role(username):
    roles = ["admin", "student", "teacher", "staff"]
    role = input("\033[33mI am signing up as (Enter 1, 2, 3 or 4): \033[0m")

    newList = indexList(roles)

    if str(int(role)-1) in newList:

        success, errorMessage, roleDictionary = extra.loadDatabase(f"{roles[int(role)-1]}db.csv", False)

        if not success:
            print(f"\033[31m{errorMessage}\033[0m")
            homepage()
            return
        else:
            ignoreList = ["coursedb.csv", "cgpa", "enrolment_status", "academic_performance", "fees_outstanding", "fees_paid", "next_payment_date", "classdb.csv", "userdb.csv"]

            length = len(list(roleDictionary)[0][2:])
            amount = str(len(roleDictionary))
            newID = list(roleDictionary)[0][:2] + ("0" * (length - len(amount))) + str(int(amount) + 1)

            template = roleDictionary[list(roleDictionary)[0]]
            record = template.copy()

            for i in record:
                if type(record[i]) is list:
                    record[i] = []
                elif type(record[i]) is dict:
                    record[i] = {}
                elif type(record[i]) is int:
                    record[i] = 0
                else:
                    record[i] = "N/A"

            for i in record:
                if i in ignoreList:
                    if type(record[i]) is list:
                        record[i] = []
                    elif type(record[i]) is dict:
                        record[i] = "N/A"
                    elif type(record[i]) is int:
                        record[i] = 0
                    else:
                        record[i] = "N/A"
            record["userdb.csv"] = username
            roleDictionary.update({newID : record})

            success = extra.modifyRecord(roleDictionary, newID, ignoreList)
            if not success:
                print("\033[31mError when inputting values.\033[0m")
                homepage()
                return
            else:
                print("\033[32mAction complete ✅\033[0m")

                success, errorMessage = extra.saveData(roleDictionary, f"{roles[int(role) - 1].lower()}db.csv")
                if not success:
                    print(f"\033[31m{errorMessage}\033[0m")
                else:
                    print("\033[32mRegistration complete ✅\033[0m")
                    homepage()
                    return
    else:
        print("\033[31mPlease enter either 1, 2, 3 or 4.\033[0m")
        role(username)
        return

def login():
    loginUser = input("\033[33mUsername (Enter '0' to RETURN): \033[0m")
    if loginUser == "0":
        homepage()
    if len(loginUser) == 0:
        print("\033[31mPlease enter your username.\033[0m")
        login()


    user_found = False
    password = ""

    try:

        with open('userdb.csv', 'r',encoding='utf-8-sig') as file:
            for line in file:
                user_data = line.strip().split(',')
                if user_data[0] == loginUser:
                    user_found = True
                    password = user_data[1]
                    break

        if not user_found:
            print("\033[31mUsername does not exist. Please sign up first.\033[0m")
            homepage()

        while True:
            entered_password = input("\033[33mEnter your password: \33[0m")

            if entered_password == password:
                print("\033[42m\033[30m>>>>> Login successful <<<<<\033[0m")

                user, role, errorMessage = extra.checkUserExistence(loginUser)

                if errorMessage:
                    print(f"\033[31m{errorMessage}\033[0m")
                else:
                    if type(role) == list and type(role[0]) == str:
                        if role[0].split("db.csv")[0] == "admin":
                            admin.admin()
                        elif role[0].split("db.csv")[0] == "student":
                            student.student(role[2])
                        elif role[0].split("db.csv")[0] == "teacher":
                            teacher.teacher(role[2])
                        elif role[0].split("db.csv")[0] == "staff":
                            staff.staff()
                break
            else:
                print("\033[31mPassword is incorrect.\033[0m")

    except FileNotFoundError:
        print("\033[31mThe user database file does not exist.\033[0m")
    except Exception as e:
        print(f"\033[31mAn error occurred: {e}\033[0m")

homepage()