def changeDataType(dictionary_to_change):
    for i in dictionary_to_change:
        found_symbol = False
        if "@" in i: found_symbol = True

        if not found_symbol:
            try:
                int(dictionary_to_change[i])
            except (ValueError, TypeError):
                pass
            else:
                dictionary_to_change[i] = int(dictionary_to_change[i])

def readRecord(dictionary, header, lines, includeID):
    success = True
    if len(lines) < 1:
        success = False
        return success, "No data found in database"

    increment = 1
    increment += len(header)-len(lines[0].strip().strip("\n").split(","))

    for i in range(0, len(lines), increment):
        line = lines[i]
        attributes = line.strip().split(",", len(header)-1)

        if includeID == True:
            row_dict = {header[i]: attributes[i] for i in range(0, len(attributes))}
        else:
            row_dict = {header[i]: attributes[i] for i in range(1, len(attributes))}

        for j in range(1, increment):
            extraCount = j + i
            extraLine = lines[extraCount]

            extraLine_attributes = extraLine.strip().split(",")

            if extraLine_attributes[0] in header:
                current_header = header[len(attributes) + j - 1]
                found_list = []

                for l in range(1, len(extraLine_attributes)):
                    found_list.append(extraLine_attributes[l])
                new_row = {current_header: found_list}
                row_dict.update(new_row)
            else:
                if extraLine_attributes[0] != "None":
                    success = False
                    return success, f"{extraLine_attributes[0]} is not found in list of attributes.", None

        changeDataType(row_dict)

        new_row = {attributes[0]: row_dict}
        dictionary.update(new_row)

    return success, None, dictionary

def loadDatabase(path, includeID):
    success = True
    dictionary = {}

    try:
        open(path, "r")
    except FileNotFoundError as e:
        success = False
        return success, e, None

    with open(path, "r", encoding='utf-8-sig') as database:
        header = database.readline().strip().split(",")
        lines = database.readlines()
        readSuccess, errorMessage, readDictionary = readRecord(dictionary, header, lines, includeID)
        if not readSuccess:
            return readSuccess, errorMessage, None

    for i in header:
        if i[-6:] == "db.csv":
            attributeDictionary = {}

            with open(i, "r", encoding='utf-8-sig') as attributeDatabase:
                attributeHeader = attributeDatabase.readline().strip().split(",")
                attributeLines = attributeDatabase.readlines()
                csvSuccess, errorMessage, csvDictionary = readRecord(attributeDictionary, attributeHeader, attributeLines, True)
                if not csvSuccess:
                    return csvSuccess, errorMessage, None

            if type(readDictionary[list(readDictionary.keys())[0]][i]) is list:
                for record in readDictionary:
                    new_table = []
                    for listID in readDictionary[record][i]:
                       if listID != "N/A":
                            found_record = csvDictionary[listID]
                            new_table.append(found_record)
                    readDictionary[record][i] = new_table
            else:
                for record in readDictionary:
                    if readDictionary[record][i] != "N/A":
                        try:
                            csvDictionary[readDictionary[record][i]]
                        except KeyError as e:
                            return success, e, None
                        else:
                            readDictionary[record][i] = csvDictionary[readDictionary[record][i]]

    return success, None, readDictionary

def modifyRecord(dictionary, id, ignoreList):
    success = True
    try:
        dictionary[id]
    except KeyError as e:
        success = False
        return success, e

    current_row = dictionary[id]
    print("Enter '/' to return.")

    def enter_new(key):
        data = current_row[key]
        data_type = type(data)
        if data_type is int:
            new_input = input(f"Enter new \033[1m{key.lower().strip("@")}\033[0m (Value: integer): ").strip()
            if new_input == "/":
                return False
            try:
                int(new_input)
            except ValueError:
                print('\033[31m!! Warning: please enter the correct data type. Current data type is an integer. !!\033[0m')
                enter_new(key)
                return
        elif data_type is list:
            new_input = []
            stop = False
            length = len(data)
            while stop == False:

                list_input = input(f"Enter new values for \033[1m{key.lower().strip("@")}\033[0m (Type  '/'  to finish entering values): ").strip()
                if not key.strip("@") == key:
                    try:
                        int(list_input)
                    except ValueError:
                        pass
                    else:
                        list_input = int(list_input)

                if list_input != "/":
                    new_input.append(list_input)
                else:
                    stop = True

        elif data_type is dict:
            print("Enter 'N/A' if data is currently unavailable.")
            new_input = input(f"Enter new \033[1m{key.lower().strip("@")}\033[0m (Value: ID of {key.split("db.csv")[0]} database): ").strip()
            if new_input == "/":
                return False
            success, errorMessage, dictionary = loadDatabase(key, True)
            if success and new_input != "N/A":
                try:
                    dictionary[new_input]
                except (KeyError, IndexError) as e:
                    return False
                else:
                    new_input = dictionary[new_input]
            else:
                print(f'\033[31m{errorMessage}\033[0m')
        else:
            new_input = input(f"Enter new \033[1m{key.lower().strip("@")}\033[0m: ").strip()
            if new_input == "/":
                return False

        current_row[key] = new_input
        return True

    for i in current_row:
        if ignoreList:
            if i not in ignoreList:
                success = enter_new(i)
                if not success:
                    break
        else:
            success = enter_new(i)
            if not success:
                break

    return success

def saveData(dictionary, path):
    success = True

    try:
        open(path, "r")
    except FileNotFoundError as e:
        success = False
        return success, e
    else:
        with open(path, "r", encoding='utf-8-sig') as database:
            header = database.readline().strip().split(",")

        lines = []
        lines.append(",".join(map(str, header)) + "\n")

        count = 0
        for id in dictionary:
            line = []
            extraLines = []
            line.append(id)
            for attribute_key in dictionary[id]:
                attribute_value = dictionary[id][attribute_key]
                if type(attribute_value) is list:
                    list_line = []
                    list_line.append(attribute_key)
                    for i in attribute_value:
                        if type(i) is dict:
                            list_line.append(i[list(i.keys())[0]])
                        else:
                            list_line.append(i)
                    extraLines.append(",".join(map(str, list_line)) + "\n")

                elif type(attribute_value) is dict:
                    attribute_value = attribute_value[list(attribute_value.keys())[0]]
                    line.append(attribute_value)
                else:
                    line.append(attribute_value)


            lines.append(",".join(map(str, line)) + "\n")

            count += 1

            for extraLine in extraLines:
                lines.append(extraLine)
                count += 1

        for i in range(0, len(lines)):
            if i == len(lines)-1:
                lines[i] = lines[i].strip("\n")

        with open(path, "w", encoding='utf-8-sig') as database:
            for i in lines:
                database.write(i)

    return success, None

def checkDict(success, dictionary, key):
    success = False

    for i in dictionary:
        if dictionary[i] == key:
            success = True
        elif type(dictionary[i]) is dict:
            checkDictSuccess = checkDict(success, dictionary[i], key)
            if checkDictSuccess:
                success = True

    return success

def checkDBExistence(key):
    success = False
    errorMessage = None
    path = None
    dictID = None
    found_fileName = None

    roles = ["course", "class", "classroom", "resources"]
    for i in roles:
        file_name = i.lower()
        file_name += "db.csv"
        readSuccess, errorMessage, dictionary = loadDatabase(file_name, False)
        if not readSuccess:
            return readSuccess, errorMessage, None
        else:
            for record in dictionary:
                if record == key:
                    success = True
                    path = dictionary
                    dictID = record
                    found_fileName = file_name
                    break

                attribute = dictionary[record][list(dictionary[record].keys())[0]]

                if attribute == key:
                    success = True
                    path = dictionary
                    dictID = record
                    found_fileName = file_name
                    break

    return success, errorMessage, found_fileName, path, dictID

def checkUserExistence(key):
    errorMessage = None
    path = None
    dictID = None
    roleID = None
    found_roleDictionary = None
    found_userDictionary = None
    userSuccess = False
    roleSuccess = False

    readSuccess, errorMessage, dictionary = loadDatabase("userdb.csv", False)
    if not readSuccess:
        return None, None, errorMessage
    else:
        for record in dictionary:
            if record == key:
                userSuccess = True
                found_userDictionary = dictionary
                dictID = record
                break

    roles = ["admin", "student", "teacher", "staff"]
    for i in roles:
        file_name = i.lower()
        file_name += "db.csv"
        readSuccess, errorMessage, roleDictionary = loadDatabase(file_name, False)
        if not readSuccess:
            return None, None, errorMessage
        else:
            for record in roleDictionary:
                if record == key:
                    roleSuccess = True
                    path = file_name
                    roleID = record
                    found_roleDictionary = roleDictionary

                if roleDictionary[record]["userdb.csv"][list(roleDictionary[record]["userdb.csv"])[0]] == key:
                    roleSuccess = True
                    path = file_name
                    roleID = record
                    found_roleDictionary = roleDictionary

    if userSuccess or roleSuccess:
        return ["userdb.csv", dictionary, dictID, userSuccess], [path, found_roleDictionary, roleID, roleSuccess], None
    else:
        return None, None, "Error in finding user/role."