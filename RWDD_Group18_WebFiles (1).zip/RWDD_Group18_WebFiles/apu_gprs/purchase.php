<?php
session_start();
include 'db_connect.php';

$user_id = $_SESSION['user_id'];
$cart = json_decode(file_get_contents("php://input"), true);

mysqli_begin_transaction($conn);

try {
    $totalCost = 0;
    $itemsForTransaction = [];

    foreach ($cart as $itemName => $qty) {
        $itemQuery = "SELECT item_id, item_cost, stock_quantity 
                      FROM shop_item 
                      WHERE item_name = '$itemName' 
                      FOR UPDATE";
        $item = mysqli_fetch_assoc(mysqli_query($conn, $itemQuery));

        if ($item['stock_quantity'] < $qty) {
            throw new Exception("Out of stock");
        }

        $totalCost += $item['item_cost'] * $qty;


        $itemsForTransaction[] = [
            'item_id' => $item['item_id'],
            'item_cost' => $item['item_cost'],
            'quantity' => $qty
        ];
    }

    $userQuery = "SELECT redeemable_points 
                  FROM user 
                  WHERE user_id = '$user_id' 
                  FOR UPDATE";
    $user = mysqli_fetch_assoc(mysqli_query($conn, $userQuery));

    if ($user['redeemable_points'] < $totalCost) {
        throw new Exception("Insufficient points");
    }

    mysqli_query($conn, "
        UPDATE user 
        SET redeemable_points = redeemable_points - $totalCost 
        WHERE user_id = '$user_id'
    ");

    foreach ($itemsForTransaction as $item) {
        mysqli_query($conn, "
            UPDATE shop_item 
            SET stock_quantity = stock_quantity - {$item['quantity']} 
            WHERE item_id = {$item['item_id']}
        ");

        for ($i = 0; $i < $item['quantity']; $i++) {
            mysqli_query($conn, "
                INSERT INTO transaction (user_id, item_id, points_spent, transaction_date) 
                VALUES ('$user_id', {$item['item_id']}, {$item['item_cost']}, CURDATE())
            ");
        }
    }

    mysqli_commit($conn);

    echo json_encode([
        "success" => true,
        "remaining_points" => $user['redeemable_points'] - $totalCost
    ]);

} catch (Exception $e) {
    mysqli_rollback($conn);
    echo json_encode([
        "success" => false,
        "error" => $e->getMessage()
    ]);
}
?>