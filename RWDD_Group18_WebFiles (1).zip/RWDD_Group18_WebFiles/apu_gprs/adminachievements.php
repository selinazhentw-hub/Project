<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>APU Green Points & Rewards System</title>
    <link rel="stylesheet" href="adminstyle.css">
</head>
<body>
    <?php 
        include 'adminsession.php' ;
        include 'adminheader.php';
    ?>
    <h1 style="font-family: 'Funnel Sans', sans-serif; text-align:center;">Create Achievement</h1>
    <h3 style="text-align: center;">Create new achievements for users to obtain</h3>
    <div class="create-challenge">
    <form method="POST" action="">
        <br>
        <label>Title</label><br>
        <input type="text" name="achievement_title" required><br>
        <br>
        <label>Condition</label><br>
        <textarea name="achievement_condition" rows="5" style="max-width:100%; box-sizing: border-box;" placeholder="How can users achieve this?"></textarea><br>
        <br><br><br><br><br>


        <div class="login-btm-btn">
            <button type="submit">Submit</button>
            <button type="reset">Reset</button>
        </div>
    </form>
    </div>

    <?php 
        include("db_connect.php");

        $error_message = "";

        if ($_SERVER["REQUEST_METHOD"] == "POST") {
            if (isset($_POST['achievement_title']) && isset($_POST['achievement_condition'])) {


                $sql = "INSERT INTO achievements (achievement_title, achievement_condition) VALUES ('$_POST[achievement_title]','$_POST[achievement_condition]')";
                if (mysqli_query($conn,$sql)){
                    echo "<script>alert('Successfully created new achievement');</script>";
                } else {
                    die(mysqli_error($conn));
                }
            }
        }
    ?>
</body>
</html>