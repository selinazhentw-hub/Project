<!DOCTYPE html>
<?php


  session_start();
      
      if (!isset($_SESSION['user_id'])) {
          header('Location: login.php'); 
          exit();
      }

      include 'db_connect.php';
  include 'userheader.php';

  $user_id = $_SESSION['user_id'];

  $userQuery = "SELECT redeemable_points FROM user WHERE user_id = '$user_id'";
  $userResult = mysqli_query($conn, $userQuery);
  $user = mysqli_fetch_assoc($userResult);

  $points = (int)$user['redeemable_points'];
?>

<html>
<head>
  <style>
    body {
      font-family: Arial, sans-serif;
      margin: 0;
      padding: 0;
      background-color: #f5f5f5;
    }
    
    h1 {
      text-align: center;
      margin-top: 20px;
      color: #333;
    }
    
    .points-info {
      text-align: center;
      margin: 10px 0 20px 0;
    }
    
    .points-badge {
      background-color: #e8f5e8;
      padding: 10px 20px;
      border-radius: 20px;
      display: inline-block;
      box-shadow: 0 2px 5px rgba(0,0,0,0.1);
      border: 1px solid #4CAF50;
    }
    
    .points-text {
      font-weight: bold;
      color: #2e7d32;
      font-size: 16px;
    }
    
    .shop {
      display: flex;
      flex-wrap: wrap;
      justify-content: center;
      gap: 20px;
      padding: 20px;
      max-width: 1200px;
      margin: 0 auto;
    }
    
    .shop-item {
      background: white;
      border-radius: 10px;
      box-shadow: 0 2px 5px rgba(0,0,0,0.1);
      width: 200px;
      padding: 15px;
      text-align: center;
      transition: transform 0.3s ease;
    }
    
    .shop-item:hover {
      transform: translateY(-5px);
    }
    
    .shop-item img {
      width: 100px;
      height: 100px;
      background: #ddd;
      margin-bottom: 10px;
      border-radius: 5px;
    }
    
    #item-name p {
      margin: 5px 0;
      font-weight: bold;
    }
    
    .price-control {
      display: flex;
      justify-content: center;
      align-items: center;
      gap: 10px;
      margin-top: 10px;
    }
    
    .price-control button {
      width: 30px;
      height: 30px;
      border: none;
      background: #4CAF50;
      color: white;
      border-radius: 50%;
      cursor: pointer;
      font-size: 16px;
    }
    
    .price-control button:hover {
      background: #45a049;
    }
    
    .price-control p {
      margin: 0;
      font-weight: bold;
      color: #333;
    }
    
    .cart-container {
      position: fixed;
      bottom: 20px;
      left: 50%;
      transform: translateX(-50%);
      width: 90%;
      max-width: 800px;
      background: white;
      border-radius: 10px;
      box-shadow: 0 -2px 10px rgba(0,0,0,0.1);
      padding: 15px;
      z-index: 1000;
      display: none;
    }
    
    .cart-header {
      display: flex;
      justify-content: space-between;
      align-items: center;
      margin-bottom: 10px;
    }
    
    .cart-title {
      font-size: 18px;
      font-weight: bold;
      color: #333;
    }
    
    .cart-content {
      max-height: 200px;
      overflow-y: auto;
      margin-bottom: 10px;
    }
    
    .cart-item {
      display: flex;
      justify-content: space-between;
      align-items: center;
      padding: 5px 0;
      border-bottom: 1px solid #eee;
    }
    
    .cart-item-name {
      flex-grow: 1;
    }
    
    .cart-item-qty {
      color: #666;
      margin-left: 10px;
    }
    
    .cart-footer {
      display: flex;
      justify-content: flex-end;
      gap: 10px;
    }
    
    .confirm-btn {
      padding: 8px 20px;
      background: #4CAF50;
      color: white;
      border: none;
      border-radius: 5px;
      cursor: pointer;
      font-size: 14px;
    }
    
    .confirm-btn:hover {
      background: #45a049;
    }
    
    .modal-overlay {
      display: none;
      position: fixed;
      top: 0;
      left: 0;
      width: 100%;
      height: 100%;
      background: rgba(0,0,0,0.5);
      z-index: 2000;
      justify-content: center;
      align-items: center;
    }
    
    .modal {
      background: white;
      border-radius: 10px;
      padding: 20px;
      width: 90%;
      max-width: 500px;
      max-height: 80vh;
      overflow-y: auto;
    }
    
    .modal-header {
      text-align: center;
      margin-bottom: 20px;
    }
    
    .modal-title {
      font-size: 20px;
      font-weight: bold;
      color: #333;
    }
    
    .order-items {
      margin-bottom: 20px;
    }
    
    .order-item {
      display: flex;
      justify-content: space-between;
      margin-bottom: 10px;
      padding-bottom: 10px;
      border-bottom: 1px solid #eee;
    }
    
    .order-total {
      text-align: right;
      font-size: 18px;
      font-weight: bold;
      color: #333;
      margin: 20px 0;
      padding-top: 10px;
      border-top: 2px solid #333;
    }
    
    .modal-footer {
      display: flex;
      justify-content: space-between;
      gap: 10px;
    }
    
    .modal-btn {
      padding: 10px 25px;
      border: none;
      border-radius: 5px;
      cursor: pointer;
      font-size: 14px;
      flex: 1;
    }
    
    .back-btn {
      background: #f44336;
      color: white;
    }
    
    .back-btn:hover {
      background: #d32f2f;
    }
    
    .purchase-btn {
      background: #4CAF50;
      color: white;
    }
    
    .purchase-btn:hover {
      background: #45a049;
    }
    
    .success-message {
      display: none;
      position: fixed;
      top: 0;
      left: 0;
      width: 100%;
      height: 100%;
      background: rgba(0,0,0,0.5);
      z-index: 3000;
      justify-content: center;
      align-items: center;
    }
    
    .success-content {
      background: white;
      border-radius: 10px;
      padding: 40px;
      text-align: center;
      max-width: 400px;
    }
    
    .success-icon {
      font-size: 48px;
      color: #4CAF50;
      margin-bottom: 20px;
    }
    
    .success-text {
      font-size: 18px;
      margin-bottom: 20px;
      color: #333;
    }
    
    .close-btn {
      padding: 10px 30px;
      background: #4CAF50;
      color: white;
      border: none;
      border-radius: 5px;
      cursor: pointer;
    }
    
    .error-message {
      display: none;
      position: fixed;
      top: 0;
      left: 0;
      width: 100%;
      height: 100%;
      background: rgba(0,0,0,0.5);
      z-index: 3000;
      justify-content: center;
      align-items: center;
    }
    
    .error-content {
      background: white;
      border-radius: 10px;
      padding: 40px;
      text-align: center;
      max-width: 400px;
    }
    
    .error-icon {
      font-size: 48px;
      color: #f44336;
      margin-bottom: 20px;
    }
    
    .error-text {
      font-size: 18px;
      margin-bottom: 20px;
      color: #333;
    }
    
    .error-close-btn {
      padding: 10px 30px;
      background: #f44336;
      color: white;
      border: none;
      border-radius: 5px;
      cursor: pointer;
    }
    
    .insufficient-points {
      color: #f44336;
      font-size: 14px;
      margin-top: 10px;
      text-align: center;
    }
  </style>
</head>
<body>
    <h1>Shop</h1>
    
    <div class="points-info">
        <div class="points-badge">
            <span id="pointsDisplay" class="points-text">
                Hi, your total point is <?php echo $points; ?>
            </span>
        </div>
    </div>
    
    <br>
    <div class="shop">
        <?php
        $itemQuery = "SELECT item_id, item_name, item_cost, stock_quantity, item_image
              FROM shop_item
              WHERE stock_quantity > 0";

        $itemResult = mysqli_query($conn, $itemQuery);

        while ($item = mysqli_fetch_assoc($itemResult)) {
        ?>
            <div class="shop-item"
                data-id="<?php echo $item['item_id']; ?>"
                data-name="<?php echo $item['item_name']; ?>"
                data-price="<?php echo $item['item_cost']; ?>">

                <div id="info">
                    <img src="<?php echo htmlspecialchars($item['item_image']); ?>" alt="<?php echo htmlspecialchars($item['item_name']); ?>">
                    <div id="item-name"><p><?php echo $item['item_name']; ?></p></div>
                </div>

                <div class="price-control">
                    <button onclick="decreaseQty(this)">-</button>
                    <p><?php echo $item['item_cost']; ?> Points</p>
                    <button onclick="increaseQty(this)">+</button>
                </div>
            </div>
        <?php } ?>
        </div>
    
    <div class="cart-container" id="cartContainer">
        <div class="cart-header">
            <div class="cart-title">Shopping Cart</div>
            <button class="confirm-btn" onclick="showOrderModal()">Confirm</button>
        </div>
        <div class="cart-content" id="cartContent">
            <div class="empty-cart">No items in cart</div>
        </div>
    </div>
    
    <div class="modal-overlay" id="orderModal">
        <div class="modal">
            <div class="modal-header">
                <div class="modal-title">Order Confirmation</div>
            </div>
            <div class="order-items" id="orderItems">
            </div>
            <div class="order-total" id="orderTotal">
                Total: 0 Points
            </div>
            <div id="insufficientPoints" class="insufficient-points" style="display: none;">
                Insufficient points! You need <span id="neededPoints"></span> points but only have <span id="currentPoints"></span>.
            </div>
            <div class="modal-footer">
                <button class="modal-btn back-btn" onclick="closeOrderModal()">Back</button>
                <button class="modal-btn purchase-btn" onclick="purchaseItems()">Confirm Purchase</button>
            </div>
        </div>
    </div>
    
    <div class="success-message" id="successMessage">
        <div class="success-content">
            <div class="success-icon">✓</div>
            <div class="success-text">
                Congratulations! Purchase successful.<br>
                Please go to school counter to receive product.
            </div>
            <button class="close-btn" onclick="closeSuccessMessage()">OK</button>
        </div>
    </div>
    
    <div class="error-message" id="errorMessage">
        <div class="error-content">
            <div class="error-icon">✗</div>
            <div class="error-text">
                Purchase failed!<br>
                Insufficient points.
            </div>
            <button class="error-close-btn" onclick="closeErrorMessage()">OK</button>
        </div>
    </div>
    
    <script>
    let x = <?php echo $points; ?>;
    
    let cart = {};
    
    document.addEventListener('DOMContentLoaded', function() {
        updatePointsDisplay();
    });
    
    function updatePointsDisplay() {
        document.getElementById('pointsDisplay').textContent = `Hi, your total point is ${x}`;
    }
    
    function increaseQty(btn) {
        const item = btn.closest('.shop-item');
        const itemName = item.dataset.name;
        
        if (!item.dataset.qty) {
            item.dataset.qty = 0;
        }
        
        item.dataset.qty = parseInt(item.dataset.qty) + 1;
        
        if (cart[itemName]) {
            cart[itemName]++;
        } else {
            cart[itemName] = 1;
        }
        
        updateCartDisplay();
    }
    
    function decreaseQty(btn) {
        const item = btn.closest('.shop-item');
        const itemName = item.dataset.name;
        
        if (!item.dataset.qty) {
            item.dataset.qty = 0;
        }
        
        let qty = parseInt(item.dataset.qty);
        if (qty > 0) {
            item.dataset.qty = qty - 1;
            
            if (cart[itemName] && cart[itemName] > 0) {
                cart[itemName]--;
                if (cart[itemName] === 0) {
                    delete cart[itemName];
                }
            }
            
            updateCartDisplay();
        }
    }
    
    function updateCartDisplay() {
        const cartContent = document.getElementById('cartContent');
        const cartContainer = document.getElementById('cartContainer');
        
        cartContent.innerHTML = '';
        
        let totalItems = 0;
        Object.keys(cart).forEach(itemName => {
            totalItems += cart[itemName];
        });
        
        if (totalItems > 0) {
            Object.keys(cart).forEach(itemName => {
                if (cart[itemName] > 0) {
                    const itemDiv = document.createElement('div');
                    itemDiv.className = 'cart-item';
                    itemDiv.innerHTML = `
                        <div class="cart-item-name">${itemName}</div>
                        <div class="cart-item-qty">x${cart[itemName]}</div>
                    `;
                    cartContent.appendChild(itemDiv);
                }
            });
            
            cartContainer.style.display = 'block';
        } else {
            cartContent.innerHTML = '<div class="empty-cart">No items in cart</div>';
            cartContainer.style.display = 'none';
        }
    }
    
    function showOrderModal() {
        const orderItems = document.getElementById('orderItems');
        const orderTotal = document.getElementById('orderTotal');
        const insufficientPoints = document.getElementById('insufficientPoints');
        const modal = document.getElementById('orderModal');
        
        orderItems.innerHTML = '';
        
        let totalPrice = 0;
        
        Object.keys(cart).forEach(itemName => {
            if (cart[itemName] > 0) {
                const itemElement = document.querySelector(`.shop-item[data-name="${itemName}"]`);

                const itemPrice = parseInt(itemElement.dataset.price);
                const itemTotal = itemPrice * cart[itemName];
                totalPrice += itemTotal;
                
                const orderItem = document.createElement('div');
                orderItem.className = 'order-item';
                orderItem.innerHTML = `
                    <div>${itemName} x${cart[itemName]}</div>
                    <div>${itemTotal} Points</div>
                `;
                orderItems.appendChild(orderItem);
            }
        });
        
        orderTotal.textContent = `Total: ${totalPrice} Points`;
        
        if (totalPrice > x) {
            insufficientPoints.style.display = 'block';
            document.getElementById('neededPoints').textContent = totalPrice;
            document.getElementById('currentPoints').textContent = x;
        } else {
            insufficientPoints.style.display = 'none';
        }
        
        modal.style.display = 'flex';
    }
    
    function closeOrderModal() {
        const modal = document.getElementById('orderModal');
        modal.style.display = 'none';
    }
    
    function purchaseItems() {
        fetch('purchase.php', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(cart)
        })
        .then(res => res.json())
        .then(data => {
            if (data.success) {
                x = data.remaining_points;
                updatePointsDisplay();
                closeOrderModal();
                document.getElementById('successMessage').style.display = 'flex';
                cart = {};
                updateCartDisplay();
            } else {
                showErrorMessage();
            }
        });
    }
        
    function showErrorMessage() {
        const errorMessage = document.getElementById('errorMessage');
        errorMessage.style.display = 'flex';
    }
    
    function closeSuccessMessage() {
        const successMessage = document.getElementById('successMessage');
        successMessage.style.display = 'none';
    }
    
    function closeErrorMessage() {
        const errorMessage = document.getElementById('errorMessage');
        errorMessage.style.display = 'none';
    }
    
    window.onclick = function(event) {
        const modal = document.getElementById('orderModal');
        if (event.target === modal) {
            closeOrderModal();
        }
        
        const successMessage = document.getElementById('successMessage');
        if (event.target === successMessage) {
            closeSuccessMessage();
        }
        
        const errorMessage = document.getElementById('errorMessage');
        if (event.target === errorMessage) {
            closeErrorMessage();
        }
    }
    </script>
    
</body>
</html>