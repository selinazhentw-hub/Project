<!DOCTYPE html>
<?php 
    include("db_connect.php");

    if (isset($_POST['delete_item'])) {

        $item_name = mysqli_real_escape_string($conn, $_POST['item_name']);

        $sql_select = "SELECT item_image FROM shop_item WHERE LOWER(item_name) = LOWER('$item_name')";
        $result = mysqli_query($conn, $sql_select);

        if ($result && mysqli_num_rows($result) > 0) {
            $item = mysqli_fetch_assoc($result);
            $imagePath = $item['item_image'];

            if (!empty($imagePath) && file_exists($imagePath)) {
                unlink($imagePath);
            }

            $sql_delete = "DELETE FROM shop_item WHERE LOWER(item_name) = LOWER('$item_name')";
            if (mysqli_query($conn, $sql_delete)) {
                header("Location: adminshop.php?status=deleted");
                exit();
            } else {
                echo "Error deleting record: " . mysqli_error($conn);
            }

        } else {
            echo '<p style="text-align: center;">Item not found.</p>';
        }
    }
?>

<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>APU Green Points & Rewards System</title>
    <link rel="stylesheet" href="adminstyle.css">
</head>
<body>
    <?php 
        include 'adminsession.php' ;
        include 'adminheader.php';
    ?>
    <h3 style="text-align: left;">
        <a href="adminshop.php" style="text-decoration: underline; color: inherit;">
            Back to Shop
        </a>
    </h3>
    <h1 style="font-family: 'Funnel Sans', sans-serif; text-align:center;">Delete Existing Item</h1>
    <h3 style="text-align: center;">Remove an item from the shop</h3>
    <div class="delete-shopitem">
    <form method="POST" action="">
        <br>
        <label>Item Name</label><br>
        <label style="font-size: 12px;">Enter the item name so the system can find and delete it.</label>
        <input type="text" name="item_name" required><br>
        <br><br><br><br><br>


        <div class="login-btm-btn">
            <button type="submit" name="delete_item">Delete</button>
            <button type="reset" name="reset_item">Reset</button>
        </div>
    </form>
    </div>

    
</body>
</html>