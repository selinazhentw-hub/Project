<!DOCTYPE html>
<?php
    include('db_connect.php');
    $role = $_SESSION['role'] ?? '';
    $username = $_SESSION['admin_username'] ?? '';
    $user_id = $_SESSION['admin_id'] ?? '';
    $email = $_SESSION['admin_email'] ?? 'NOT SET';
    $phone_number = $_SESSION['admin_phone_number'] ?? 'NOT SET';
    $full_name = $_SESSION['admin_fullname'] ?? '';

    if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update_profile'])) {

        $admin_id = $_SESSION['admin_id'];

        $username = $_POST['username'];
        $email    = $_POST['email'];
        $phone    = $_POST['phone'];

        $sql = "
            UPDATE admin
            SET admin_username = ?, admin_email = ?, admin_phone_number = ?
            WHERE admin_id = ?
        ";

        $stmt = $conn->prepare($sql);
        $stmt->bind_param("sssi", $username, $email, $phone, $admin_id);
        $stmt->execute();

        $_SESSION['admin_username'] = $username;
        $_SESSION['admin_email'] = $email;
        $_SESSION['admin_phone_number'] = $phone;

        header("Location: " . $_SERVER['PHP_SELF']);
        exit;
    }

?>
<script>
    const adminUser = {
        role: "<?php echo $role; ?>",
        username: "<?php echo $username; ?>",
        user_id: "<?php echo $user_id; ?>",
        email: "<?php echo $email; ?>",
        phone_number: "<?php echo $phone_number; ?>",
        full_name: "<?php echo $full_name; ?>",
    };
</script>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <div id="header">
        <h1 id="web_title">APU Green Points & Reward System</h1>
        <div id="profile">
            <button type="button" name="goto_profile" value="profile" class="profile-btn">
                <img src="https://cdn-icons-png.flaticon.com/512/6522/6522516.png" alt="Profile" height="50" width="50">
                <span>Profile</span>
            </button>
        </div>
        
        <script>
            document.querySelector(".profile-btn").addEventListener("click", function () {
                const popout = document.getElementById("profile-popout");
                const blur = document.getElementById("blur-overlay");
                const show = popout.style.display !== "block";

                popout.style.display = (popout.style.display === "block") ? "none" : "block";
                blur.style.display = show ? "block" : "none";
            });

            document.addEventListener("click", function (e) {
                const popout = document.getElementById("profile-popout");
                const button = document.querySelector(".profile-btn");
                const blur = document.getElementById("blur-overlay");

                if (!button.contains(e.target) && !popout.contains(e.target)) {
                    popout.style.display = "none";
                    blur.style.display = "none";
                }
            });
        </script>
    </div>
    <div id="blur-overlay"></div>
    
    <div id="profile-popout" class="popout">
        <h2 style="text-align: center; padding: 0px;">Profile</h2>
        <h3 id="profile-title"></h3>
        <div class="profile-info">
            <img src="https://cdn-icons-png.flaticon.com/512/6522/6522516.png" alt="Profile" height="100" width="100">
            <div style="display: flex; flex-direction: column; align-items: left; margin-left: 5%; text-align: left;">
                <span id="profile-username"></span>
                <span id="profile-fullname"></span>
            </div>
        </div>
        <br>
        <div style="background-color: #77B77D; height: 5px; width: 100%"></div>
        <br>
        <h2>ID: <span id="profile-userid"></span></h2>
        <h2>Email: <span id="profile-email"></span></h2>
        <h2>Phone Number: <span id="profile-phone"></span></h2>
        <br>
        <div class="profile-popout-btn">
            <button type="button" id="update-profile-btn">Update Profile</button>
            <button type="button" id="logout-btn">Logout</button>
        </div>
    </div>

    <div id="update-profile-popout" class="update-profile-popout">
        <h2>Update Profile</h2>
        <form method="POST" class="update-profile-form">
            <label>Username</label>
            <input type="text" name="username" required>

            <label>Email</label>
            <input type="email" name="email" required>

            <label>Phone Number</label>
            <input type="tel" name="phone">

            <div class="form-divider"></div>

            <div class="update-profile-buttons">
                <button type="submit" name="update_profile" style="background-color: #77B77D;">Save Changes</button>
                <button type="button" class="update-profile-cancel" id="cancel-update">Cancel</button>
            </div>
        </form>
    </div>

    <div id="ribbon">
        <script>
            const pages = [
                { name: "Dashboard", link: "admindashboard.php"},               
                { name: "Leaderboard", link: "adminleaderboard.php" },
                { name: "Shop", link: "adminshop.php"},
                { name: "Create Challenge", link: "adminchallenges.php"},
                { name: "Create Achievement", link: "adminachievements.php"},
                { name: "Award Points", link: "award_points.php"},
                { name: "Account Requests", link: "account_request.php"},
                
            ];

            const container = document.getElementById("ribbon");

            pages.forEach(page => {
                const btn = document.createElement("button");
                btn.type = "button";
                btn.textContent = page.name;
                btn.classList.add("ribbon-btn");
                btn.style.margin = "4px";
                btn.onclick = () => window.location.href = page.link;
                container.appendChild(btn);
            });
        </script>
    </div>

    <script>
        document.getElementById('profile-title').textContent = adminUser.role;
        document.getElementById('profile-username').textContent = adminUser.username;
        document.getElementById('profile-userid').textContent = adminUser.user_id;
        document.getElementById('profile-email').textContent = adminUser.email;
        document.getElementById('profile-phone').textContent = adminUser.phone_number;
        document.getElementById('profile-fullname').textContent = adminUser.full_name;

        document.getElementById('logout-btn').addEventListener('click', function() {
            window.location.href = 'logout.php';
        });

        document.getElementById('update-profile-btn').addEventListener('click', function(e) {
            e.preventDefault();
            e.stopPropagation();
            
            document.getElementById('profile-popout').style.display = 'none';
            document.getElementById('blur-overlay').style.display = 'none';
            
            const updatePopout = document.getElementById('update-profile-popout');
            const blur = document.getElementById('blur-overlay');
            updatePopout.style.display = 'block';
            blur.style.display = 'block';
        });

        document.getElementById('cancel-update').addEventListener('click', function() {
            hideUpdateProfilePopout();
        });

        function hideUpdateProfilePopout() {
            const updatePopout = document.getElementById('update-profile-popout');
            const blur = document.getElementById('blur-overlay');
            updatePopout.style.display = 'none';
            blur.style.display = 'none';
        }

        document.getElementById('blur-overlay').addEventListener('click', function() {
            hideUpdateProfilePopout();
            document.getElementById('profile-popout').style.display = 'none';
            this.style.display = 'none';
        });
    </script>
</body>
</html>