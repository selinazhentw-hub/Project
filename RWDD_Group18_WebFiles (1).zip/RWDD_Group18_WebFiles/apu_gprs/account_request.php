<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>APU Green Points & Rewards System</title>
    <link rel="stylesheet" href="adminstyle.css">
</head>
<body>
    <?php 
        include 'adminsession.php' ;
        include 'adminheader.php';
    ?>
    <h1 style="font-family: 'Patrick Hand SC', sans-serif; text-align:left;">Account Activation Requests</h1>
    <h3>Verify user ID and accept/reject a new user account activation request.</h3>        
    <br>
    <div class="award-points">
        <div class="staff-request-title">
            <p>User ID</p>
            <p>Username</p>
            <p>Password</p>
            <p style="text-align: right;">Action</p>
        </div>

        <?php
            include('db_connect.php');

            $sql = "SELECT user_id, username, user_password 
                    FROM user 
                    WHERE account_status = 'Pending'";

            $result = mysqli_query($conn, $sql);

            if (mysqli_num_rows($result) > 0) {
                while ($row = mysqli_fetch_assoc($result)) {
            ?>
                <div class="staff-request">
                    <p><?php echo $row['user_id']; ?></p>
                    <p><?php echo $row['username']; ?></p>
                    <p><?php echo $row['user_password']; ?></p>

                    <div class="staff-request-action">
                        <form method="POST" action="">
                            <input type="hidden" name="user_id" value="<?php echo $row['user_id']; ?>">

                           <button type="button" id="approve" onclick="openApprovePopout('<?php echo $row['user_id']; ?>')">Accept</button>
                            <button type="submit" name="reject_request" id="reject">Reject</button>
                        </form>
                    </div>
                </div>
        <?php
            }
        } else {
            echo '<p style="text-align: center;">No pending account requests.</p>';
        }
        ?>
    </div>

    <?php 
        include('db_connect.php');

        if (isset($_POST['confirm_approve'])) {

            $user_id = $_POST['user_id'];
            $fullname = $_POST['user_fullname'];
            $age = $_POST['user_age'];

            $sql = "UPDATE user
                    SET user_fullname = '$fullname',
                        user_age = '$age',
                        account_status = 'Approved'
                    WHERE user_id = '$user_id'";

            mysqli_query($conn, $sql);

            echo "<script>
                    alert('User approved successfully');
                    window.location.href = 'admindashboard.php';
                </script>";
        }

        if (isset($_POST['reject_request'])) {

            $user_id = $_POST['user_id'];

            $sql = "UPDATE user
                    SET account_status = 'Rejected'
                    WHERE user_id = '$user_id'";

            mysqli_query($conn, $sql);

            echo "<script>
                    alert('User rejected');
                    window.location.href = 'account_request.php';
                </script>";
        }
    ?>

    <div id="approvePopout" class="update-profile-popout">
        <h2>Approve User Account</h2>

        <form method="POST" class="update-profile-form">
            <input type="hidden" name="user_id" id="approve_user_id">

            <label>Full Name</label>
            <input type="text" name="user_fullname" required placeholder="Enter full name">

            <label>Age</label>
            <input type="number" name="user_age" min="1" required placeholder="Enter age">

            <div class="form-divider"></div>

            <div class="update-profile-buttons">
                <button type="submit" name="confirm_approve" class="update-profile-save">
                    Confirm
                </button>
                <button type="button" class="update-profile-cancel" onclick="closeApprovePopout()">
                    Cancel
                </button>
            </div>
        </form>
    </div>
    <script>
        function openApprovePopout(userId) {
            document.getElementById("approve_user_id").value = userId;
            document.getElementById("approvePopout").style.display = "block";
        }

        function closeApprovePopout() {
            document.getElementById("approvePopout").style.display = "none";
        }
    </script>
</body>
</html>