<?php 
    session_start();

    if (!isset($_SESSION['user_id']) || ($_SESSION['role'] ?? '') !== 'user') {
        header('Location: login.php');
        exit();
    }
?>

<!DOCTYPE html>
<html>
<head>
  <?php 
    include 'userheader.php';
  
  ?>

</head>
<body>
    <h1>History</h1>

    <div class="history-container">

    <div class="history-filter-box">
        <div class="date-row">
            <div class="date-field">
                <label><b>Start Date:</b></label>
                <input type="date" id="startDate">
            </div>
    
            <div class="date-field">
                <label><b>End Date:</b></label>
                <input type="date" id="endDate">
            </div>
        </div>
    
        <button id="filterBtn" class="filter-btn">Apply Filter</button>
        <button id="clearBtn" class="filter-btn">Clear</button>
    </div>

        <div class="history-list" id="historyList">
            <?php
            include 'db_connect.php';
            $user_id = $_SESSION['user_id'];
            if ($user_id !== '') {
                $sql = "SELECT history_title, history_description, history_date 
                        FROM history 
                        WHERE user_id = ? 
                        ORDER BY history_date DESC";
                $stmt = $conn->prepare($sql);
                $stmt->bind_param("s", $user_id);
                $stmt->execute();
                $result = $stmt->get_result();
                if ($result->num_rows > 0) {
                    while($row = $result->fetch_assoc()) {
                        $formatted_date = date('d M Y', strtotime($row['history_date']));
                        $iso_date = date('Y-m-d', strtotime($row['history_date']));
                        
                        echo '<div class="history-entry" data-date="' . $iso_date . '">';
                        echo '<p class="h-title">' . htmlspecialchars($row['history_title']) . '</p>';
                        echo '<p class="h-desc">' . htmlspecialchars($row['history_description']) . '</p>';
                        echo '<p class="h-date">' . $formatted_date . '</p>';
                        echo '</div>';
                    }
                } else {
                    echo '<div class="history-entry">';
                    echo '<p class="h-title">No history records found.</p>';
                    echo '<p class="h-desc">You don\'t have any history records yet.</p>';
                    echo '</div>';
                }
                $stmt->close();
                $conn->close();
            } 
            ?>
        </div>
    </div>

    <script>
        document.getElementById("filterBtn").addEventListener("click", () => {
            const start = document.getElementById("startDate").value;
            const end = document.getElementById("endDate").value;

            const entries = document.querySelectorAll(".history-entry");

            entries.forEach(entry => {
                const entryDate = entry.getAttribute("data-date");

                let show = true;

                if (start && entryDate < start) show = false;
                if (end && entryDate > end) show = false;

                entry.style.display = show ? "block" : "none";
            });
        });

        document.getElementById("clearBtn").addEventListener("click", () => {
            document.getElementById("startDate").value = "";
            document.getElementById("endDate").value = "";
            
            const entries = document.querySelectorAll(".history-entry");
            entries.forEach(entry => {
                entry.style.display = "block";
            });
        });
        
        document.addEventListener('DOMContentLoaded', function() {
            const today = new Date().toISOString().split('T')[0];
            document.getElementById('endDate').value = today;
            
            const thirtyDaysAgo = new Date();
            thirtyDaysAgo.setDate(thirtyDaysAgo.getDate() - 30);
            document.getElementById('startDate').value = thirtyDaysAgo.toISOString().split('T')[0];
        });
    </script>

</body>
</html>