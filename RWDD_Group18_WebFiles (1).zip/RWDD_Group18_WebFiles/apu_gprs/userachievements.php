<?php
    session_start();

    if (!isset($_SESSION['user_id'])) {
        header("Location: login.php");
        exit();
    }

    include 'db_connect.php';
?>
<!DOCTYPE html>
<html>
<head>
  <?php include 'userheader.php';?>
</head>
<body>
    <h1 style="text-align: left; margin-top: 20px;">Achievements</h1>
    <p style="text-align: left; margin-top: 20px;">Pick a title to be displayed on your profile 🌟</p>
    
    <div class="achievements">
        <?php
        
        $user_id = $_SESSION['user_id']; 
        
        $sql = "SELECT 
                    a.achievement_id,
                    a.achievement_title, 
                    a.achievement_condition,
                    ua.achievement_status,
                    ua.unlocked_date
                FROM achievements a
                LEFT JOIN user_achievements ua ON a.achievement_id = ua.achievement_id 
                    AND ua.user_id = ?
                ORDER BY a.achievement_id";
        
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("i", $user_id);
        $stmt->execute();
        $result = $stmt->get_result();
        
        if ($result->num_rows > 0) {
            while($row = $result->fetch_assoc()) {
                $title = htmlspecialchars($row['achievement_title']);
                $condition = htmlspecialchars($row['achievement_condition']);
                $status = $row['achievement_status'];
                $unlocked_date = $row['unlocked_date'];
                $is_unlocked = ($status === 'Unlocked' || $status === 'Selected');
                $is_selected = ($status === 'Selected');
                
                $formatted_date = '';
                if ($unlocked_date) {
                    $date = new DateTime($unlocked_date);
                    $formatted_date = $date->format('F j, Y');
                }
                ?>
                <div class="achievement-card">
                    <div class="achievement-header">
                        <p class="a-title"><?php echo $title; ?></p>
                    </div>
                    <div class="achievement-body">
                        <p class="a-desc"><?php echo $condition; ?></p>
                    </div>
                    
                    <?php if ($is_unlocked && $formatted_date): ?>
                        <p style="text-align: center; font-family: 'Funnel Sans', sans-serif; font-size: 12px; color: #77B77D; margin: 5px 0;">
                            Unlocked on: <?php echo $formatted_date; ?>
                        </p>
                    <?php endif; ?>
                    
                    <button 
                        class="select-btn <?php echo $is_unlocked ? 'unlocked' : 'locked'; ?> <?php echo $is_selected ? 'selected' : ''; ?>"
                        <?php echo $is_unlocked ? '' : 'disabled'; ?>
                        data-achievement-id="<?php echo $row['achievement_id']; ?>"
                    >
                        <?php
                            if ($is_selected) echo 'Selected';
                            elseif ($is_unlocked) echo 'Select';
                            else echo 'Locked';
                        ?>
                    </button>
                </div>
                <?php
            }
        } else {
            echo "<p>No achievements yet.</p>";
        }
        
        $stmt->close();
        $conn->close();
        ?>
    </div>

    <script>
        const buttons = document.querySelectorAll(".select-btn.unlocked");

        buttons.forEach(btn => {
            btn.addEventListener("click", () => {
                const achievementId = btn.dataset.achievementId;
                const isSelected = btn.classList.contains("selected");

                fetch("select_achievement.php", {
                    method: "POST",
                    headers: { "Content-Type": "application/x-www-form-urlencoded" },
                    body: "achievement_id=" + achievementId + "&toggle=" + (isSelected ? "off" : "on")
                })
                .then(() => {
                    buttons.forEach(b => {
                        b.classList.remove("selected");
                        b.textContent = "Select";
                    });

                    if (!isSelected) {
                        btn.classList.add("selected");
                        btn.textContent = "Selected";
                    }
                });
            });
        });
        </script>

</body>
</html>