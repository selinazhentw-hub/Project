﻿<?php
session_start();

if (!isset($_SESSION['staff_id'])) {
    header("Location: login.php");
    exit();
}

include("db_connect.php");

if (isset($_POST['reason']) && isset($_GET['action_id'])) {

    $actionId = $_GET['action_id'];
    $reason = mysqli_real_escape_string($conn, $_POST['reason']);

    $staffId = $_SESSION['staff_id'];

    $getActionSql = "SELECT user_id, action_desc FROM eco_action WHERE action_id = $actionId";
    $actionResult = mysqli_query($conn, $getActionSql);
    $actionData = mysqli_fetch_assoc($actionResult);

    $userId = $actionData['user_id'];
    $actionDesc = $actionData['action_desc'];

    $sql = "UPDATE eco_action 
            SET action_status = 'Rejected',
                rejection_reason = '$reason',
                staff_id = $staffId
            WHERE action_id = $actionId";

    mysqli_query($conn, $sql);

    $historyTitle = "Eco Action Rejected";
    $historyDescription = "$actionDesc was rejected by staff.";

    $historySql = "INSERT INTO history (
                        history_title,
                        history_description,
                        history_date,
                        user_id
                   ) VALUES (
                        '$historyTitle',
                        '$historyDescription',
                        CURDATE(),
                        '$userId'
                   )";

    mysqli_query($conn, $historySql);

    header("Location: ecoactions.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>APU Green Points & Rewards System</title>
    <link rel="stylesheet" href="staffstyle.css?v=2">

</head>
<body>
    <?php include('staffheader.php'); ?>

<h2 style="margin-left:20px; margin-top:20px; color: black; ">Eco Actions</h2>

<?php
$actionId = $_GET['action_id'] ?? null;
$selectedAction = null;

if ($actionId) {
    $sql = "SELECT * FROM eco_action WHERE action_id = $actionId";
    $result = mysqli_query($conn, $sql);
    $selectedAction = mysqli_fetch_assoc($result);
} else {
    $sql = "SELECT * FROM eco_action WHERE action_status = 'Pending'";
    $result = mysqli_query($conn, $sql);
}
?>

<div style="padding:20px;">

<?php if ($selectedAction): ?>

    <div style="
        background:white; padding:20px; border-radius:15px;
        margin-bottom:20px; box-shadow:0 0 15px rgba(0,0,0,0.15);
    ">
        <h3>Selected Eco Action</h3>
        <p><strong>Action:</strong> <?= $selectedAction['action_desc']; ?></p>
        <p><strong>Bag Number:</strong> <?= $selectedAction['bag_num']; ?></p>
        <p><strong>Date:</strong> <?= $selectedAction['action_date']; ?></p>
    </div>

    <form method="POST"
          action="ecoactions.php?action_id=<?= $actionId ?>"
          style="
            background:white; padding:20px; border-radius:15px;
            max-width:600px; margin:auto;
            box-shadow:0 0 15px rgba(0,0,0,0.15);
          ">

        <h3>Rejection Details</h3>

        <label><strong>Rejection Reason:</strong></label>
        <textarea name="reason" rows="4" required
                  style="width:100%; padding:10px; margin-bottom:15px; border-radius:8px;"></textarea>

        <button type="submit" class="ribbon-btn"
                style="width:200px; height:45px; font-size:18px;">
            Send
        </button>

    </form>


<?php else: ?>

    <h3>List of Eco Actions:</h3>

    <div class="table-container">

        <table class="eco-table" style="width:100%;border-collapse:collapse;background:white;">
    <tr>
        <th>Eco Action</th>
        <th>Bag Number</th>
        <th>Date</th>
        <th>Action</th>
    </tr>

            <?php while ($action = mysqli_fetch_assoc($result)): ?>
            <tr>
                <td><?= $action["action_desc"] ?></td>
                <td><?= $action["bag_num"] ?></td>
                <td><?= $action["action_date"] ?></td>
                <td>
                    <a href="ecoactions.php?action_id=<?= $action['action_id'] ?>">
                        <button class="ribbon-btn" style="width:120px; height:40px; font-size:16px;">
                            Reject
                        </button>
                    </a>
                </td>
            </tr>
            <?php endwhile; ?>

        </table>

    </div>

<?php endif; ?>

</div>

</body>
</html>

</body>
</html>