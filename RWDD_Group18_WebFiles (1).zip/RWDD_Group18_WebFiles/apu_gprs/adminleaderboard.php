<!DOCTYPE html>
<?php 
    include('adminsession.php');
    include('db_connect.php');

    $all_users_query = "SELECT username, total_points FROM user ORDER BY total_points";
    $all_users_result = $conn->query($all_users_query);

    $top_users = [];
    if ($all_users_result && $all_users_result->num_rows > 0) {
        while ($row = $all_users_result->fetch_assoc()) {
            $top_users[] = $row;
        }
    }

    $conn->close();
?>
<html>
<head>
  <?php include 'adminheader.php'; ?>
  <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>APU Green Points & Rewards System</title>
    <link rel="stylesheet" href="adminstyle.css">
</head>
<body>
    <h1 style="text-align: left; margin-top: 20px;">Leaderboard</h1>
    
    <div class="content-box">
        <?php
        if (!empty($top_users)) {
            $display_rank = 1;
            foreach ($top_users as $user) {
                $is_first_place = ($display_rank == 1);
                
                echo '<div class="leaderboard-placing">';
                echo '<div style="display: flex; align-items: center; width: 100%;">';
                
                echo '<div class="rank-number" style="flex-shrink: 0;">';
                if ($is_first_place) {
                    echo '<img src="https://upload.wikimedia.org/wikipedia/commons/thumb/2/25/Simple_gold_crown.svg/768px-Simple_gold_crown.svg.png" 
                          style="width: 30px; height: 30px;" class="crown-icon" alt="Crown">';
                } else {
                    echo $display_rank . '.';
                }
                echo '</div>';
                
                echo '<div class="user-name" style="flex: 1;">';
                echo htmlspecialchars($user['username']);
                echo '</div>';
                
                echo '<div class="points-display" style="flex-shrink: 0;">' . number_format($user['total_points']) . ' pts</div>';
                
                echo '</div>'; 
                echo '</div>'; 
                
                $display_rank++;
            }
        } else {
            echo '<div class="empty-message" style="text-align:center; margin: 20px;">';
            echo 'No users found in the leaderboard.';
            echo '</div>';
        }
        ?>
    </div>
</body>
</html>