<?php
    session_start();
    include 'db_connect.php';

    if (!isset($_SESSION['user_id'], $_POST['achievement_id'])) {
        exit;
    }

    $user_id = $_SESSION['user_id'];
    $achievement_id = intval($_POST['achievement_id']);
    $toggle = $_POST['toggle'] ?? 'on';

    $sql = "UPDATE user_achievements
            SET achievement_status = 'Unlocked'
            WHERE user_id = ?
            AND achievement_status = 'Selected'";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $user_id);
    $stmt->execute();

    if ($toggle === 'on') {
        $sql = "UPDATE user_achievements
                SET achievement_status = 'Selected'
                WHERE user_id = ?
                AND achievement_id = ?
                AND achievement_status = 'Unlocked'";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("ii", $user_id, $achievement_id);
        $stmt->execute();
    }
?>