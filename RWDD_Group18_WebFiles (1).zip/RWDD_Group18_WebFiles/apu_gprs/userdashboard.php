<!DOCTYPE html>
<?php
    session_start();
    include 'db_connect.php';

    if (!isset($_SESSION['user_id'])) {
        header("Location: login.php");
        exit();
    }

    $user_id = $_SESSION['user_id'];
    $query = "SELECT total_points, redeemable_points FROM user WHERE user_id = ?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("i", $user_id);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        $user_data = $result->fetch_assoc();
        $total_points = $user_data['total_points'];
        $redeemable_points = $user_data['redeemable_points'];
    } else {
        $total_points = 0;
        $redeemable_points = 0;
    }

    $stmt->close();

    $sqlAchievements = "
    SELECT 
        a.achievement_title,
        a.achievement_condition,
        ua.unlocked_date
    FROM user_achievements ua
    JOIN achievements a
        ON ua.achievement_id = a.achievement_id
    WHERE ua.user_id = '$_SESSION[user_id]'
    ORDER BY ua.unlocked_date DESC
    ";


    $resultAchievements = mysqli_query($conn, $sqlAchievements);
?>
<html>
<head>
  <?php include 'userheader.php';?>
</head>
<body>

    <div id="dashboard" style="text-align: left;">
        <h1>Hello, <?php echo htmlspecialchars($_SESSION['username']); ?>!</h1>
        <h2>Total points obtained: <?php echo $total_points; ?></h2>
        <h2>Redeemable points: <?php echo $redeemable_points; ?></h2>
        <p>Redeem your points in the <a href="usershop.php">Shop</a> to get exciting rewards!</p>
    </div>

    <h2 style="margin:20px;">Achievements</h2>

    <div style="margin:20px;">
    <?php while ($row = mysqli_fetch_assoc($resultAchievements)): ?>

        <div style="
            background:white;
            padding:15px;
            margin-bottom:10px;
            border-radius:10px;
            border-left: 6px solid #2e7d32;
        ">
            <strong><?= $row['achievement_title'] ?></strong><br>
            <small><?= $row['achievement_condition'] ?></small><br>

            <span style="color:green; font-weight:bold;">
                Unlocked on <?= $row['unlocked_date'] ?>
            </span>
        </div>

    <?php endwhile; ?>
</body>
</html>