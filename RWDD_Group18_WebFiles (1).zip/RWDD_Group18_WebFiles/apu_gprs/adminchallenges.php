<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>APU Green Points & Rewards System</title>
    <link rel="stylesheet" href="adminstyle.css">
</head>
<body>
    <?php 
        include 'adminsession.php' ;
        include 'adminheader.php';
    ?>
    <h1 style="font-family: 'Funnel Sans', sans-serif; text-align:center;">Create Challenge</h1>
    <h3 style="text-align: center;">Create new challenges</h3>
    <div class="create-challenge">
    <form method="POST" action="">
        <br>
        <label>Title</label><br>
        <input type="text" name="challenge_title" required><br>
        <br>
        <label>Description</label><br>
        <textarea name="challenge_description" rows="5" style="max-width:100%; box-sizing: border-box;" placeholder="Give your challenge a description so challengers know more."></textarea><br>
        <label>Duration</label><br>
        <input type="number" name="challenge_duration" min="0" required> <label>Days</label>
        <br>
        <br><br><br><br><br>


        <div class="login-btm-btn">
            <button type="submit">Submit</button>
            <button type="reset">Reset</button>
        </div>
    </form>
    </div>

    <?php 
        include("db_connect.php");

        $error_message = "";

        if ($_SERVER["REQUEST_METHOD"] == "POST") {
            if (isset($_POST['challenge_title']) && isset($_POST['challenge_description']) && isset($_POST['challenge_duration']) && isset($_POST['challenge_category'])) {


                $sql = "INSERT INTO challenge (challenge_title, challenge_description, challenge_duration) VALUES ('$_POST[challenge_title]','$_POST[challenge_description]','$_POST[challenge_duration]')";
                if (mysqli_query($conn,$sql)){
                    echo "<script>alert('Successfully created new challenge');</script>";
                } else {
                    die(mysqli_error($conn));
                }
            }
        }
    ?>
</body>
</html>