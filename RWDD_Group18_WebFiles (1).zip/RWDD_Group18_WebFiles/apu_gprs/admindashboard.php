<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>APU Green Points & Rewards System</title>
    <link rel="stylesheet" href="adminstyle.css">
</head>
<body>
    <?php 
        include 'adminsession.php' ;
        include 'adminheader.php';
    ?>
    
    <div style="padding: 20px;">
        <h1 style="font-family: 'Patrick Hand SC', sans-serif; text-align:left;">Pending Staff Requests</h1>    
        <br>
        <div class="award-points">
            <div class="staff-request-title">
                <p>Staff Name</p>
                <p>Student Name</p>
                <p>Number of Points</p>
                <p style="text-align: right;">Approval / Rejection</p>
            </div>

            <?php
            include('db_connect.php');

            $sql = "SELECT action_id, action_date, user_id, point_requested, action_status
                    FROM eco_action
                    WHERE action_status = 'Requested'";

            $result = mysqli_query($conn, $sql);

            if (mysqli_num_rows($result) > 0) {
                while ($row = mysqli_fetch_assoc($result)) {
            ?>
                    <div class="staff-request">
                        <p><?php echo $row['action_date']; ?></p>
                        <p><?php echo $row['user_id']; ?></p>
                        <p><?php echo $row['point_requested']; ?></p>

                        <p style="text-align: right;"><?php echo $row['action_status']; ?></p>
                    </div>
            <?php
                }
            } else {
                echo '<p style="text-align:center; margin-top:20px;">
                        No pending award requests.
                    </p>';
            }
            ?>

        </div>
    </div>

    <h1 style="font-family: 'Patrick Hand SC', sans-serif; text-align:left;">Pending Account Activation Requests</h1>    
        <br>
    <div class="award-points">
        <div class="staff-request-title">
            <p>User ID</p>
            <p>Username</p>
            <p>Password</p>
            <p style="text-align: right;">Action</p>
        </div>

        <?php
            include('db_connect.php');

            $sql = "SELECT user_id, username, user_password, account_status 
                    FROM user 
                    WHERE account_status = 'Pending'";

            $result = mysqli_query($conn, $sql);

            if (mysqli_num_rows($result) > 0) {
                while ($row = mysqli_fetch_assoc($result)) {
            ?>
                <div class="staff-request">
                    <p><?php echo $row['user_id']; ?></p>
                    <p><?php echo $row['username']; ?></p>
                    <p><?php echo $row['user_password']; ?></p>

                    <p style="text-align: right;"><?php echo $row['account_status']; ?></p>
                </div>
        <?php
            }
        } else {
            echo '<p style="text-align: center;">No pending account requests.</p>';
        }
        ?>
    </div>

    
</body>
</html>