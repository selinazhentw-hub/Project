<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>APU Green Points & Rewards System</title>
    <link rel="stylesheet" href="adminstyle.css">
    <style> 
        #confirmapp {
            background-color: #77B77D;
            border: 2px solid #314b34;
        }

        #cancel {
            background-color: #9b4848;
            border: 2px solid #502525;
        }
    </style>
</head>
<body>
    <?php 
        include 'adminsession.php';
        include 'adminheader.php';
        include('db_connect.php');

        if (isset($_POST['final_approve'])) {

            $action_id = $_POST['action_id'];
            $user_id   = $_POST['user_id'];
            $achievements = $_POST['achievements'] ?? [];

            $sql = "SELECT point_requested, action_desc, action_date 
                    FROM eco_action WHERE action_id = '$action_id'";
            $result = mysqli_query($conn, $sql);
            $row = mysqli_fetch_assoc($result);

            $points = (int)$row['point_requested'];
            $action_description = $row['action_desc'];
            $history_title = "Eco Action";
            $history_description = $action_description . " (+" . $points . " points)";
            $history_date = $row['action_date'];

            mysqli_query($conn, "
                UPDATE user
                SET total_points = total_points + $points,
                    redeemable_points = redeemable_points + $points
                WHERE user_id = '$user_id'
            ");

            foreach ($achievements as $achievement_id) {
                mysqli_query($conn, "
                    INSERT INTO user_achievements (user_id, achievement_id, achievement_status, unlocked_date)
                    VALUES ('$user_id', '$achievement_id', 'Unlocked', NOW())
                ");
            }

            mysqli_query($conn, "
                UPDATE eco_action
                SET action_status = 'Approved'
                WHERE action_id = '$action_id'
            ");

            $insert_sql = "
                INSERT INTO history (
                    history_title,
                    history_description,
                    history_date,
                    user_id
                ) VALUES (
                    '$history_title',
                    '$history_description',
                    '$history_date',
                    '$user_id'
                )
            ";
            mysqli_query($conn, $insert_sql);

            echo "<script>
                alert('Eco action approved successfully');
                window.location.href='award_points.php';
            </script>";
            exit;
        }

        if (isset($_POST['reject_action'])) {
            $action_id = $_POST['action_id'];
            mysqli_query($conn, "
                UPDATE eco_action
                SET action_status = 'Rejected'
                WHERE action_id = '$action_id'
            ");
            echo "<script>
                alert('Points rejected');
                window.location.href = 'award_points.php';
            </script>";
            exit;
        }
    ?>

    <h1 style="font-family: 'Patrick Hand SC', sans-serif; text-align:left;">Award Points</h1>
    <h3>Award points to students by approving staff requests.</h3>
    <br>

    <div class="award-points">
        <div class="staff-request-title">
            <p>Staff Name</p>
            <p>Student ID</p>
            <p>Number of Points</p>
            <p style="text-align: right;">Approval / Rejection</p>
        </div>

        <?php
        $sql = "SELECT action_id, action_date, user_id, point_requested 
                FROM eco_action WHERE action_status = 'Requested'";
        $result = mysqli_query($conn, $sql);

        if (mysqli_num_rows($result) > 0) {
            while ($row = mysqli_fetch_assoc($result)) {
        ?>
                <div class="staff-request">
                    <p><?php echo $row['action_date']; ?></p>
                    <p><?php echo $row['user_id']; ?></p>
                    <p><?php echo $row['point_requested']; ?></p>

                    <div class="staff-request-action">
                        <form method="POST">
                            <input type="hidden" name="action_id" value="<?php echo $row['action_id']; ?>">
                            <button type="button" 
                                onclick="openApprovePopout('<?php echo $row['action_id']; ?>', '<?php echo $row['user_id']; ?>')"
                                id="approve">Approve</button>
                            <button type="submit" name="reject_action" id="reject">Reject</button>
                        </form>
                    </div>
                </div>
        <?php
            }
        } else {
            echo '<p style="text-align:center; margin-top:20px;">No pending award requests.</p>';
        }
        ?>
    </div>

    <div id="approve-blur-overlay" style="
        display:none;
        position:fixed;
        top:0;
        left:0;
        width:100%;
        height:100%;
        background:rgba(0,0,0,0.5);
        z-index:999;
    "></div>

    <div id="approve-popout" style="
        display:none;
        position:fixed;
        top:50%;
        left:50%;
        transform:translate(-50%, -50%);
        width:500px;
        background:#e6f2e2;
        padding:20px;
        border-radius:12px;
        z-index:1000;
    ">
        <h2 style="color:black;">Approve Eco Action</h2>
        <h3>Eco Action History</h3>
        <div id="ecoHistory">Loading...</div>

        <h3>Assign Achievements</h3>
        <div id="achievementList">
            
        </div>

        <form method="POST">
            <input type="hidden" name="action_id" id="approve_action_id">
            <input type="hidden" name="user_id" id="approve_user_id">

            <div id="achievementFormContainer">

            </div>
            <br>
            <button type="submit" name="final_approve" id="confirmapp">Confirm Approval</button>
            <button type="button" onclick="closeApprovePopout()" id="cancel">Cancel</button>
        </form>
    </div>

    <script>
    document.addEventListener("DOMContentLoaded", function() {
        const blurOverlay = document.getElementById("approve-blur-overlay");
        const approvePopout = document.getElementById("approve-popout");
        blurOverlay.addEventListener("click", function() {
            approvePopout.style.display = "none";
            blurOverlay.style.display = "none";
        });
        window.openApprovePopout = function(actionId, userId) {
            const approveActionId = document.getElementById("approve_action_id");
            const approveUserId = document.getElementById("approve_user_id");
            const ecoHistoryDiv = document.getElementById("ecoHistory");
            const achievementDiv = document.getElementById("achievementFormContainer");
            approveActionId.value = actionId;
            approveUserId.value = userId;
            document.getElementById("approve-popout").style.display = "block";
            document.getElementById("approve-blur-overlay").style.display = "block";
            ecoHistoryDiv.innerHTML = "<p>Loading eco action history...</p>";
            fetch('load_eco_history.php?user_id=' + encodeURIComponent(userId))
                .then(response => response.text())
                .then(data => ecoHistoryDiv.innerHTML = data)
                .catch(err => {
                    ecoHistoryDiv.innerHTML = "<p>Error loading history.</p>";
                    console.error(err);
                });
            achievementDiv.innerHTML = "<p>Loading achievements...</p>";
            fetch('load_achievements.php?user_id=' + encodeURIComponent(userId))
                .then(response => response.text())
                .then(data => achievementDiv.innerHTML = data)
                .catch(err => {
                    achievementDiv.innerHTML = "<p>Error loading achievements.</p>";
                    console.error(err);
                });
        };
        window.closeApprovePopout = function() {
            approvePopout.style.display = "none";
            blurOverlay.style.display = "none";
        };
    });
    </script>

</body>
</html>