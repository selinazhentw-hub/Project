﻿<?php
    session_start();

    if (!isset($_SESSION['staff_id'])) {
        header("Location: login.php");
        exit();
    }

    include("db_connect.php");

    $error = "";

    if (isset($_POST['bagno'], $_POST['points'], $_GET['id'])) {

        $actionId = $_GET['id'];
        $enteredBag = $_POST['bagno'];
        $points = (int)$_POST['points'];

        $sql = "SELECT bag_num FROM eco_action WHERE action_id = $actionId";
        $result = mysqli_query($conn, $sql);
        $row = mysqli_fetch_assoc($result);

        if (!$row) {
            $error = "Eco action not found.";
        } elseif ($enteredBag != $row['bag_num']) {
            $error = "Bag number does not match.";
        } else {
            
            $staffId = $_SESSION['staff_id'];

            $updateSql = "UPDATE eco_action 
                        SET point_requested = $points,
                            action_status = 'Requested',
                            staff_id = $staffId
                        WHERE action_id = $actionId";

            mysqli_query($conn, $updateSql);

            header("Location: sendrequest.php");
            exit();
        }
    }
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>APU Green Points & Rewards System</title>
    <link rel="stylesheet" href="staffstyle.css?v=2">
</head>
<body>
    <?php include('staffheader.php'); ?>

<h2 style="margin-left:20px; margin-top:20px; color: black; ">Send Request</h2>

<?php
    $actionId = $_GET['id'] ?? null;
    $selectedAction = null;

    if ($actionId) {
        $sql = "SELECT * FROM eco_action WHERE action_id = $actionId";
        $result = mysqli_query($conn, $sql);
        $selectedAction = mysqli_fetch_assoc($result);
    } else {
        $sql = "SELECT * FROM eco_action 
                WHERE action_status != 'Rejected' 
                AND point_requested = 0";
        $result = mysqli_query($conn, $sql);
    }
?>


<div style="padding: 20px;">

<?php if ($selectedAction): ?>

    <div style="background:white;padding:20px;border-radius:15px;margin-bottom:20px;box-shadow:0 0 15px rgba(0,0,0,0.15);">
        <h3>Selected Eco Action</h3>
        <p><strong>Action:</strong> <?= $selectedAction['action_desc']; ?></p>
        <p><strong>Bag Number:</strong> <?= $selectedAction['bag_num']; ?></p>
        <p><strong>Date:</strong> <?= $selectedAction['action_date']; ?></p>
    </div>

    <?php if (!empty($error)): ?>
    <p style="color:red; font-weight:bold;">
        <?= $error ?>
    </p>
    <?php endif; ?>

    <form method="POST" 
          action="sendrequest.php?id=<?= $actionId ?>" 
          enctype="multipart/form-data"
          style="background:white;padding:20px;border-radius:15px;max-width:90%;margin:auto;box-shadow:0 0 15px rgba(0,0,0,0.15);">

        <h3>Verification Details</h3>

        <label><strong>Bag Number:</strong></label>
        <input type="text" name="bagno" required style="width:100%;padding:10px;margin-bottom:15px;border-radius:8px;">

        <label><strong>Points (amount):</strong></label>
        <input type="number" name="points" min="1" required style="width:100%;padding:10px;margin-bottom:15px;border-radius:8px;">

        <button type="submit" class="ribbon-btn" style="width:200px;height:45px;font-size:18px;">
            Send Request
        </button>
    </form>

<?php else: ?>

    <h3>Select an Eco Action to send a request for points:</h3>

            <table class="eco-table" style="width:100%;border-collapse:collapse;background:white;">
    <tr>
        <th>Eco Action</th>
        <th>Bag Number</th>
        <th>Date</th>
        <th>Action</th>
    </tr>

        <?php while ($action = mysqli_fetch_assoc($result)): ?>
        <tr>
            <td><?= $action["action_desc"] ?></td>
            <td><?= $action["bag_num"] ?></td>
            <td><?= $action["action_date"] ?></td>
            <td>
                <a href="sendrequest.php?id=<?= $action['action_id'] ?>">
                    <button class="ribbon-btn" style="width:120px;height:40px;font-size:16px;">
                        Select
                    </button>
                </a>
            </td>
        </tr>
        <?php endwhile; ?>

    </table>

<?php endif; ?>

</div>