<!DOCTYPE html>
<?php
    include('db_connect.php');
    $role = $_SESSION['role'] ?? '';
    $username = $_SESSION['username'] ?? '';
    $user_id = $_SESSION['user_id'] ?? '';
    $email = $_SESSION['user_email'] ?? 'NOT SET';
    $user_fullname = $_SESSION['user_full_name'] ?? '';

    $selected_title = '';

    if ($user_id) {
        $sql = "SELECT a.achievement_title
                FROM user_achievements ua
                JOIN achievements a
                ON ua.achievement_id = a.achievement_id
                WHERE ua.user_id = ?
                AND ua.achievement_status = 'Selected'
                LIMIT 1";

        $stmt = $conn->prepare($sql);
        $stmt->bind_param("i", $user_id);
        $stmt->execute();
        $stmt->bind_result($selected_title);
        $stmt->fetch();
        $stmt->close();
    }

    if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update_profile'])) {

        $user_id = $_SESSION['user_id'];

        $username = $_POST['username'] ?? '';
        $email    = $_POST['email'] ?? '';

        $sql = "UPDATE user SET username = ?, user_email = ? WHERE user_id = ?";

        $stmt = $conn->prepare($sql);
        $stmt->bind_param("sss", $username, $email, $user_id);
        $stmt->execute();

        $_SESSION['username'] = $username;
        $_SESSION['user_email'] = $email;

        header("Location: " . $_SERVER['PHP_SELF']);
        exit;
    }

?>
<script>
    const studentUser = {
        role: "<?php echo $role; ?>",
        username: "<?php echo $username; ?>",
        user_id: "<?php echo $user_id; ?>",
        email: "<?php echo $email; ?>",
        full_name: "<?php echo $user_fullname; ?>"
    };
</script>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>APU Green Points & Rewards System</title>
    <link rel="stylesheet" href="userstyle.css">


</head>

<body>

    <div id="header">
        <h1 id="web_title">APU Green Points & Reward System</h1>
        <div id="profile">
            <button type="button" name="goto_profile" value="profile" class="profile-btn">
                <img src="https://cdn-icons-png.flaticon.com/512/6522/6522516.png" alt="Profile" height="50" width="50">
                <span>Profile</span>
            </button>
        </div>
        
        <script>
            document.querySelector(".profile-btn").addEventListener("click", function () {
                const popout = document.getElementById("profile-popout");
                const blur = document.getElementById("blur-overlay");
                const show = popout.style.display !== "block";

                popout.style.display = (popout.style.display === "block") ? "none" : "block";
                blur.style.display = show ? "block" : "none";
            });

            document.addEventListener("click", function (e) {
                const popout = document.getElementById("profile-popout");
                const button = document.querySelector(".profile-btn");
                const blur = document.getElementById("blur-overlay");

                if (!button.contains(e.target) && !popout.contains(e.target)) {
                    popout.style.display = "none";
                    blur.style.display = "none";
                }
            });
        </script>
    </div>
    <div id="blur-overlay"></div>
    
    <div id="profile-popout" class="popout">
        <h2 style="text-align: center; padding: 0px;">Profile</h2>
        <h3 id="profile-title">
            <?php echo htmlspecialchars($selected_title ?: 'No Title Selected'); ?>
        </h3>
        <div class="profile-info">
            <img src="https://cdn-icons-png.flaticon.com/512/6522/6522516.png" alt="Profile" height="100" width="100">
            <div style="display: flex; flex-direction: column; align-items: left; margin-left: 5%; text-align: left;">
                <span id="profile-username"></span>
                <span id="profile-fullname"></span>
            </div>
        </div>
        <br>
        <div style="background-color: #77B77D; height: 5px; width: 100%"></div>
        <br>
        <h2>ID: <span id="profile-userid"></span></h2>
        <h2>Email: <span id="profile-email"></span></h2>
        <br>
        <div class="profile-popout-btn">
            <button type="button" id="update-profile-btn">Update Profile</button>
            <button type="button" id="logout-btn">Logout</button>
        </div>
    </div>

    <div id="update-profile-popout" class="update-profile-popout">
        <h2>Update Profile</h2>
        <form id="update-profile-form" class="update-profile-form" method="POST">
            <label>Username</label>
            <input type="text" name="username" placeholder="Enter your username" value="<?php echo htmlspecialchars($username); ?>">
            
            <label>Email</label>
            <input type="email" name="email" placeholder="Enter your email" value="<?php echo htmlspecialchars($email); ?>">
            
            <div class="form-divider"></div>
            
            <div class="update-profile-buttons">
                <button type="submit" name="update_profile" class="update-profile-save">Save Changes</button>
                <button type="button" class="update-profile-cancel" id="cancel-update">Cancel</button>
            </div>
        </form>
    </div>
    </div>
    
    <div id="ribbon"></div>

    <button class="history-btn" onclick="window.location.href='history.php'">
        <span><u>View History</u></span>
    </button>

    <script>
        //document.getElementById('profile-title').textContent = studentUser.role;
        document.getElementById('profile-username').textContent = studentUser.username;
        document.getElementById('profile-userid').textContent = studentUser.user_id;
        document.getElementById('profile-email').textContent = studentUser.email;
        document.getElementById('profile-fullname').textContent = studentUser.full_name;

        document.getElementById('logout-btn').addEventListener('click', function() {
            window.location.href = 'logout.php';
        });

        const pages = [
            { name: "Dashboard", link: "userdashboard.php" },
            { name: "Leaderboard", link: "userleaderboard.php" },
            { name: "Shop", link: "usershop.php"},
            { name: "Forum", link: "userforum.php"},
            { name: "Achievements", link: "userachievements.php"},
            { name: "Challenges", link: "userchallenges.php"}
        ];

        const container = document.getElementById("ribbon");

        pages.forEach(page => {
            const btn = document.createElement("button");
            btn.type = "button";
            btn.textContent = page.name;
            btn.classList.add("ribbon-btn");
            btn.style.margin = "4px";
            btn.onclick = () => window.location.href = page.link;
            container.appendChild(btn);
        });

        document.getElementById('update-profile-btn').addEventListener('click', function(e) {
            e.preventDefault();
            e.stopPropagation();
            
            document.getElementById('profile-popout').style.display = 'none';
            
            const updatePopout = document.getElementById('update-profile-popout');
            const blur = document.getElementById('blur-overlay');
            updatePopout.style.display = 'block';
            blur.style.display = 'block';
        });

        document.getElementById('cancel-update').addEventListener('click', function() {
            hideUpdateProfilePopout();
        });

        function hideUpdateProfilePopout() {
            document.getElementById('update-profile-popout').style.display = 'none';
            document.getElementById('blur-overlay').style.display = 'none';
        }

        document.getElementById('blur-overlay').addEventListener('click', function() {
            hideUpdateProfilePopout();
            document.getElementById('profile-popout').style.display = 'none';
        });
    </script>
</body>
</html>