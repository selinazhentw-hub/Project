<?php
session_start();

if (!isset($_SESSION['staff_id'])) {
    header("Location: login.php");
    exit();
}

include("db_connect.php");

$staffId = $_SESSION['staff_id'];

$sql = "SELECT staff_fullname FROM staff WHERE staff_id = $staffId";
$result = mysqli_query($conn, $sql);
$staff = mysqli_fetch_assoc($result);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>APU Green Points & Rewards System</title>
    <link rel="stylesheet" href="staffstyle.css">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
</head>
<body>
    <?php include('staffheader.php'); ?>

    <h1 style="font-size:52px; margin:0; color:#032d07; text-align:center;">
    Welcome, <?= htmlspecialchars($staff['staff_fullname']) ?>
    </h1>

    <img src="images/Logo.png" alt="APU Logo"
     style="max-width:100%; height:auto; margin-top:20px; display:block; margin-left:auto; margin-right:auto;">

    <div id="clock"
        style="text-align:center; margin-top:10px; font-size:18px; color:#032d07;">
        Loading date & time...
    </div>

    <script>
    function updateClock() {
        const now = new Date();

        const date = now.toLocaleDateString('en-GB', {
            day: '2-digit',
            month: 'long',
            year: 'numeric'
            });

        const time = now.toLocaleTimeString('en-GB');

        document.getElementById("clock").innerHTML =
            date + "<br>" + time;
    }

    updateClock();              
    setInterval(updateClock, 1000);
    </script>

</body>
</html>