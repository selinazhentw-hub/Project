<!DOCTYPE html>
<?php
    session_start();
    include 'db_connect.php';

    $current_user_username = $_SESSION['username'];
    $current_user_rank = 0;
    $total_users = 0;

    $total_query = "SELECT COUNT(*) as total FROM user";
    $total_result = $conn->query($total_query);
    if ($total_result) {
        if ($total_row = $total_result->fetch_assoc()) {
            $total_users = $total_row['total'];
            echo "<!-- DEBUG: Total users found: $total_users -->\n";
        }
    } else {
        echo "<!-- DEBUG: Error in total query: " . $conn->error . " -->\n";
    }

    $all_users_query = "SELECT username, total_points FROM user ORDER BY total_points DESC";
    $all_users_result = $conn->query($all_users_query);


    $rank_counter = 1;
    $all_users_data = [];

    if ($all_users_result) {
        if ($all_users_result->num_rows > 0) {
            echo "<!-- DEBUG: Found " . $all_users_result->num_rows . " users -->\n";
            while ($row = $all_users_result->fetch_assoc()) {
                echo "<!-- DEBUG: User #$rank_counter: " . $row['username'] . " with " . $row['total_points'] . " points -->\n";
                $all_users_data[] = $row;
                
                if ($row['username'] == $current_user_username) {
                    $current_user_rank = $rank_counter;
                }
                $rank_counter++;
            }
        } else {
            echo "<!-- DEBUG: No users found in database -->\n";
        }
    } else {
        echo "<!-- DEBUG: Error in all_users query: " . $conn->error . " -->\n";
    }

    $display_limit = min(10, count($all_users_data));
    $top_users = array_slice($all_users_data, 0, $display_limit);

    echo "<!-- DEBUG: Will display $display_limit users -->\n";

    $conn->close();
?>
<html>
<head>
  <?php include 'userheader.php';?>
</head>
<body>
    <h1 style="text-align: left; margin-top: 20px;">Leaderboard</h1>
    
    <div class="rank-display">
        <p>
            Your rank: 
            <span class="rank-number-large">
                <?php echo ($current_user_rank > 0) ? $current_user_rank : "Not ranked"; ?>
            </span> 
            out of 
            <span style="font-weight: bold;"><?php echo $total_users; ?></span> 
            users
        </p>
    </div>
    
    <div class="content-box">
        <?php
        $display_rank = 1;
        
        if (!empty($top_users)) {
            foreach ($top_users as $user) {
                $is_current_user = ($user['username'] == $current_user_username);
                $is_first_place = ($display_rank == 1);
                
                echo '<div class="leaderboard-placing' . ($is_current_user ? ' current-user' : '') . '">';
                
                echo '<div style="display: flex; align-items: center; width: 100%;">';
                
                echo '<div class="rank-number" style="flex-shrink: 0;">';
                if ($is_first_place) {
                    echo '<img src="https://upload.wikimedia.org/wikipedia/commons/thumb/2/25/Simple_gold_crown.svg/768px-Simple_gold_crown.svg.png" 
                          style="width: 30px; height: 30px;" class="crown-icon" alt="Crown">';
                } else {
                    echo $display_rank . '.';
                }
                echo '</div>';
                
                echo '<div class="user-name" style="flex: 1; display: flex; align-items: center;">';
                
                echo '<span style="flex: 1;">' . htmlspecialchars($user['username']) . '</span>';
                
                if ($is_current_user) {
                    echo '<span class="you-badge">YOU</span>';
                }
                
                echo '</div>';
                
                echo '<div class="points-display" style="flex-shrink: 0;">' . number_format($user['total_points']) . ' pts</div>';
                
                echo '</div>';
                echo '</div>';
                
                $display_rank++;
            }
        } else {
            echo '<div class="empty-message">';
            echo 'No users found in the leaderboard. Be the first to earn points!';
            echo '</div>';
        }
        ?>
    </div>
    

</body>
</html>