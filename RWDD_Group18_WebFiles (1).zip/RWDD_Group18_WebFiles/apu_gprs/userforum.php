<?php
    session_start();
    include 'db_connect.php';

    $user_id = $_SESSION['user_id'] ?? null;
    $username = $_SESSION['username'] ?? 'Unknown User';

    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        header('Content-Type: application/json'); 
        if (!$user_id) {
            echo json_encode(['success' => false, 'message' => 'You must be logged in.']);
            exit();
        }

        $content = trim($_POST['content'] ?? '');
        $parent_post_id = $_POST['parent_post_id'] ?? null;

        if (empty($content)) {
            echo json_encode(['success' => false, 'message' => 'Content cannot be empty.']);
            exit();
        }

        if ($parent_post_id) {
            $stmt = $conn->prepare("
                INSERT INTO forum_post (user_id, post_content, parent_post_id, is_reply, date_posted)
                VALUES (?, ?, ?, TRUE, NOW())
            ");
            $stmt->bind_param("ssi", $user_id, $content, $parent_post_id);
            $history_action = "replied to a forum post";
        } else {
            $stmt = $conn->prepare("
                INSERT INTO forum_post (user_id, post_content, date_posted)
                VALUES (?, ?, NOW())
            ");
            $stmt->bind_param("ss", $user_id, $content);
            $history_action = "posted a forum";
        }

        if ($stmt->execute()) {
            $post_id = $stmt->insert_id;

            $hist_stmt = $conn->prepare("
                INSERT INTO history (user_id, history_title, history_description, history_date)
                VALUES (?, 'Forum', ?, NOW())
            ");
            $hist_stmt->bind_param("ss", $user_id, $history_action);
            $hist_stmt->execute();
            $hist_stmt->close();

            echo json_encode([
                'success' => true,
                'post_id' => $post_id,
                'username' => $username,
                'message' => 'Post saved successfully.'
            ]);
        } else {
            echo json_encode(['success' => false, 'message' => $stmt->error]);
        }

        $stmt->close();
        $conn->close();
        exit(); 
    }

?>
<!DOCTYPE html>
<html>
<head>
    <?php include 'userheader.php'; ?>
</head>
<body>
    <h1 style="text-align:left; margin-top:20px;">Forum</h1>
    <div class="content-box">
        <div class="new-post">
            <textarea id="main-post-content" placeholder="Write your post here..."></textarea>
            <button class="submit-btn" onclick="submitPost()">Post</button>
        </div>
        <div class="posts">
            <?php
            function displayPosts($conn, $parent_id = NULL) {
                if ($parent_id === NULL) {
                    $stmt = $conn->prepare("
                        SELECT fp.*, u.username 
                        FROM forum_post fp
                        INNER JOIN user u ON fp.user_id = u.user_id
                        WHERE fp.parent_post_id IS NULL
                        ORDER BY fp.date_posted DESC
                    ");
                } else {
                    $stmt = $conn->prepare("
                        SELECT fp.*, u.username 
                        FROM forum_post fp
                        INNER JOIN user u ON fp.user_id = u.user_id
                        WHERE fp.parent_post_id = ?
                        ORDER BY fp.date_posted ASC
                    ");
                    $stmt->bind_param("i", $parent_id);
                }
                $stmt->execute();
                $result = $stmt->get_result();

                while ($post = $result->fetch_assoc()) {
                    $username = $post['username'];
                    ?>
                    <div class="post" data-post-id="<?php echo $post['post_id']; ?>">
                        <div class="post-header">
                            <h3><?php echo htmlspecialchars($username); ?></h3>
                            <span class="post-date"><?php echo date('M j, Y g:i A', strtotime($post['date_posted'])); ?></span>
                        </div>
                        <p><?php echo htmlspecialchars($post['post_content']); ?></p>

                        <?php if ($parent_id === NULL): ?>
                            <button class="reply-btn" onclick="showReplyForm(<?php echo $post['post_id']; ?>)">Reply</button>
                            <div class="reply-form" id="reply-form-<?php echo $post['post_id']; ?>">
                                <textarea placeholder="Write your reply..."></textarea>
                                <button class="submit-btn" onclick="submitReply(<?php echo $post['post_id']; ?>)">Post Reply</button>
                            </div>
                        <?php endif; ?>

                        <div class="replies-container">
                            <?php displayPosts($conn, $post['post_id']); ?>
                        </div>
                    </div>
                    <?php
                }
                $stmt->close();
            }

            displayPosts($conn, NULL);
            $conn->close();
            ?>
        </div>
    </div>

<script>
function submitPost() {
    const content = document.getElementById("main-post-content").value.trim();
    if (!content) return alert("Please enter content.");

    const formData = new URLSearchParams();
    formData.append('content', content);

    fetch('', { method: 'POST', body: formData })
        .then(r => r.json())
        .then(data => {
            if (data.success) location.reload(); 
            else alert(data.message);
        });
}

function showReplyForm(postId) {
    document.querySelectorAll('.reply-form').forEach(f => f.classList.remove('active'));
    document.getElementById(`reply-form-${postId}`).classList.toggle('active');
}

function submitReply(parentPostId) {
    const form = document.getElementById(`reply-form-${parentPostId}`);
    const content = form.querySelector('textarea').value.trim();
    if (!content) return alert("Please enter reply.");

    const formData = new URLSearchParams();
    formData.append('content', content);
    formData.append('parent_post_id', parentPostId);

    fetch('', { method: 'POST', body: formData })
        .then(r => r.json())
        .then(data => {
            if (data.success) location.reload(); 
            else alert(data.message);
        });
}
</script>
</body>
</html>