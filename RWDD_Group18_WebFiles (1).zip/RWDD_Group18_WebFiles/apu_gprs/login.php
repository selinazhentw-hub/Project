<!DOCTYPE html>
<?php
    session_start();
    include 'db_connect.php';

    $error_message = "";

    if ($_SERVER["REQUEST_METHOD"] === "POST") {

        if (!empty($_POST['username']) && !empty($_POST['password'])) {

            $username = $_POST['username'];
            $password = $_POST['password'];
            $error_message = "Invalid username or password.";

            /*
            ======================
            ADMIN LOGIN
            ======================
            */
            $sql = "SELECT * FROM admin WHERE admin_username = ?";
            $stmt = $conn->prepare($sql);
            $stmt->bind_param("s", $username);
            $stmt->execute();
            $result = $stmt->get_result();

            if ($result->num_rows === 1) {
                $admin = $result->fetch_assoc();

                if ($password === $admin['admin_password']) {
                    $_SESSION['admin_id'] = $admin['admin_id'];
                    $_SESSION['admin_username'] = $admin['admin_username'];
                    $_SESSION['admin_email'] = $admin['admin_email'];
                    $_SESSION['admin_phone_number'] = $admin['admin_phone_number'];
                    $_SESSION['admin_fullname'] = $admin['admin_fullname'];
                    $_SESSION['role'] = 'admin';

                    
                    header("Location: admindashboard.php");
                    exit();
                }
            }

            /*
            ======================
            STAFF LOGIN
            ======================
            */
            $sql = "SELECT * FROM staff WHERE staff_username = ?";
            $stmt = $conn->prepare($sql);
            $stmt->bind_param("s", $username);
            $stmt->execute();
            $result = $stmt->get_result();

            if ($result->num_rows === 1) {
                $staff = $result->fetch_assoc();

                if ($password === $staff['staff_password']) {
                    $_SESSION['staff_id'] = $staff['staff_id'];
                    $_SESSION['staff_username'] = $staff['staff_username'];
                    $_SESSION['staff_fullname'] = $staff['staff_fullname'];
                    $_SESSION['staff_email'] = $staff['staff_email'];
                    $_SESSION['staff_phone_number'] = $staff['staff_phone_number'];
                    $_SESSION['staff_fullname'] = $staff['staff_fullname'];
                    $_SESSION['role'] = 'staff';

                    header("Location: staffdashboard.php");
                    exit();
                }
            }

            /*
            ======================
            USER LOGIN
            ======================
            */
            $sql = "SELECT * FROM user WHERE username = ?";
            $stmt = $conn->prepare($sql);
            $stmt->bind_param("s", $username);
            $stmt->execute();
            $result = $stmt->get_result();

            if ($result->num_rows === 1) {
                $user = $result->fetch_assoc();

                if ($user['account_status'] === "Pending") {
                    $error_message = "Your account is still pending approval. Please wait for admin approval.";
                } elseif ($user['account_status'] === "Rejected") {
                    $error_message = "Your account request has been rejected. Please contact the administrator.";
                } elseif ($password === $user['user_password']) {
                    $_SESSION['user_id'] = $user['user_id'];
                    $_SESSION['username'] = $user['username'];
                    $_SESSION['user_full_name'] = $user['user_fullname'];
                    $_SESSION['user_email'] = $user['user_email'];
                    $_SESSION['total_points'] = $user['total_points'];
                    $_SESSION['redeemable_points'] = $user['redeemable_points'];
                    $_SESSION['role'] = 'user';

                    header("Location: userdashboard.php");
                    exit();
                }

                

                
            }

            /*
            ======================
            LOGIN FAILED
            ======================
            */
            

            $stmt->close();

        } else {
            $error_message = "Please fill in all fields.";
        }

        $conn->close();
    }
?>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>APU Green Points & Rewards System</title>
    <link rel="stylesheet" href="adminstyle.css">
</head>
<body>
    <div id="header">
        <h1 id="web_title">APU Green Points & Reward System</h1>
        <div id="profile">
            <button type="button" name="goto_profile" value="profile" class="profile-btn">
                <img src="https://cdn-icons-png.flaticon.com/512/6522/6522516.png" alt="Profile" height="50" width="50">
                <span>Profile</span>
            </button>
        </div>
    </div>
    <h1 style="font-family: 'Funnel Sans', sans-serif; text-align:center;">Login</h1>
    <h3 style="text-align: center;">Welcome back! Enter your credentials to login.</h3>
    
    <?php if (!empty($error_message)): ?>
        <div style="color: red; text-align: center; margin: 10px;">
            <?php echo $error_message; ?>
        </div>
    <?php endif; ?>
    
    <div class="login">
    <form method="POST" action="">
        <br>
        <label>Username</label><br>
        <input type="text" name="username" required><br>
        <br>
        <label>Password</label><br>
        <input type="password" name="password" style="margin-bottom:0px;" required><br>
        
        <br><br><br><br><br><br>
        <div class="login-btm-btn">
            <button type="submit">Submit</button>
            <button type="reset">Reset</button>
        </div>
        <br><br>
        <button type="button" onclick="window.location.href='signup.php'" name="goto_signup" value="signup" style="background:none; border:none; cursor:pointer; margin-top:5px; display: block; margin: auto;">
            <span style="color: #97ea9fff; font-family: 'Funnel Sans', sans-serif;"><u>Not registered? Sign up here.</u></span>
        </button>
    </form>
    </div>
</body>
</html>