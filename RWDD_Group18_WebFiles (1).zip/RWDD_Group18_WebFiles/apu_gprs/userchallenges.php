<?php
    session_start();
    include 'db_connect.php';

    if (!isset($_SESSION['user_id']) || ($_SESSION['role'] ?? '') !== 'user') {
        header('Location: login.php');
        exit();
    }

    $success_message = '';
    $error_message = '';

    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        $user_id = $_SESSION['user_id']; 
        $challenge_id = $_POST['challenge_id'] ?? '';
        $challenge_date = $_POST['challenge_date'] ?? '';
        $bag_number = $_POST['bag_number'] ?? '';

        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        $user_id = $_SESSION['user_id']; 
        $challenge_id = $_POST['challenge_id'] ?? '';
        $challenge_date = $_POST['challenge_date'] ?? '';
        $bag_number = $_POST['bag_number'] ?? '';

        if (!$challenge_date || !$bag_number) {
            $error_message = 'Please fill in all required fields.';
        } else {
            $challenge_id = mysqli_real_escape_string($conn, $challenge_id);
            $challenge_date = mysqli_real_escape_string($conn, $challenge_date);
            $bag_number = mysqli_real_escape_string($conn, $bag_number);
            $user_id_esc = mysqli_real_escape_string($conn, $user_id);

            if ($challenge_id) {
                $challenge_id_esc = mysqli_real_escape_string($conn, $challenge_id);
                $title_result = mysqli_query($conn, "SELECT challenge_title FROM challenge WHERE challenge_id = '$challenge_id'");
                if ($title_result && mysqli_num_rows($title_result) > 0) {
                    $row_title = mysqli_fetch_assoc($title_result);
                    $action_desc = mysqli_real_escape_string($conn, $row_title['challenge_title']);
                } else {
                    $action_desc = "Eco Action Completed";
                    $challenge_id_esc = "NULL";
                }
            } else {
                $action_desc = "Eco Action Completed";
                $challenge_id_esc = "NULL";
            }

            $sql = "INSERT INTO eco_action (
                user_id, challenge_id, action_desc, action_date, action_status, point_requested, bag_num, rejection_reason
            ) VALUES (
                '$user_id_esc', " . ($challenge_id_esc === "NULL" ? "NULL" : "'$challenge_id_esc'") . ", '$action_desc', '$challenge_date', 'Pending', 0, '$bag_number', ''
            )";

            if (mysqli_query($conn, $sql)) {
                $success_message = 'Challenge submitted successfully!';
            } else {
                $error_message = 'Database error: ' . mysqli_error($conn);
            }
        }
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>User Challenges</title>
    <link rel="stylesheet" href="userstyle.css">
</head>
<body>
    <?php include 'userheader.php'; ?>

    <div id="challenges">
        <h1>Challenges</h1>

        <?php if ($success_message): ?>
            <div style="color: green; text-align: center; margin: 10px;"><?= $success_message ?></div>
        <?php endif; ?>
        <?php if ($error_message): ?>
            <div style="color: red; text-align: center; margin: 10px;"><?= $error_message ?></div>
        <?php endif; ?>

        <div class="challenge-layout">
            <div class="challenge-menu">
                <div class="arrow-box" data-target="monthly">Monthly<p>Resets on 1st of the month</p></div>
                <div class="arrow-box" data-target="submit">Submit</div>
            </div>

            <div class="challenge-content">
                <div class="content-card">
                    <div class="content-box hidden" id="monthly">
                        <?php
                        $sql = "SELECT challenge_id, challenge_title, challenge_duration, challenge_description 
                                FROM challenge ORDER BY challenge_title";
                        $result = $conn->query($sql);

                        if ($result->num_rows > 0) {
                            while ($row = $result->fetch_assoc()) {
                                echo '<div class="challenge-row">';
                                echo '<div class="challenge-info">';
                                echo '<span class="challenge-title">' . htmlspecialchars($row['challenge_title']) . '</span>';
                                if (!empty($row['challenge_description'])) {
                                    echo '<div class="challenge-description">' . htmlspecialchars($row['challenge_description']) . '</div>';
                                }
                                echo '</div></div>';
                            }
                        } else {
                            echo '<div class="challenge-row"><span class="challenge-name">No challenges available</span></div>';
                        }
                        ?>
                    </div>

                        <div class="content-box hidden" id="submit">
                            <div class="submission-wrapper">
                                <form id="ecoForm" class="eco-form" method="POST">
                                    <label for="dateInput">Date:</label>
                                    <input type="date" id="dateInput" name="challenge_date" required>

                                    <label for="challengeSelect">Challenge:</label>
                                    <select id="challengeSelect" name="challenge_id">
                                        <option value="">Select a challenge</option>
                                        <?php
                                        include 'db_connect.php';
                                        
                                        $sql = "SELECT challenge_id, challenge_title FROM challenge ORDER BY challenge_title";
                                        $result = $conn->query($sql);
                                        
                                        if ($result->num_rows > 0) {
                                            while($row = $result->fetch_assoc()) {
                                                echo "<option value='" . htmlspecialchars($row['challenge_id']) . "'>" . 
                                                    htmlspecialchars($row['challenge_title']) . 
                                                    "</option>";
                                            }
                                        }
                                        $conn->close();
                                        ?>
                                    </select>

                                    <label for="bagNum">Bag number:</label>
                                    <input type="number" id="bagNum" name="bag_number" placeholder="Bag no." min="1" step="1" required>

                                    <button type="submit" class="submit-btn">Submit Challenge</button>
                                </form>

                                <div id="submittedOverlay" class="submitted-overlay">
                                    <h1>SUBMITTED!</h1>
                                    <p style="color: white; margin-bottom: 20px; font-size: 18px;">Challenge submitted successfully</p>
                                    <a id="backToForm" class="back-link">Back to Form</a>
                                </div>
                            </div>
                        </div>
                </div>
            </div>
        </div>
    </div>

    <script>
        document.querySelectorAll(".arrow-box").forEach(btn => {
            btn.addEventListener("click", () => {
                document.querySelectorAll(".arrow-box").forEach(b => b.classList.remove("active"));
                btn.classList.add("active");
                document.querySelectorAll(".content-box").forEach(c => c.classList.add("hidden"));
                const target = btn.dataset.target;
                const targetElement = document.getElementById(target);
                if (targetElement) targetElement.classList.remove("hidden");
            });
        });
        document.addEventListener('DOMContentLoaded', () => {
            document.querySelector('.arrow-box').click();
        });
    </script>
</body>
</html>