<?php
include('db_connect.php');

$user_id = $_GET['user_id'] ?? '';

if (!$user_id) {
    echo "<p>No user specified.</p>";
    exit;
}

$sql = "SELECT action_desc, action_date, action_status
        FROM eco_action
        WHERE user_id = '$user_id'
        ORDER BY action_date DESC";

$result = mysqli_query($conn, $sql);

if (mysqli_num_rows($result) > 0) {
    echo "<ul>";
    while ($row = mysqli_fetch_assoc($result)) {
        echo "<li>
                <strong>" . htmlspecialchars($row['action_date']) . "</strong> – 
                " . htmlspecialchars($row['action_desc']) . " (" . htmlspecialchars($row['action_status']) . ")
              </li>";
    }
    echo "</ul>";
} else {
    echo "<p>No eco actions found.</p>";
}
?>