<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>APU Green Points & Rewards System</title>
    <link rel="stylesheet" href="adminstyle.css">
    <style>
        .shop-item {
            background: white;
            border-radius: 10px;
            box-shadow: 0 2px 5px rgba(0,0,0,0.1);
            width: 200px;
            padding: 15px;
            text-align: center;
            transition: transform 0.3s ease;
            }
            
            .shop-item:hover {
            transform: translateY(-5px);
            }
            
            .shop-item img {
            width: 100px;
            height: 100px;
            background: #ddd;
            margin-bottom: 10px;
            border-radius: 5px;
            }
    </style>
</head>
<body>
    <?php 
        include 'adminsession.php' ;
        include 'adminheader.php';
    ?>
    <h1 style="font-family: 'Patrick Hand SC', sans-serif; text-align:left;">Shop</h1>
    
    <br>
    <h3 style="text-align: right;">
        <a href="add_shopitem.php" style="text-decoration: underline; color: inherit;">
            Add New Item
        </a>
    </h3>
    <h3 style="text-align: right;">
        <a href="delete_shopitem.php" style="text-decoration: underline; color: inherit;">
            Delete Existing Item
        </a>
    </h3>
    <div class="shop">
        <?php
        include ('db_connect.php');

        $itemQuery = "SELECT item_id, item_name, item_cost, stock_quantity, item_image
                    FROM shop_item
                    WHERE stock_quantity > 0";

        $itemResult = mysqli_query($conn, $itemQuery);

        if (mysqli_num_rows($itemResult) > 0) {
            while ($item = mysqli_fetch_assoc($itemResult)) {
                ?>
                <div class="shop-item"
                    data-id="<?= $item['item_id'] ?>"
                    data-name="<?= htmlspecialchars($item['item_name']) ?>"
                    data-price="<?= $item['item_cost'] ?>">

                    <div class="info">
                        <img src="<?= htmlspecialchars($item['item_image']) ?>" alt="<?= htmlspecialchars($item['item_name']) ?>">
                        <div class="item-name"><p><?= htmlspecialchars($item['item_name']) ?></p></div>
                    </div>

                    <div class="price-control">
                        <p><?= $item['item_cost'] ?> Points</p>
                    </div>
                </div>
                <?php
            }
        } else {
            echo '<p style="text-align: center;">No items found.</p>';
        }
        ?>
        </div>
    </div>
</body>
</html>