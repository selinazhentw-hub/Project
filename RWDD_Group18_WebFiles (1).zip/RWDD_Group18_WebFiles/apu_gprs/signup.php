<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>APU Green Points & Rewards System</title>
    <link rel="stylesheet" href="adminstyle.css">
</head>
<body>
    <div id="header">
        <h1 id="web_title">APU Green Points & Reward System</h1>
        <div id="profile">
            <button type="button" name="goto_profile" value="profile" class="profile-btn">
                <img src="https://cdn-icons-png.flaticon.com/512/6522/6522516.png" alt="Profile" height="50" width="50">
                <span>Profile</span>
            </button>
        </div>
        
    </div>
    <h1 style="font-family: 'Funnel Sans', sans-serif; text-align:center;">Signup</h1>
    <h3 style="text-align: center;">Create an account</h3>
    <div class="signup">
    <form method="POST" action="">
        <br>
        <label>User ID <span style="color: red;">*</span></label><br>
        <label style="font-size: 12px;">Enter your school ID. It will be verified during our onboarding process.</label><br>
        <input type="text" name="user_id" placeholder="TP..." required><br>
        <br>
        <label>Username <span style="color: red;">*</span></label><br>
        <input type="text" name="username" required><br>
        <br>
        <label>Password <span style="color: red;">*</span></label><br>
        <input type="password" name="user_password" required maxlength="25"><br>
        <label>Email</label><br>
        <input type="email" name="user_email" maxlength="200"><br>

        <br><br><br><br>
        <div class="login-btm-btn">
            <button type="submit">Submit</button>
            <button type="reset">Reset</button>
        </div>
        <label style="font-size: 12px;">Please wait for our admins to approve your onboarding.</label><br>
        <br><br>
        <button type="button" onclick="window.location.href='login.php'" name="goto_signup" value="signup" style="background:none; border:none; cursor:pointer; margin-top:5px; display: block; margin: auto;">
            <span style="color: #97ea9fff; font-family: 'Funnel Sans', sans-serif;"><u>Already registered? Log in here.</u></span>
        </button>
    </form>
    </div>

    <?php 
        include("db_connect.php");

        $error_message = "";

        if ($_SERVER["REQUEST_METHOD"] == "POST") {
            if (isset($_POST['user_id']) && isset($_POST['username']) && isset($_POST['user_password'])) {


                $sql = "SELECT * FROM user WHERE user_id='$_POST[user_id]'";
                $result = mysqli_query($conn,$sql);
                $rowcount = mysqli_num_rows($result);
                if ($rowcount > 0) {
                    echo "<script>alert('User ID already registered!')</script>";
                } else {
                    $current_date = date("Y-m-d");
                    $sql = "INSERT INTO user (user_id, username, user_password, user_fullname, user_age, user_email, account_status, total_points, redeemable_points, date_created) VALUES ('$_POST[user_id]','$_POST[username]','$_POST[user_password]','','','$_POST[user_email]','Pending','0','0', '$current_date')";
                    if (mysqli_query($conn,$sql)){
                        echo "<script>alert('Successfully registered'); window.location.href = 'login.php';</script>";
                    } else {
                        die(mysqli_error($conn));
                    }
                }
            }
        }
    ?>
</body>
</html>