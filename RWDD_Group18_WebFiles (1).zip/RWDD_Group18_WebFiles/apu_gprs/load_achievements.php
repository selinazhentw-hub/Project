<?php
include('db_connect.php');

$user_id = $_GET['user_id'] ?? '';

if (!$user_id) {
    echo "<p>No user specified.</p>";
    exit;
}

$sql = "SELECT achievement_id, achievement_title
        FROM achievements ORDER BY achievement_title";
$result = mysqli_query($conn, $sql);

if (mysqli_num_rows($result) > 0) {
    while ($row = mysqli_fetch_assoc($result)) {
        echo "<label style='color:black;'>
                <input type='checkbox' name='achievements[]' value='" . htmlspecialchars($row['achievement_id']) . "'> " 
                . htmlspecialchars($row['achievement_title']) . "
              </label><br>";
    }
} else {
    echo "<p>No achievements available.</p>";
}
?>