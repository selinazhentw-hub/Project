<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>APU Green Points & Rewards System</title>
    <link rel="stylesheet" href="adminstyle.css">
</head>
<body>
    <?php 
        include 'adminsession.php' ;
        include 'adminheader.php';
    ?>
    <h3 style="text-align: left;">
        <a href="adminshop.php" style="text-decoration: underline; color: inherit;">
            Back to Shop
        </a>
    </h3>
    <h1 style="font-family: 'Funnel Sans', sans-serif; text-align:center;">Add New Item</h1>
    <h3 style="text-align: center;">Add a new item into the shop</h3>
    <div class="create-challenge">
    <form method="POST" action="" enctype="multipart/form-data">
        <br>
        <label>Item Name</label><br>
        <input type="text" name="item_name" required><br>
        <br>
        <label>Cost</label><br>
        <input type="number" name="item_cost" min="0" required><label> points</label>
        <br>
        <label>Stock Quantity</label><br>
        <input type="number" name="stock_quantity" min="1" required><br>
        <label>Item Image</label><br>
        <input type="file" name="item_image" accept="image/*" required><br><br>
        <br><br><br><br><br>


        <div class="login-btm-btn">
            <button type="submit">Submit</button>
            <button type="reset">Reset</button>
        </div>
    </form>
    </div>

    <?php
        include("db_connect.php");

        if ($_SERVER["REQUEST_METHOD"] === "POST") {

            $item_name = $_POST['item_name'];
            $item_cost = $_POST['item_cost'];
            $stock_quantity = $_POST['stock_quantity'];

            $image_name = $_FILES['item_image']['name'];
            $image_tmp = $_FILES['item_image']['tmp_name'];
            $image_ext = strtolower(pathinfo($image_name, PATHINFO_EXTENSION));

            $allowed_ext = ['jpg', 'jpeg', 'png', 'gif'];

            if (!in_array($image_ext, $allowed_ext)) {
                die("Invalid image format.");
            }

            $new_image_name = uniqid("item_", true) . "." . $image_ext;
            $image_path = "uploads/shop_items/" . $new_image_name;

            if (!move_uploaded_file($image_tmp, $image_path)) {
                die("Failed to upload image.");
            }

            $sql = "INSERT INTO shop_item 
                    (item_name, item_cost, stock_quantity, item_image)
                    VALUES 
                    ('$item_name', '$item_cost', '$stock_quantity', '$image_path')";

            if (mysqli_query($conn, $sql)) {
                echo "<script>alert('Successfully added new shop item.');</script>";
            } else {
                die(mysqli_error($conn));
            }
        }
    ?>
</body>
</html>