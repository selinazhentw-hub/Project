-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: Jan 11, 2026 at 12:06 PM
-- Server version: 9.1.0
-- PHP Version: 8.3.14

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `gprs`
--

-- --------------------------------------------------------

--
-- Table structure for table `achievements`
--

DROP TABLE IF EXISTS `achievements`;
CREATE TABLE IF NOT EXISTS `achievements` (
  `achievement_id` int NOT NULL AUTO_INCREMENT,
  `achievement_title` tinytext NOT NULL,
  `achievement_condition` tinytext NOT NULL,
  PRIMARY KEY (`achievement_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `achievements`
--

INSERT INTO `achievements` (`achievement_id`, `achievement_title`, `achievement_condition`) VALUES
(1, 'Green Supporter ', 'Obtain 20 points '),
(2, 'Eco Hero', 'Recycle 50 bottles');

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

DROP TABLE IF EXISTS `admin`;
CREATE TABLE IF NOT EXISTS `admin` (
  `admin_id` int NOT NULL AUTO_INCREMENT,
  `admin_username` tinytext NOT NULL,
  `admin_fullname` tinytext NOT NULL,
  `admin_email` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `admin_password` varchar(25) NOT NULL,
  `admin_phone_number` varchar(25) NOT NULL,
  PRIMARY KEY (`admin_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`admin_id`, `admin_username`, `admin_fullname`, `admin_email`, `admin_password`, `admin_phone_number`) VALUES
(1, 'admin01', 'Alvin Teoh', 'zxzx@gmail.com', 'av123', '0123456790');

-- --------------------------------------------------------

--
-- Table structure for table `challenge`
--

DROP TABLE IF EXISTS `challenge`;
CREATE TABLE IF NOT EXISTS `challenge` (
  `challenge_id` int NOT NULL AUTO_INCREMENT,
  `challenge_title` text NOT NULL,
  `challenge_duration` int NOT NULL,
  `challenge_description` longtext NOT NULL,
  PRIMARY KEY (`challenge_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `challenge`
--

INSERT INTO `challenge` (`challenge_id`, `challenge_title`, `challenge_duration`, `challenge_description`) VALUES
(1, 'Bottle Recycling Frenzy', 14, 'Recycle as many bottles as you can to earn 100 points!');

-- --------------------------------------------------------

--
-- Table structure for table `eco_action`
--

DROP TABLE IF EXISTS `eco_action`;
CREATE TABLE IF NOT EXISTS `eco_action` (
  `action_id` int NOT NULL AUTO_INCREMENT,
  `user_id` varchar(8) NOT NULL,
  `challenge_id` int DEFAULT NULL,
  `staff_id` int DEFAULT NULL,
  `action_desc` text NOT NULL,
  `action_date` date NOT NULL,
  `action_status` varchar(20) NOT NULL,
  `point_requested` int NOT NULL,
  `bag_num` int NOT NULL,
  `rejection_reason` text CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  PRIMARY KEY (`action_id`),
  KEY `user_id` (`user_id`),
  KEY `challenge_id` (`challenge_id`),
  KEY `staff_id` (`staff_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `eco_action`
--

INSERT INTO `eco_action` (`action_id`, `user_id`, `challenge_id`, `staff_id`, `action_desc`, `action_date`, `action_status`, `point_requested`, `bag_num`, `rejection_reason`) VALUES
(1, 'TP088991', 1, 1, 'Bottle Recycling Frenzy', '2026-01-01', 'Approved', 15, 7, ''),
(2, 'TP088991', 1, NULL, 'Bottle Recycling Frenzy', '2026-01-11', 'Pending', 0, 2, '');

-- --------------------------------------------------------

--
-- Table structure for table `forum_post`
--

DROP TABLE IF EXISTS `forum_post`;
CREATE TABLE IF NOT EXISTS `forum_post` (
  `post_id` int NOT NULL AUTO_INCREMENT,
  `user_id` varchar(8) NOT NULL,
  `post_content` text NOT NULL,
  `date_posted` datetime DEFAULT CURRENT_TIMESTAMP,
  `parent_post_id` int DEFAULT NULL,
  `is_reply` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`post_id`),
  KEY `user_id` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `forum_post`
--

INSERT INTO `forum_post` (`post_id`, `user_id`, `post_content`, `date_posted`, `parent_post_id`, `is_reply`) VALUES
(16, 'TP088991', 'Anyone up for looking for plastics together?', '2026-01-11 18:56:44', NULL, 0),
(17, 'TP083103', 'Yeah!', '2026-01-11 18:57:06', 16, 1);

-- --------------------------------------------------------

--
-- Table structure for table `history`
--

DROP TABLE IF EXISTS `history`;
CREATE TABLE IF NOT EXISTS `history` (
  `history_id` int NOT NULL AUTO_INCREMENT,
  `history_title` text NOT NULL,
  `history_description` text CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `history_date` date NOT NULL,
  `user_id` varchar(8) NOT NULL,
  PRIMARY KEY (`history_id`),
  KEY `user_id` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `history`
--

INSERT INTO `history` (`history_id`, `history_title`, `history_description`, `history_date`, `user_id`) VALUES
(10, 'Eco Action', 'Bottle Recycling Frenzy (+15 points)', '2026-01-01', 'TP088991'),
(11, 'Forum', 'posted a forum', '2026-01-11', 'TP088991'),
(12, 'Forum', 'replied to a forum post', '2026-01-11', 'TP083103');

-- --------------------------------------------------------

--
-- Table structure for table `shop_item`
--

DROP TABLE IF EXISTS `shop_item`;
CREATE TABLE IF NOT EXISTS `shop_item` (
  `item_id` int NOT NULL AUTO_INCREMENT,
  `item_name` tinytext NOT NULL,
  `item_cost` int NOT NULL,
  `stock_quantity` int NOT NULL,
  `item_image` varchar(255) NOT NULL,
  PRIMARY KEY (`item_id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `shop_item`
--

INSERT INTO `shop_item` (`item_id`, `item_name`, `item_cost`, `stock_quantity`, `item_image`) VALUES
(7, '100 Plus', 100, 19, 'uploads/shop_items/item_69634bc96f6437.78222432.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `staff`
--

DROP TABLE IF EXISTS `staff`;
CREATE TABLE IF NOT EXISTS `staff` (
  `staff_id` int NOT NULL AUTO_INCREMENT,
  `staff_username` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `staff_password` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `staff_fullname` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `staff_email` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `staff_phone_number` varchar(25) NOT NULL,
  PRIMARY KEY (`staff_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `staff`
--

INSERT INTO `staff` (`staff_id`, `staff_username`, `staff_password`, `staff_fullname`, `staff_email`, `staff_phone_number`) VALUES
(1, 'staff01', 'aisyah', 'Nur Aisyah Binti Rahman', 'aisyah.rahman@gmail.com', '0123456789');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

DROP TABLE IF EXISTS `user`;
CREATE TABLE IF NOT EXISTS `user` (
  `user_id` varchar(8) NOT NULL,
  `username` varchar(50) NOT NULL,
  `user_password` varchar(50) NOT NULL,
  `user_fullname` varchar(255) NOT NULL,
  `user_age` int NOT NULL,
  `user_email` varchar(255) NOT NULL,
  `account_status` tinytext NOT NULL,
  `total_points` int NOT NULL,
  `redeemable_points` int NOT NULL,
  `date_created` date NOT NULL,
  PRIMARY KEY (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`user_id`, `username`, `user_password`, `user_fullname`, `user_age`, `user_email`, `account_status`, `total_points`, `redeemable_points`, `date_created`) VALUES
('TP081111', 'nick', 'nick123', '', 0, 'nickhi@gmail.com', 'Pending', 0, 0, '2026-01-11'),
('TP083103', 'zx', 'zx123', 'Yeoh Zi Xuan', 19, 'zxzx@gmail.com', 'Approved', 0, 0, '2026-01-11'),
('TP088991', 'beautylily06', 'beauty123', 'Lily McKenzie', 19, 'beautylily@gmail.com', 'Approved', 15, 15, '2026-01-11');

-- --------------------------------------------------------

--
-- Table structure for table `user_achievements`
--

DROP TABLE IF EXISTS `user_achievements`;
CREATE TABLE IF NOT EXISTS `user_achievements` (
  `user_achievement_id` int NOT NULL AUTO_INCREMENT,
  `user_id` varchar(8) NOT NULL,
  `achievement_id` int NOT NULL,
  `achievement_status` tinytext NOT NULL,
  `unlocked_date` date NOT NULL,
  PRIMARY KEY (`user_achievement_id`),
  KEY `achievement_id` (`achievement_id`),
  KEY `user_id` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `user_achievements`
--

INSERT INTO `user_achievements` (`user_achievement_id`, `user_id`, `achievement_id`, `achievement_status`, `unlocked_date`) VALUES
(2, 'TP088991', 1, 'Unlocked', '2026-01-11');

--
-- Constraints for dumped tables
--

--
-- Constraints for table `eco_action`
--
ALTER TABLE `eco_action`
  ADD CONSTRAINT `eco_action_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `user` (`user_id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  ADD CONSTRAINT `eco_action_ibfk_2` FOREIGN KEY (`challenge_id`) REFERENCES `challenge` (`challenge_id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  ADD CONSTRAINT `eco_action_ibfk_3` FOREIGN KEY (`staff_id`) REFERENCES `staff` (`staff_id`) ON DELETE RESTRICT ON UPDATE RESTRICT;

--
-- Constraints for table `forum_post`
--
ALTER TABLE `forum_post`
  ADD CONSTRAINT `forum_post_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `user` (`user_id`) ON DELETE RESTRICT ON UPDATE RESTRICT;

--
-- Constraints for table `history`
--
ALTER TABLE `history`
  ADD CONSTRAINT `history_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `user` (`user_id`) ON DELETE RESTRICT ON UPDATE RESTRICT;

--
-- Constraints for table `user_achievements`
--
ALTER TABLE `user_achievements`
  ADD CONSTRAINT `user_achievements_ibfk_1` FOREIGN KEY (`achievement_id`) REFERENCES `achievements` (`achievement_id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  ADD CONSTRAINT `user_achievements_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `user` (`user_id`) ON DELETE RESTRICT ON UPDATE RESTRICT;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
