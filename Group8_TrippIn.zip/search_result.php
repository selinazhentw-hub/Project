<?php
include 'db_connect.php';

if (!isset($_GET['city'])) {
    die("No search data.");
}

$city = $_GET['city'];
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <title>Search Result</title>
    <?php include 'sidenav.php'; ?>

<style>
body {
    margin: 0;
    font-family: Arial;
    background: url('https://images.unsplash.com/photo-1507525428034-b723cf961d3e') no-repeat center fixed;
    background-size: cover;
}

body::before {
    content: "";
    position: fixed;
    width: 100%;
    height: 100%;
    background: rgba(0,0,0,0.5);
    z-index: -1;
}

#main-content {
    padding: 30px;
    color: white;
}

h2 {
    text-align: center;
}

/* CARDS */
.grid {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(250px,1fr));
    gap: 20px;
}

.card {
    background: rgba(255,255,255,0.1);
    border-radius: 15px;
    overflow: hidden;
}

.card img {
    width: 100%;
    height: 180px;
    object-fit: cover;
}

.card-content {
    padding: 15px;
}
</style>
</head>

<body>

<div id="main-content">

<h2>Results in <?php echo $city; ?></h2>

<h3>🏨 Accommodation</h3>

<div class="grid">
<?php
$sql1 = "SELECT * FROM accommodation WHERE acco_city LIKE '%$city%'";
$result1 = $conn->query($sql1);

if ($result1->num_rows > 0) {
    while ($row = $result1->fetch_assoc()) {
?>
    <div class="card">
        <img src="<?php echo $row['acco_image']; ?>">
        <div class="card-content">
            <h4><?php echo $row['acco_name']; ?></h4>
            <p>RM <?php echo $row['acco_price']; ?>/day</p>
        </div>
    </div>
<?php
    }
} else {
    echo "No accommodation found.";
}
?>
</div>

<!-- ================= ACTIVITIES ================= -->
<h3 style="margin-top:40px;">🎯 Activities</h3>

<div class="grid">
<?php
$sql2 = "SELECT * FROM activity WHERE activity_city LIKE '%$city%'";
$result2 = $conn->query($sql2);

if ($result2->num_rows > 0) {
    while ($row = $result2->fetch_assoc()) {
?>
    <div class="card">
        <img src="<?php echo $row['activity_image']; ?>">
        <div class="card-content">
            <h4><?php echo $row['activity_name']; ?></h4>
            <p><?php echo $row['activity_category']; ?></p>
        </div>
    </div>
<?php
    }
} else {
    echo "No activities found.";
}
?>
</div>

</div>

</body>
</html>