﻿<?php
include 'db_connect.php';

$success = false;

$error = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $email = $_POST["email"];
    $username = $_POST["username"];
    $password = $_POST["password"];
    if (strlen($password) < 8) {
    $error = "Password must be at least 8 characters long.";
    }
    $fullname = $_POST["fullname"];
    $phone = $_POST["phone"];
    if (!preg_match('/^[0-9+\-]+$/', $phone)) {
    $error = "Phone number can only contain numbers, + and -";
    }
    if (strlen($phone) < 7) {
    $error = "Phone number must be at least 7 characters long";
    }
    $gender = $_POST["gender"];

    $checkSql = "SELECT * FROM user WHERE user_email = '$email' OR user_name = '$username'";
    $result = $conn->query($checkSql);

    if (empty($error) && $result->num_rows > 0) {
        $row = $result->fetch_assoc();

        if ($row['user_email'] == $email) {
            $error = "Email is already in use.";
        } elseif ($row['user_name'] == $username) {
            $error = "Username is already taken.";
        }
    } elseif (empty($error)) {
        $sql = "INSERT INTO user (user_email, user_name, user_password, user_fullname, user_phone, user_gender)
                VALUES ('$email', '$username', '$password', '$fullname', '$phone', '$gender')";

        if ($conn->query($sql) === TRUE) {
            $success = true;
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <title>Register - TrippIn</title>
    <link rel="stylesheet" href="style.css">
</head>

<body class="auth-body">

    <h2 class="auth-title">TrippIn</h2>

    <div class="auth-container">
        <button class="close-x" onclick="window.location.href='home.php'">✕</button>

        <h3>Register</h3>

        <?php if (!empty($error)) { ?>
            <p style="color:red; margin-bottom:10px;"><?php echo $error; ?></p>
        <?php } ?>

        <form method="POST">
            <label>Email</label>
            <input type="email" name="email" required>

            <label>Username</label>
            <input type="text" name="username" required>

            <label>Password</label>
            <input type="password" name="password" required>

            <label>Full Name</label>
            <input type="text" name="fullname" required>

            <label>Phone Number</label>
            <input type="text" name="phone" pattern="[0-9+\-]+" title="Only numbers, + and - are allowed" required>

            <label>Gender</label>
            <select name="gender" required>
                <option value="">Select</option>
                <option value="Male">Male</option>
                <option value="Female">Female</option>
                <option value="Prefer not to say">Prefer not to say</option>
            </select>

            <button type="submit" class="auth-btn">Register</button>
        </form>
    </div>

    <div id="successModal" class="modal">
        <div class="modal-content">
            <h3>Registration Successful</h3>
            <button class="close-btn" onclick="goToLogin()">OK</button>
        </div>
    </div>

    <script>
        function goToLogin() {
            window.location.href = "login.php";
        }

        <?php if ($success) { ?>
            document.getElementById("successModal").style.display = "flex";
        <?php } ?>
    </script>

</body>
</html>