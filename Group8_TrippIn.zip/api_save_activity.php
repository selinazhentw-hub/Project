<?php
session_start();
header('Content-Type: application/json');
require_once 'db_connect.php';

if (!isset($_SESSION["admin_name"])) {
    echo json_encode(["success" => false, "message" => "Unauthorized"]);
    exit();
}

$admin_id = $_SESSION["admin_id"] ?? 1;

$action = $_POST['action'] ?? '';

$imageName = $_POST['existing_image'] ?? '';
if (isset($_FILES['image']) && $_FILES['image']['error'] === UPLOAD_ERR_OK) {
    $file = $_FILES['image'];
    $allowed = ['jpg', 'jpeg', 'png', 'gif'];
    $ext = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
    
    if (!in_array($ext, $allowed)) {
        echo json_encode(["success" => false, "message" => "Only JPG, PNG, GIF allowed"]);
        exit();
    }
    
    if ($file['size'] > 5 * 1024 * 1024) {
        echo json_encode(["success" => false, "message" => "File too large (max 5MB)"]);
        exit();
    }
    
    if (!file_exists('images')) {
        mkdir('images', 0777, true);
    }
    
    $imageName = uniqid() . '.' . $ext;
    $uploadPath = 'images/' . $imageName;
    
    if (!move_uploaded_file($file['tmp_name'], $uploadPath)) {
        echo json_encode(["success" => false, "message" => "Failed to save image"]);
        exit();
    }
}

$name = $_POST['activity_name'] ?? '';
$category = $_POST['activity_category'] ?? '';
$country = $_POST['activity_country'] ?? '';
$city = $_POST['activity_city'] ?? '';
$price = $_POST['activity_price'] ?? 0;
$address = $_POST['activity_address'] ?? '';
$description = $_POST['activity_description'] ?? '';

if ($action === 'add') {
    $sql = "INSERT INTO activity (activity_name, activity_category, activity_country, activity_city, 
            activity_price, activity_address, activity_description, activity_image, admin_id) 
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ssssdsssi", $name, $category, $country, $city, $price, $address, $description, $imageName, $admin_id);
} else if ($action === 'update') {
    $id = $_POST['activity_id'] ?? 0;
    $sql = "UPDATE activity SET activity_name=?, activity_category=?, activity_country=?, activity_city=?, 
            activity_price=?, activity_address=?, activity_description=?, activity_image=? 
            WHERE activity_id=?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ssssdsssi", $name, $category, $country, $city, $price, $address, $description, $imageName, $id);
} else {
    echo json_encode(["success" => false, "message" => "Invalid action"]);
    exit();
}

if ($stmt->execute()) {
    echo json_encode(["success" => true, "message" => "Saved successfully"]);
} else {
    echo json_encode(["success" => false, "message" => $conn->error]);
}
$stmt->close();
?>