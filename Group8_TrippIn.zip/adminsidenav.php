<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>TrippIn Admin</title>
    <link rel="stylesheet" href="style.css"> <!-- Referencing style.css[cite: 1, 4] -->
</head>

<body>
    <div id="side-nav">
        <button type="button" class="side-nav-button" onclick="window.location.href='adminhome.php'">
            <span><h1>TrippIn</h1></span> <!-- Red Rose font styling from style.css[cite: 1] -->
        </button>

        <button type="button" class="side-nav-button" onclick="window.location.href='adminactivities.php'">
            <span>Activities</span>
        </button>
        
        <button type="button" class="side-nav-button" onclick="window.location.href='adminacco.php'">
            <span>Accommodation</span>
        </button>
        
        <button type="button" class="side-nav-button" onclick="window.location.href='display_feedback.php'">
            <span>Feedback</span>
        </button>

        <div id="admin-logout">
            <button type="button" class="admin-logout-btn" onclick="if(confirm('Are you sure you want to logout?')) window.location.href='login.php'">
                <span>Logout</span>
            </button>
        </div>
    </div>
</body>
</html>