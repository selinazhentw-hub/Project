<?php
session_start();
header('Content-Type: application/json');
require_once 'db_connect.php';

if (!isset($_SESSION["admin_name"])) {
    echo json_encode(["success" => false, "message" => "Unauthorized"]);
    exit();
}

$sql = "SELECT * FROM activity ORDER BY activity_id DESC";
$result = $conn->query($sql);

$activities = [];
while ($row = $result->fetch_assoc()) {
    $activities[] = $row;
}

echo json_encode(["success" => true, "data" => $activities]);
?>