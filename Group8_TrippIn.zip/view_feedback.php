<?php
require_once "db_connect.php";

session_start();
$email = $_SESSION['user_email'] ?? '';   

if (empty($email)) {
    header("Location: login.php");
    exit;
}

$stmt = $conn->prepare("SELECT user_id, user_name FROM user WHERE user_email = ?");
$stmt->bind_param("s", $email);
$stmt->execute();
$user_data = $stmt->get_result()->fetch_assoc();
$stmt->close();

if (!$user_data) {
    die("User not found.");
}

$user_id   = $user_data['user_id'];
$user_info = $user_data;   

$sql = "SELECT f.*, u.user_name AS author_name, a.acco_name, act.activity_name
        FROM feedback f
        JOIN user u ON f.user_id = u.user_id
        LEFT JOIN accommodation a   ON f.acco_id     = a.acco_id
        LEFT JOIN activity      act ON f.activity_id = act.activity_id
        ORDER BY f.feedback_id DESC";

$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8"/>
    <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
    <title>TrippIn — My Feedback</title>
    
    <link rel="stylesheet" href="style.css">
    <style>
        .feedback-list {
            display: flex;
            flex-direction: column;
            gap: 14px;
            padding: 20px;
        }

        .feedback-card {
            background: #ffffff;
            border: 1px solid #e4ded4;
            border-radius: 12px;
            padding: 20px 24px;
            display: flex;
            align-items: flex-start;
            justify-content: space-between;
            gap: 16px;
            transition: box-shadow 0.2s;
        }

        .feedback-card:hover {
            box-shadow: 0 4px 20px rgba(0,0,0,0.07);
        }

        .feedback-body { flex: 1; }

        .feedback-place {
            font-size: 1rem;
            font-weight: 600;
            color: #1c1c1e;
            margin-bottom: 4px;
        }

        .feedback-author {
            font-size: 0.8rem;
            color: #888;
            margin-bottom: 8px;
        }

        .author-name {
            color: #1c1c1e;
            font-weight: 600;
        }

        .you-badge {
            display: inline-block;
            margin-left: 6px;
            padding: 2px 8px;
            background: #e8c97e;
            color: #1c1c1e;
            border-radius: 10px;
            font-size: 0.7rem;
            font-weight: 600;
        }

        .feedback-rating-row {
            display: flex;
            align-items: center;
            gap: 10px;
        }

        .stars { display: flex; gap: 3px; }
        .star.filled { color: #e8c97e; }
        .star.empty  { color: #d4cec6; }

        .feedback-comment {
            margin-top: 8px;
            font-size: 0.875rem;
            color: #7a7672;
            line-height: 1.55;
        }

        .feedback-photos {
            display: flex;
            flex-wrap: wrap;
            gap: 8px;
            margin-top: 12px;
        }

        .feedback-img {
            width: 100px;
            height: 100px;
            object-fit: cover;
            border-radius: 8px;
            border: 1px solid #e4ded4;
            cursor: pointer;
        }

        .feedback-img:hover {
            transform: scale(1.05);
        }

        .feedback-actions {
            display: flex;
            gap: 8px;
            flex-shrink: 0;
        }

        .btn-action {
            display: inline-flex;
            align-items: center;
            gap: 6px;
            padding: 8px 16px;
            border-radius: 8px;
            font-family: 'DM Sans', sans-serif;
            font-size: 0.8rem;
            font-weight: 500;
            cursor: pointer;
            text-decoration: none;
            border: none;
        }

        .btn-edit { background: #e8c97e; color: #1c1c1e; }
        .btn-delete { background: #f9eded; color: #b04040; }

        .lightbox {
            position: fixed;
            inset: 0;
            background: rgba(0,0,0,0.85);
            z-index: 99999;
            display: none;
            align-items: center;
            justify-content: center;
        }
        .lightbox.open { display: flex; }
        .lightbox img {
            max-width: 90vw;
            max-height: 90vh;
            border-radius: 10px;
        }
        .lightbox-close {
            position: absolute;
            top: 20px; right: 28px;
            color: #fff; font-size: 2rem;
            cursor: pointer; background: none; border: none;
        }

        .page-header {
            display: flex;
            align-items: flex-end;
            justify-content: space-between;
            margin: 20px 20px 0 20px;
            padding-bottom: 20px;
            border-bottom: 1px solid #e4ded4;
        }

        .page-header-left h1 {
            font-family: 'Playfair Display', serif;
            font-size: 1.75rem;
            font-weight: 700;
        }

        .username-highlight { color: #e8c97e; font-weight: 700; }

        .btn-add {
            background: #1c1c1e;
            color: #fff;
            border: none;
            padding: 10px 20px;
            border-radius: 8px;
            text-decoration: none;
            font-size: 0.875rem;
        }
    </style>
</head>
<body>

    <?php include 'sidenav.php'; ?>

    <div id="main-content">
        <div class="page-header">
            <div class="page-header-left">
                <h2><span class="username-highlight">Community</span> Feedback</h2>
                <p class="subtitle">Reviews and ratings shared by all travelers</p>
            </div>
            <a href="feedback.php" class="btn-add">+ Add Feedback</a>
        </div>

        <div class="feedback-list">
            <?php while($row = $result->fetch_assoc()) :
                $is_owner = ((int)$row['user_id'] === (int)$user_id);
            ?>
            <div class="feedback-card">
                <div class="feedback-body">
                    <div class="feedback-place">
                        <?php echo htmlspecialchars($row['activity_name'] ?: $row['acco_name']); ?>
                    </div>
                    <div class="feedback-author">
                        by <span class="author-name"><?php echo htmlspecialchars($row['author_name']); ?></span>
                        <?php if ($is_owner): ?><span class="you-badge">You</span><?php endif; ?>
                    </div>
                    <div class="feedback-rating-row">
                        <div class="stars">
                            <?php for($s = 1; $s <= 5; $s++): ?>
                                <span class="star <?php echo ($s <= $row['rating']) ? 'filled' : 'empty'; ?>">★</span>
                            <?php endfor; ?>
                        </div>
                    </div>
                    <p class="feedback-comment"><?php echo nl2br(htmlspecialchars($row['feedback_description'])); ?></p>

                    <?php
                    $f_id = $row['feedback_id'];
                    $photo_sql = "SELECT feedback_photo_url FROM feedback_photo WHERE feedback_id = $f_id";
                    $photo_res = $conn->query($photo_sql);
                    if ($photo_res && $photo_res->num_rows > 0):
                    ?>
                    <div class="feedback-photos">
                        <?php while($p = $photo_res->fetch_assoc()):
                            $src = "uploads/feedback/" . htmlspecialchars($p['feedback_photo_url']);
                        ?>
                            <img src="<?php echo $src; ?>"
                                 class="feedback-img"
                                 alt="Feedback photo"
                                 onclick="openLightbox('<?php echo $src; ?>')">
                        <?php endwhile; ?>
                    </div>
                    <?php endif; ?>
                </div>

                <?php if ($is_owner): ?>
                <div class="feedback-actions">
                    <a href="edit_feedback.php?id=<?php echo $row['feedback_id']; ?>" class="btn-action btn-edit">✏️ Edit</a>
                    <a href="delete_feedback.php?id=<?php echo $row['feedback_id']; ?>" class="btn-action btn-delete"
                       onclick="return confirm('Delete this feedback?');">🗑️ Delete</a>
                </div>
                <?php endif; ?>
            </div>
            <?php endwhile; ?>
            
            <?php if($result->num_rows == 0): ?>
            <div style="text-align: center; padding: 60px; color: #888;">
                <p>No feedback yet. Click "Add Feedback" to share your experience.</p>
            </div>
            <?php endif; ?>
        </div>
    </div>

    <div class="lightbox" id="lightbox" onclick="closeLightbox()">
        <button class="lightbox-close">✕</button>
        <img id="lightbox-img" src="" alt="Full photo">
    </div>

    <script>
        function openLightbox(src) {
            document.getElementById('lightbox-img').src = src;
            document.getElementById('lightbox').classList.add('open');
        }
        function closeLightbox() {
            document.getElementById('lightbox').classList.remove('open');
        }
        document.addEventListener('keydown', e => {
            if (e.key === 'Escape') closeLightbox();
        });
    </script>
</body>
</html>