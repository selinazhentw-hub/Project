<?php
session_start();
header('Content-Type: application/json');
require_once 'db_connect.php';

if (!isset($_SESSION["admin_name"])) {
    echo json_encode(["success" => false, "message" => "Unauthorized"]);
    exit();
}

$input = json_decode(file_get_contents('php://input'), true);
$id = $input['activity_id'] ?? 0;

$sql = "SELECT activity_image FROM activity WHERE activity_id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $id);
$stmt->execute();
$result = $stmt->get_result();
$row = $result->fetch_assoc();

if ($row && $row['activity_image']) {
    $imagePath = 'images/' . $row['activity_image'];
    if (file_exists($imagePath)) {
        unlink($imagePath);
    }
}

$sql = "DELETE FROM activity WHERE activity_id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $id);

if ($stmt->execute()) {
    echo json_encode(["success" => true, "message" => "Deleted successfully"]);
} else {
    echo json_encode(["success" => false, "message" => $conn->error]);
}
$stmt->close();
?>