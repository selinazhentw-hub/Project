<?php
session_start();
require_once "db_connect.php";

if (!isset($_SESSION["user_email"])) {
    header("Location: login.php");
    exit();
}

$email = $_SESSION["user_email"];
$u_res = $conn->query("SELECT user_id FROM user WHERE user_email = '$email'");
$user_id = $u_res->fetch_assoc()['user_id'];

if (isset($_GET['id']) && isset($_GET['type'])) {
    $wishlist_id = intval($_GET['id']);
    $type = $_GET['type'];
    
    if ($type === 'accommodation') {
        $sql = "UPDATE wishlist SET is_deleted = 1, acco_id = NULL 
                WHERE wishlist_id = ? AND user_id = ?";
    } elseif ($type === 'activity') {
        $sql = "UPDATE wishlist SET is_deleted = 1, activity_id = NULL 
                WHERE wishlist_id = ? AND user_id = ?";
    } else {
        header("Location: wishlist.php");
        exit();
    }

    if ($stmt = $conn->prepare($sql)) {
        $stmt->bind_param("ii", $wishlist_id, $user_id);
        $stmt->execute();
        $stmt->close();
    }
}

header("Location: wishlist.php");
exit();
?>