﻿<?php
include 'db_connect.php';

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

$error = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $login_input = $_POST["email"];
    $password = $_POST["password"];

    $sql = "SELECT * FROM user WHERE user_email='$login_input' OR user_name='$login_input'";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();

        if ($password == $row["user_password"]) {

            $_SESSION["user_email"] = $row["user_email"];

            header("Location: home.php");
            exit();
        } else {
            $error = "Wrong password";
        }

    } else {
        //If not found, check ADMIN table
        $sql2 = "SELECT * FROM admin WHERE admin_name='$login_input'";
        $result2 = $conn->query($sql2);

        if ($result2->num_rows > 0) {
            $row2 = $result2->fetch_assoc();

            if ($password == $row2["admin_password"]) {
                $_SESSION["admin_name"] = $row2["admin_name"];
                header("Location: adminhome.php");
                exit();
            } else {
                $error = "Wrong password";
            }

        } else {
            $error = "Email not found";
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <title>Login - TrippIn</title>
    <link rel="stylesheet" href="style.css">
</head>

<body class="auth-body">

    <!-- Page Title -->
    <h2 class="auth-title">TrippIn</h2>

    <!-- Login Box -->
    <div class="auth-container">
        <button class="close-x" onclick="window.location.href='home.php'">✕</button>

        <h3>Login</h3>

        <!-- Error message -->
        <?php if ($error != "") echo "<p>$error</p>"; ?>

        <form method="POST">
            <label>Email / Username</label>
            <input type="text" name="email" placeholder="Enter email or username" required>

            <label>Password</label>
            <input type="password" name="password" placeholder="Enter your password" required>

            <button type="submit" class="auth-btn">Login</button>
        </form>
    </div>

    <!-- Register Link -->
    <p class="auth-switch">
        No account? 
        <a href="signup.php">Click to register.</a>
    </p>

</body>
</html>
