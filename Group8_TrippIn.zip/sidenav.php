<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

include 'db_connect.php';

$profileName = "Guest";

if (isset($_SESSION["user_email"])) {

    $email = $_SESSION["user_email"];

    $sql = "SELECT user_name FROM user WHERE user_email='$email'";
    $profileResult = $conn->query($sql);

    if ($profileResult->num_rows > 0) {
        $profileRow = $profileResult->fetch_assoc();
        $profileName = $profileRow["user_name"];
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>TrippIn</title>
    <link rel="stylesheet" href="style.css">
    


</head>

<body>
    <div id="side-nav">

        <button type="button" name="goto_home" value="trippin" class="side-nav-button" onclick="window.location.href='home.php'">
            <span><h1>TrippIn</h1></span>
        </button>

        <button type="button" name="goto_activities" value="activities" class="side-nav-button" onclick="window.location.href='activities.php'">
            <span>Activities</span>
        </button>
        <button type="button" name="goto_accommodation" value="accommodation" class="side-nav-button" onclick="window.location.href='accommodation.php'">
            <span>Accommodation</span>
        </button>
        <button type="button" name="goto_itinerary" value="itinerary" class="side-nav-button" onclick="window.location.href='itinerary.php'">
            <span>Itinerary</span>
        </button>
        <button type="button" name="goto_wishlist" value="wishlist" class="side-nav-button" onclick="window.location.href='wishlist.php'">
            <span>Wish List</span>
        </button>
        <button type="button" name="goto_feedback" value="feedback" class="side-nav-button" onclick="window.location.href='view_feedback.php'">
            <span>Feedback</span>
        </button>
        <div id="profile">
            <button type="button" name="goto_profile" value="profile" class="profile-btn" onclick="window.location.href='profile.php'">
                <img src="https://cdn-icons-png.flaticon.com/512/6522/6522516.png" alt="Profile" height="50" width="50">
                <span>Profile, <?php echo $profileName; ?></span>
            </button>
        </div>
    </div>


</body>
</html>