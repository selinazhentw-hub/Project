﻿<?php
include 'db_connect.php';

$group_id = isset($_GET['group_id']) ? intval($_GET['group_id']) : 1;

//  Site 1 (main price)
$sql1 = "SELECT acco_name, acco_price FROM accommodation WHERE group_id = $group_id LIMIT 1";
$result1 = $conn->query($sql1);
$row1 = $result1->fetch_assoc();
if (!$row1) {
    echo "<div>No price data available</div>";
    exit();
}

//  Site 2 & 3 (other prices)
$sql2 = "SELECT acco_price FROM acco_price WHERE group_id = $group_id ORDER BY price_id ASC LIMIT 2";
$result2 = $conn->query($sql2);

$prices = [];
while ($row = $result2->fetch_assoc()) {
    $prices[] = $row['acco_price'];
}

$price2 = $prices[0] ?? "N/A";
$price3 = $prices[1] ?? "N/A";
?>

<div class="compare-row">
    <div class="left">
        <img src="images/airbnb.png">
        <a href="https://www.airbnb.com" target="_blank" class="compare-link">
        <span>Airbnb</span>
        </a>
    </div>
    <div class="right">
        RM <?php echo $row1['acco_price']; ?>
    </div>
</div>

<div class="compare-row">
    <div class="left">
        <img src="images/trip.png">
        <a href="https://www.trip.com" target="_blank" class="compare-link">
        <span>Trip</span>
        </a>
    </div>
    <div class="right">
        RM <?php echo $price2; ?>
    </div>
</div>

<div class="compare-row">
    <div class="left">
        <img src="images/booking.png">
        <a href="https://www.booking.com" target="_blank" class="compare-link">
        <span>Booking</span>
        </a>
    </div>
    <div class="right">
        RM <?php echo $price3; ?>
    </div>
</div>