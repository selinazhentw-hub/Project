-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: May 17, 2026 at 11:54 AM
-- Server version: 9.1.0
-- PHP Version: 8.3.14

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `trippin`
--

-- --------------------------------------------------------

--
-- Table structure for table `accommodation`
--

DROP TABLE IF EXISTS `accommodation`;
CREATE TABLE IF NOT EXISTS `accommodation` (
  `acco_id` int NOT NULL AUTO_INCREMENT,
  `group_id` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `admin_id` int NOT NULL,
  `acco_name` varchar(100) NOT NULL,
  `acco_type` varchar(50) NOT NULL,
  `acco_price` decimal(10,2) NOT NULL,
  `acco_country` varchar(50) NOT NULL,
  `acco_city` varchar(50) NOT NULL,
  `acco_address` text NOT NULL,
  `acco_description` text,
  `acco_image` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`acco_id`),
  UNIQUE KEY `currency_id` (`admin_id`),
  UNIQUE KEY `currency_id_2` (`group_id`),
  UNIQUE KEY `group_id` (`group_id`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `accommodation`
--

INSERT INTO `accommodation` (`acco_id`, `group_id`, `admin_id`, `acco_name`, `acco_type`, `acco_price`, `acco_country`, `acco_city`, `acco_address`, `acco_description`, `acco_image`) VALUES
(1, '1', 1, 'Infini Spacious 1 Queen Bedroom@D\'Majestic Pudu KL', 'Accommodation ', 167.00, 'Malaysia', 'Kuala Lumpur', '376, Jln Pudu, Pudu, 55100 Kuala Lumpur, Wilayah Persekutuan Kuala Lumpur', 'Located at the city centre in Kuala Lumpur, very nearby to Bukit Bintang area.\r\n\r\nEasily to Pavillion Mall, KLCC, China Town, Jalan Alor food street, Times Square and Lalaport in 5-10min drive.\r\n\r\nYou can also imagine yourself floating in the rooftop infinity pool, gazing down on the glittering city-skyline from level 20.\r\n\r\nPlease note due to the building age and location, the unit might prone to have cockroaches, and the furniture are slightly old.\r\n\r\nWe are non smoking unit\r\n\r\nThe space\r\nExperience the prestige in living in the modern city of Kuala Lumpur. The vibrant and energetic concept of the Residence offers spacious living room, with spectacular view and premier facilities for a relaxing escape.\r\n\r\nGuest access\r\nFacilities & Common Area\r\nUnlimited entertainment with premier facilities !\r\n\r\n[ROOFTOP] : Infinity View\r\n\r\n+ Infinity Swimming Pool\r\n+ Children Pool\r\n\r\n** if you wish to ‘touch’ the water, please wear proper swimming attire.\r\n\r\n\r\n+ Sky Lounge\r\nA perfect spot for relaxation, social and hang out.\r\n\r\n+ [24Hours convenient store]\r\n+ [walking distance shop and stall]\r\n\r\nOther things to note\r\nParking rate:\r\nFirst 2 Hours: RM2.50\r\nFor every subsequent hour: RM2.20\r\nMaximum per day: RM11\r\nPer entry (5:00pm-7:00pm): RM5.20\r\nPer entry (Sat, Sun & Public Holiday): RM5.20', 'Infini Spacious 1 Queen Bedroom@D\'Majestic Pudu KL'),
(2, '2', 2, '5m to metro, KL & NU Sentral , Riveria T#4 Studio', 'Studio', 130.00, 'Malaysia', 'Kuala Lumpur', 'Brickfields, 50470 Kuala Lumpur, Federal Territory of Kuala Lumpur', 'Nestled in the heart of Kuala Lumpur, this stylish studio apartment offers the perfect blend of comfort and convenience. Located in the prestigious Riveria City Residency, you\'ll enjoy the utmost convenience during your stay!\r\n\r\nWhy you should stay with us?\r\n✨300m to KL Sentral (Transportation hub - LRT, MRT, KTM, Monorail & bus)\r\n✨Located within walking distance of NU Sentral Shopping Mall & eateries in Brickfields\r\n✨Our co-worker station and conference room, are perfect for meetings and gatherings\r\n\r\nThe space\r\nThe studio includes\r\n- Queen bed (sleeps 2 comfortably; Asian beds are 5 ft long)\r\n- En-suite bathroom with sink and shower, plus shampoo and soap\r\n- Fresh 300TC hotel-quality linens and towels, professionally laundered\r\n- Iron, ironing board, and hairdryer\r\n- TV\r\n- Kitchen includes coffee, electric kettle, refrigerator, induction stove & kitchen hob, pots & pans, and necessary cutleries\r\n\r\nEnjoy staying with us!\r\n\r\n*Note: This is a multi-listing with several units featuring similar designs.*\r\n*Some of our listings are dual key units.\r\n\r\nGuest access\r\nFACILITIES AVAILABLE\r\nYou are welcome to enjoy our facilities, as follows:\r\n\r\nSwimming Pool (Level 53A) 8:00 AM to 10:00 PM\r\nPoolside lounge (Level 53A) 8:00 AM to 7:00 PM\r\nJacuzzi (Level 53A) 8:00 AM to 7:00 PM\r\nGymnasium (Level 53) 8:00AM to 10:00PM\r\nCo-Worker Station (Level 53) 8:00 AM to 10:00 PM\r\n\r\n(Please note that the sauna is currently under maintenance. We apologize for the inconvenience.)\r\n\r\nTips: To reach KL Sentral and NU Sentral, take the monorail from Tun Sambathan; it takes under 5 minutes.\r\n\r\nOther things to note\r\nPlease be advised that construction is currently underway in the building. We apologize for any inconvenience this may cause.', '5m to metro, KL & NU Sentral , Riveria T#4 Studio'),
(3, '3', 3, 'Sunrise Forest View | 4 minutes to 1Utama IKEA PJ', 'Accommodation ', 120.00, 'Malaysia', 'Petaling Jaya', 'Jalan PJU 8/1, Damansara Perdana, 47820 Petaling Jaya, Selangor, Malaysia', 'Why choose Luna Homes,\r\n1. 4K SMART TV with a complimentary Netflix subscription.\r\n2. Free access to co-working lounge (23A floor).\r\n3. Rooftop salt water swimming pool & jacuzzi with a hill view (25th floor)\r\n4. High-speed WiFi.\r\n5. Free access to a fully equipped gym.\r\n\r\nThe space\r\n• Studio - 1 Queen Bed\r\n\r\n【Living Room】\r\n• 4K Smart TV with complimentary Netflix account\r\n\r\n【Pantry】\r\n• Microwave to reheat food\r\n• Mini bar fridge\r\n• Bowls, Plates, Spoon, Fork, Mugs, Wine Glasses, Wine opener, Knife, Scissors provided\r\n• Kettle\r\n• Complimentary Coffee & Tea\r\n\r\n【Other Miscellaneous Items Provided】\r\n• Comfortable quilt with clean quilt cover\r\n• Large towels\r\n• Water Heater\r\n• Toilet rolls\r\n• 2 in 1 - Hair and Body shampoo\r\n• Hair Dryer\r\n• Iron & Ironing Board\r\n\r\nGuest access\r\nLEVEL B4/B2/B1/LG2/LG1\r\n• Car Park\r\n\r\nLEVEL B3\r\n• Car Park\r\n• Grab / Taxi Drop Off\r\n\r\nLEVEL G\r\n• Main Lobby with Free internet\r\n\r\nLEVEL 23A\r\n• 【Free to use】 Co-living Lounge with Free internet\r\n\r\nLEVEL 25 (TOP FLOOR)\r\n• Rooftop Swimming pool with green hill view\r\n• Pool Lounge\r\n• Jacuzzi\r\n• Garden Lounge\r\n- 【Booking needed】Dome Lounge - Multipurpose hall\r\n- 【Booking needed】Pre-function Lounge\r\n- 【Booking needed】Dining Lounge with Karaoke room\r\n\r\nOther things to note\r\n【Please take note before booking】\r\n\r\nParking\r\n· Covered paid parking is available on-site, payable by TNG, Visa / Mastercard.\r\nRM2 for every 3 hours\r\nRM 6 maximum per 24 hours, per entry\r\n\r\nAccess Card\r\n· One (1) access card is provided per booking.\r\n· A replacement fee of RM 200 will be charged for lost or damaged cards.\r\n------------------------------------------------\r\n\r\nOTHER SERVICES:\r\n1. Personal Hygiene Items\r\n- For hygiene reasons, we do not provide indoor slippers, toothpaste, or toothbrushes. Bath towels are provided.\r\n\r\n2. Towel Service\r\n- Daily towel / linen changes are not provided. Fresh linens can be requested at (available daily from 10:00 AM to 5:00 PM) :\r\nRM 10 per towel\r\nRM 5 per pillow case\r\nRM 10 per bedsheet\r\nRM 15 per blanket/duvet\r\n\r\n3. Cleaning Fee\r\n⁃ A one-time cleaning fee included in your booking is to cover cleaning after you check out.\r\n⁃ For stays longer than 3 nights, we provide one (1) complimentary cleaning.\r\n⁃ Complimentary cleaning covers general tidying only and does not include linen or towel replacement.\r\n\r\n4. Additional Cleaning Services\r\n⁃ Mid-stay cleaning is available upon request at RM 50 per session, and includes linen replacement (between 10:00 AM and 5:00 PM, with at least one day’s notice).\r\n⁃ For cleaning on Fridays to Sundays, special arrangements are required. Please message us in advance to coordinate.\r\n\r\n5. Amenities Provided\r\n⁃ We provide Nescafé coffee, tea, and bottled water as starter amenities. No replenishment is provided during the stay.\r\nRefill available at RM5 per set (1 set = 2 servings).\r\n\r\n6. Damages and Stains\r\n- Unremovable stains or damages to furniture or fittings may incur additional charges. Fees for stained linens are as follows:\r\n▪ Bath Towel: RM 40\r\n▪ Bath Mat: RM 20\r\n▪ Duvet Cover: RM 140\r\n▪ Bed Sheet: RM 80\r\n▪ Pillowcase: RM 20\r\n\r\n7. Appliances\r\n- All appliances are checked before your arrival. If you notice any issues, please let us know within 1 hour of check-in. Any damages that occur during your stay may incur replacement / repair costs.\r\n\r\n\r\n8. Power Plug and Voltage\r\n- Malaysia uses a Type-G 3-pin power plug (same as the UK) with a voltage of 220-240V. Please bring a universal adapter and voltage converter for your devices.\r\n\r\n9. Check-Out and Left-Behind Items\r\n- Double-check your belongings before check-out. We are not responsible for items left behind. Housekeeping will dispose of all items unless clearly marked as a tip.\r\n\r\n10. Check-In and Check-Out Times\r\n- Check-In: Check-in time is from 3:00 PM onwards.\r\nEarly check-in is subject to availability and charged at RM 20/hour.\r\n\r\n- Check-Out: Check-out time is by 11:00 AM.\r\nLate check-out fees apply as follows:\r\n▪ If the unit is booked on your check-out day: RM 20 per 30 minutes (up to 1:30 PM max).\r\n▪ Full-day rate applies for check-outs at 3:00 PM or later.\r\n\r\n11. Guest Registration\r\n- Ensure your booking reflects the correct number of guests. The unit will be prepared accordingly.\r\n\r\n------------------------------------------------\r\n\r\n1 No Parties or Illegal Activities\r\n- STRICTLY no parties, loud noise, or illegal activities are allowed. Please respect other residents when using common areas and facilities. We value our neighbors and expect our guests to do the same. Violations will result in immediate removal without a refund.\r\n\r\n2 Do Not Stick Anything on Walls\r\n- Do not stick anything on walls or wallpaper, as it will peel off. You may use windows or window frames as long as no stains or damage are left upon removal. Any peeled paint will incur a charge of RM 30 per spot.\r\n\r\n3 Non-Smoking Unit\r\n- This is a strictly NON-SMOKING unit. If any smoke smell or signs of smoking are detected, a minimum charge of RM500 will apply for cleaning and restoration. Additional charges may apply for damages, including a minimum of 2 days\' income loss due to downtime.\r\n\r\nThank you! We look forward to ensuring a pleasant experience for both you and us 😊', 'Sunrise Forest View , 4 minutes to 1Utama IKEA PJ'),
(4, '4', 4, 'TRION The Teneighth Studio For 4', 'Studio', 890.00, 'Malaysia', 'Kuala Lumpur', 'Chan Sow Lin, 55200 Kuala Lumpur, Federal Territory of Kuala Lumpur', 'THE SENYUM Teneighth Studio @ TRION KL\r\n\r\nKL city view + pool view\r\n\r\n2 Queen beds Perfect for 4 Adults\r\nStudio unit\r\n\r\n- WIFI\r\n- Projector\r\n- Air-conditioning\r\n- Water Heater\r\n- Mini fridge\r\n- Iron and ironing board\r\n\r\n2.6 KM to IKEA CHERAS and Sunway Velocity\r\n3.5 KM to BBCC LALAPORT\r\n3.9 KM to BERJAYA TIMES SQUARE , LOT 10 and Sungei Wang\r\n4.8 KM to PAVILLION BUKIT BINTANG\r\n\r\n\r\n\r\n\r\nUnit doesn\'t come with free car parking lot , commercial car parking lot available with pay-per-use basis\r\n\r\nThe space\r\nThis is a dual key layout apartment , One main door opens into a foyer, which then splits into two self-contained units. Both units will have their own door and occupied separately, giving privacy equal to individual apartments.\r\n\r\nAll the pictures showing on the listing , are non-sharing and for your private use only.\r\n\r\nOnly the main fire rated door will be shared with one neighbour.\r\n\r\nGuest access\r\nGuest may refer to the pictures to get an idea of the living space , all of the pictures are taken from the exact unit .\r\n\r\nGuest can also use swimming pools , gym , sauna .', 'TRION The Teneighth Studio For 4'),
(5, '5', 5, 'Paxtonz- near Kepong, PJ, IKEA, Paradigm & 1 Utama', 'Hotel', 86.00, 'Malaysia', 'Petaling Jaya', 'Jalan PJU 8/1, Damansara Perdana, 47820 Petaling Jaya, Selangor, Malaysia', 'Paxtonz Petaling Jaya – Comfort near Shopping & Business Hubs\r\n\r\nWelcome to Paxtonz Petaling Jaya, your home away from home in one of KL’s most vibrant suburbs. Whether you’re here for work, shopping, or a weekend escape, our apartment offers everything you need for a comfortable and stress-free stay.\r\n\r\nThe space\r\nOur unit is thoughtfully designed with modern furnishings and cozy touches to make you feel right at home. Enjoy a spacious living area with a smart TV, high-speed WiFi for work or entertainment, and a well-equipped kitchen for simple meals or coffee breaks. The bedrooms feature comfortable bedding to ensure a restful night’s sleep after a busy day.\r\n\r\n🏊 Facilities\r\nAs our guest, you’ll have access to building amenities including a swimming pool, and secure parking. With 24-hour security, you can relax knowing your stay is safe and worry-free.\r\n\r\nOther than that, it is also equipped:-\r\n\r\n1) Queen Size Bed x 1\r\n2)Towels, Body Gel and Shampoo only\r\n3) Mini Fridge\r\n4) Wifi\r\n5) Smart TV (Netflix account is not provided)\r\n6) Water Heater\r\n7) Air Conditioning\r\n8) Basic Cleaning Materials\r\n9) Hair dryer\r\n10) Iron\r\n11) Oil, Sugar , Salt and peppers are not provided\r\n\r\n\r\nCASUAL INDOOR PARKING RATE:\r\n\r\n- 1st 3hours or Part Thereof (RM2.00)\r\n- Every Subsequent 3 Hour or Part Thereof (RM2.00)\r\n- Maximum (per day) (RM6.00)\r\n- Lost Ticket/Card (per day) (RM20.00)\r\n- Clamping Fee (RM100.00)\r\n\r\nPAYMENT METHOD FOR PARKING:\r\n- TnGo, Debit and Credit Card only\r\n\r\n\r\nPlease note that:-\r\n1) The unit is strictly a non-smoking unit.\r\n2) The Check-in time is 3 pm\r\n3) The check out time is 11am\r\n4) Early check in (before 3pm) or Late check out (after 11am) will be charged at Rm50 per hour.\r\n5) Rooms which were handed over late due to unforeseen circumstances , will be compensated via the same amount of time as late check out, instead of in the form of monetary.\r\n6) No party is allowed\r\n7) No Over-pax\r\n8) No food leftover and uncleaned dishes after check out. Additional cleaning will be charged if there is\r\n9) No smoking in the unit. RM500 additional cleaning fee will be imposed if found.\r\n10) Quiet hour is 7 pm onwards\r\n11) All guests have to present a photo identification upon check-in\r\n12) Prior arrangement and/or approval for Photo and Video Shooting is needed\r\n13) For monthly stay, we only cover the electricity usage up to RM150.00 per month. A utility deposit of RM500.00 is required. The deposit will be refunded after the electricity bill is issued by TNB and no outstanding.\r\n14) No deposit for short-term stay.\r\n\r\n📍Location Highlights\r\nOur apartment is located just minutes from top shopping malls like 1 Utama, Paradigm Mall, and IKEA Damansara, as well as PJ’s bustling food and café scene. Business travelers will find easy access to nearby corporate hubs, while families and leisure guests can explore countless dining and entertainment options. The unit is also conveniently connected to major highways, making travel to Kuala Lumpur, Subang, or Shah Alam quick and easy.', 'Paxtonz- near Kepong, PJ, IKEA, Paradigm & 1 Utama'),
(6, '6', 6, 'Single room, shared bathroom in Tanjong Pagar', 'Hotel', 175.00, 'Singapore', 'Tanjong Pagar', '32 Tras St, Singapore 078972', 'This property is located in Singapore’s central business district and is less than 10 minutes walk away from Tanjong Pagar and Outram MRT Station. Close by, you\'ll find fascinating Chinatown, the Tanjong Pagar Conservation District, key office buildings, banks, shops, as well as dining and entertainment establishments. Treat yourself to a sample of Singapore’s most loved local dishes at reasonable prices at nearby Maxwell and Amoy Street food center.\r\n\r\nThe space\r\nPrivate Cabin( 6 sqm) is equipped with one single sized bed, suitable for 1 adult. (Bed type allocation is subjected to availability). Bathroom is communal bathroom.\r\n\r\nIn room amenities include towels, safe, TV, vanity area and writing table with chair.\r\n\r\nRate is inclusive of Wifi, bath amenities (dispenser) and complimentary usage of the communal kitchen. Complimentary water (dispenser) and premium coffee/tea is available 24/7 at the communal kitchen.\r\nVending machine and luggage locker (own padlock) are available at the premise for convenience.\r\n\r\nOther things to note\r\n- Check-in time is from 1500 hours(GMT+8) and check-out time is by 1200 hours (GMT+8).\r\n- Please note that our hotel practices self-check-in. Please download the ‘ST Signature Chat-In’ mobile App in advance from Apple App Store or Play Store for ease of checking in. Thereafter, follow the instructions as prompted. Please note that you can complete your pre-arrival registration 6 days prior to arrival date. However, check in can only be completed while you are present at the hotel.\r\n- It is a must to check in with either your physical NRIC, FIN Card or passport. A selfie is required for check-in to match with the identification uploaded.\r\n- To unlock the door, please turn on Bluetooth on the phone and scan the phone over the door lock.\r\n- Early check-in and late checkout are subjected to availability and charges may apply. Please contact Community Hosts via the chat for the arrangement.\r\n- Extra bed is not allowed in all room types\r\n- If you are travelling with young children or the elderly, it is advisable to request for rooms with lower beds.\r\n- Smoking is strictly prohibited on the premises. A SGD 100 fine will be charged to any guest who violates the smoking policy.\r\n- The minimum age required to check in is 18 years. Children or guests who are under 18 years old must be accompanied by parents or with written consent of parents/guardians.\r\n- Visitors are not allowed in the room.\r\n- For special requests, please write in and note that special requests are subject to availability, cannot be guaranteed and may incur additional charges.\r\n- Please note that renovation noises surrounding the building are expected from now till further notice.\r\n\r\nRegistration Details\r\nS0464', 'Single room, shared bathroom in Tanjong Pagar'),
(7, '7', 7, 'H81 Princess', 'Hotel', 217.00, 'Singapore', 'Geylang', '21 Lorong 12 Geylang, Singapore 399001', 'Experience a simple yet wonderful stay in Geylang at our Hotel 81 Premier Princess. We’re near the Aljunied MRT station and Guillemard Road bus stand. Our guest rooms are simple and clean, with essential amenities for a fuss-free stay in the city. Enjoy complimentary in-room beverages and count on our friendly staff to help direct you to the nearest attractions.', 'H81 Princess'),
(8, '8', 8, 'Your Capsule Pod in Singapore (FP-API-401)', 'Sleep Pod', 115.00, 'Singapore', 'Singapore', '38 Upper Cross Street, #02-01 & #03-01, Singapore 058341.', NULL, 'Your Capsule Pod in Singapore (FP-API-401)'),
(9, '9', 9, '(New!) 2 Mins to Clarke Quay MRT! - Large Bunk Bed', 'Sleep Pod', 139.00, 'Singapore', 'HongKong St', '5 Hongkong St, Singapore 059648', 'Welcome to City Backpackers - Hostel and Private Rooms!\r\n\r\nLarge Bunk Bed (1.2 meters wide) so you can stretch out and enjoy a perfect sleep after your day of exploring Singapore!\r\n\r\nWe have 14 of these beds in the mixed dorm room with 6 shared bathroom and shower stalls with branded quality amenities\r\n\r\nEnjoy easy access to popular shops and restaurants from this charming place to stay. Easy connectivity to all parts of Singapore through 3 MRT stations - Chinatown, Clarke Quay, Raffles Place\r\n\r\nRegistration Details\r\nS0257', '(New!) 2 Mins to Clarke Quay MRT! - Large Bunk Bed'),
(10, '10', 10, 'Single Cabin Pod w Shared Bathroom (Cloudbeds)', 'Hotel', 262.00, 'Singapore', 'Tyrhitt Rd', 'Blanc Inn, 151 Tyrwhitt Rd, Singapore 207564 ', 'We are co-living hostel located conveniently in Lavender/Kallang area.\r\n\r\nRoom-like Cabin Pod (4.2 square meter) for 1 pax. Strong air-conditioning are available inside the cabin pod. Bathrooms, lounge and pantry area are shared and located outside your room. Cabin pod are private & accessible with key card.\r\n\r\nSingle bed, safe box, slippers, dental kit & towels are available in the pod. Ear plugs are available upon request.\r\n\r\n3 MRT Nearby: Bendemeer (Blue)/ Lavender (Green)/ Farrer Park (Purple).\r\n\r\nGuest access\r\nGuest have access to sharing bathrooms, showers, working space, pantry & reception.\r\n\r\nAfter checking out, guest may leave their luggage at the luggage storage next to the reception.\r\n\r\nSharing bathrooms and showers are available after check-out upon request. Staff will send one-time QR code for access.\r\n\r\nOther things to note\r\nThis listing has multiple units of similar layout. Photos provided are for illustration purposes only. All photos are taken with wide-angle lens.\r\nMost of the Single pod comes with a bed frame however, some room bed mattress will be on the floor. Room allocation will be assign subject to availability.\r\n\r\nStandard check-in time is 2pm. Early check-in between 09:00AM and 02:00PM will be subjected to availability and extra charges. Contactless Check-in Kiosk is available 24/7.\r\n\r\nRegistration Details\r\nS0251', 'Single Cabin Pod w Shared Bathroom (Cloudbeds)');

-- --------------------------------------------------------

--
-- Table structure for table `acco_price`
--

DROP TABLE IF EXISTS `acco_price`;
CREATE TABLE IF NOT EXISTS `acco_price` (
  `price_id` int NOT NULL AUTO_INCREMENT,
  `group_id` int NOT NULL,
  `acco_price` decimal(10,2) NOT NULL,
  PRIMARY KEY (`price_id`)
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `acco_price`
--

INSERT INTO `acco_price` (`price_id`, `group_id`, `acco_price`) VALUES
(1, 1, 180.00),
(2, 1, 160.00),
(3, 2, 115.00),
(4, 2, 135.00),
(5, 3, 100.00),
(6, 3, 140.00),
(7, 4, 790.00),
(8, 4, 950.00),
(9, 5, 66.00),
(10, 5, 75.00),
(11, 6, 200.00),
(12, 6, 195.00),
(13, 7, 220.00),
(14, 7, 235.00),
(15, 8, 100.00),
(16, 8, 103.00),
(17, 9, 144.00),
(18, 9, 159.00),
(19, 10, 260.00),
(20, 10, 250.00);

-- --------------------------------------------------------

--
-- Table structure for table `activity`
--

DROP TABLE IF EXISTS `activity`;
CREATE TABLE IF NOT EXISTS `activity` (
  `activity_id` int NOT NULL AUTO_INCREMENT,
  `admin_id` int DEFAULT NULL,
  `activity_name` varchar(100) NOT NULL,
  `activity_category` varchar(50) DEFAULT NULL,
  `activity_country` varchar(50) NOT NULL,
  `activity_city` varchar(50) NOT NULL,
  `activity_address` text,
  `activity_description` text,
  `activity_price` decimal(10,2) NOT NULL,
  `activity_image` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`activity_id`)
) ENGINE=InnoDB AUTO_INCREMENT=67 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `activity`
--

INSERT INTO `activity` (`activity_id`, `admin_id`, `activity_name`, `activity_category`, `activity_country`, `activity_city`, `activity_address`, `activity_description`, `activity_price`, `activity_image`) VALUES
(17, 1, 'Petronas Twin Towers Skybridge', 'Sightseeing', 'Malaysia', 'Kuala Lumpur', 'Concourse Level, Lower Ground, KLCC', 'Walk across the world\'s highest two-story bridge connecting the iconic twin towers.', 100.00, 'twintowerbridge.png'),
(18, 1, 'Batu Caves Rainbow Stairs Tour', 'Culture', 'Malaysia', 'Kuala Lumpur', 'Gombak, 68100 Batu Caves', 'Climb the 272 vibrant, colorful steps leading into a massive limestone cave temple.', 0.00, 'batu_caves.jpg'),
(22, 1, 'Penang Hill Funicular Railway', 'Sightseeing', 'Malaysia', 'Penang', 'Jalan Stesen, Bukit Bendera', 'Ride the historic funicular train up 821 meters to enjoy the cool breezes of Penang Hill.', 30.00, 'penang_hill_train.jpg'),
(27, 1, 'Shibuya Sky Observation Deck', 'Sightseeing', 'Japan', 'Tokyo', '2-24-12 Shibuya', 'Stunning 360-degree open-air views of Tokyo from the top of Shibuya Scramble Square.', 220.00, 'shibuya_sky.jpg'),
(31, 1, 'Akihabara Go-Kart Tour', 'Adventure', 'Japan', 'Tokyo', '4-12-9 Sotokanda, Chiyoda', 'Dress up in anime costumes and drive street-legal go-karts through Tokyo.', 500.00, 'akiba_kart.jpg'),
(37, 1, 'Eiffel Tower Summit Access', 'Sightseeing', 'France', 'Paris', 'Champ de Mars, 5 Av. Anatole France', 'Ride the glass elevator to the top floor of the iconic Eiffel Tower.', 29.00, 'eiffel_summit.jpg'),
(41, 1, 'Moulin Rouge Cabaret Show', 'Entertainment', 'France', 'Paris', '82 Boulevard de Clichy', 'The world-famous bohemian cabaret show featuring spectacular costumes and dance.', 130.00, 'moulin_rouge.jpg'),
(46, 1, 'Disneyland Paris 1-Day Pass', 'Entertainment', 'France', 'Paris', 'Boulevard de Parc, Coupvray', 'Experience the magic of Disneyland Park and Walt Disney Studios.', 99.00, 'disneyland_paris.jpg'),
(47, 1, 'Empire State Building Observatory', 'Sightseeing', 'USA', 'New York City', '20 W 34th St.', 'Take in breathtaking 360-degree views of Manhattan from the 86th floor.', 44.00, 'empire_state.jpg'),
(48, 1, 'Statue of Liberty Ferry & Island', 'Sightseeing', 'USA', 'New York City', 'Battery Park', 'Take a scenic ferry ride to Liberty Island and the Ellis Island National Museum.', 25.00, 'statue_liberty.png');

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

DROP TABLE IF EXISTS `admin`;
CREATE TABLE IF NOT EXISTS `admin` (
  `admin_id` int NOT NULL AUTO_INCREMENT,
  `admin_name` varchar(50) NOT NULL,
  `admin_password` varchar(255) NOT NULL,
  PRIMARY KEY (`admin_id`),
  UNIQUE KEY `admin_id` (`admin_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`admin_id`, `admin_name`, `admin_password`) VALUES
(1, 'Teoh', '0062');

-- --------------------------------------------------------

--
-- Table structure for table `feedback`
--

DROP TABLE IF EXISTS `feedback`;
CREATE TABLE IF NOT EXISTS `feedback` (
  `feedback_id` int NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `acco_id` int DEFAULT NULL,
  `rating` tinyint NOT NULL,
  `feedback_description` text NOT NULL,
  `activity_id` int DEFAULT NULL,
  PRIMARY KEY (`feedback_id`) USING BTREE,
  KEY `feedback_id` (`feedback_id`),
  KEY `user_id` (`user_id`) USING BTREE,
  KEY `activity_id` (`activity_id`) USING BTREE,
  KEY `acco_id` (`acco_id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- --------------------------------------------------------

--
-- Table structure for table `feedback_photo`
--

DROP TABLE IF EXISTS `feedback_photo`;
CREATE TABLE IF NOT EXISTS `feedback_photo` (
  `feedback_photo_id` int NOT NULL AUTO_INCREMENT,
  `feedback_id` int NOT NULL,
  `feedback_photo_url` varchar(255) NOT NULL,
  PRIMARY KEY (`feedback_photo_id`),
  KEY `feedback_photo_id` (`feedback_photo_id`) USING BTREE,
  KEY `fk_feedbackphoto_feedback` (`feedback_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- --------------------------------------------------------

--
-- Table structure for table `itinerary`
--

DROP TABLE IF EXISTS `itinerary`;
CREATE TABLE IF NOT EXISTS `itinerary` (
  `itinerary_id` int NOT NULL AUTO_INCREMENT,
  `est_total` decimal(10,2) NOT NULL,
  `user_id` int NOT NULL,
  `group_id` int NOT NULL,
  PRIMARY KEY (`itinerary_id`),
  KEY `user_id` (`user_id`),
  KEY `items_id` (`group_id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `itinerary`
--

INSERT INTO `itinerary` (`itinerary_id`, `est_total`, `user_id`, `group_id`) VALUES
(8, 0.00, 1, 8);

-- --------------------------------------------------------

--
-- Table structure for table `itinerary_items`
--

DROP TABLE IF EXISTS `itinerary_items`;
CREATE TABLE IF NOT EXISTS `itinerary_items` (
  `items_id` int NOT NULL AUTO_INCREMENT,
  `group_id` int NOT NULL,
  `item_id` int NOT NULL,
  `item_category` varchar(50) NOT NULL,
  PRIMARY KEY (`items_id`),
  KEY `group_id` (`group_id`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `itinerary_items`
--

INSERT INTO `itinerary_items` (`items_id`, `group_id`, `item_id`, `item_category`) VALUES
(11, 8, 18, 'Activity');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

DROP TABLE IF EXISTS `user`;
CREATE TABLE IF NOT EXISTS `user` (
  `user_id` int NOT NULL AUTO_INCREMENT,
  `user_name` varchar(50) NOT NULL,
  `user_fullname` varchar(255) NOT NULL,
  `user_password` varchar(50) NOT NULL,
  `user_email` varchar(50) NOT NULL,
  `user_gender` varchar(20) NOT NULL,
  `user_phone` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `profile_pic` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`user_id`),
  UNIQUE KEY `user_id` (`user_id`),
  UNIQUE KEY `user_email` (`user_email`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`user_id`, `user_name`, `user_fullname`, `user_password`, `user_email`, `user_gender`, `user_phone`, `profile_pic`) VALUES
(1, 'jessicalai99', 'Jessica Lai', 'jessie333', 'jessicalai99@yahoo.com', 'Prefer not to say', '01152336669', 'uploads/69f9e65c1b182.jpeg');

-- --------------------------------------------------------

--
-- Table structure for table `wishlist`
--

DROP TABLE IF EXISTS `wishlist`;
CREATE TABLE IF NOT EXISTS `wishlist` (
  `wishlist_id` int NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `acco_id` int DEFAULT NULL,
  `activity_id` int DEFAULT NULL,
  `is_deleted` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`wishlist_id`),
  KEY `user_id` (`user_id`),
  KEY `acco_id` (`acco_id`),
  KEY `activity_id` (`activity_id`),
  KEY `wishlist_id` (`wishlist_id`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `wishlist`
--

INSERT INTO `wishlist` (`wishlist_id`, `user_id`, `acco_id`, `activity_id`, `is_deleted`) VALUES
(12, 1, NULL, NULL, 1),
(13, 1, NULL, 27, 0),
(14, 1, NULL, 18, 0);

--
-- Constraints for dumped tables
--

--
-- Constraints for table `feedback_photo`
--
ALTER TABLE `feedback_photo`
  ADD CONSTRAINT `fk_feedbackphoto_feedback` FOREIGN KEY (`feedback_id`) REFERENCES `feedback` (`feedback_id`) ON DELETE RESTRICT ON UPDATE RESTRICT;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
