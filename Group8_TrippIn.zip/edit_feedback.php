<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
require_once "db_connect.php";

// Validate ID
if (!isset($_GET['id']) || !is_numeric($_GET['id'])) {
    header("Location: view_feedback.php");
    exit;
}

$id = (int) $_GET['id'];

$stmt = $conn->prepare("SELECT * FROM feedback WHERE feedback_id = ?");
$stmt->bind_param("i", $id);
$stmt->execute();
$row = $stmt->get_result()->fetch_assoc();
$stmt->close();

if (!$row) {
    header("Location: view_feedback.php");
    exit;
}


$place_name = 'Place';
if (!empty($row['acco_id'])) {
    $ps = $conn->prepare("SELECT acco_name FROM accommodation WHERE acco_id = ?");
    $ps->bind_param("i", $row['acco_id']);
    $ps->execute();
    $prow = $ps->get_result()->fetch_assoc();
    $ps->close();
    if ($prow) $place_name = $prow['acco_name'];
} elseif (!empty($row['activity_id'])) {
    $ps = $conn->prepare("SELECT activity_name FROM activity WHERE activity_id = ?");
    $ps->bind_param("i", $row['activity_id']);
    $ps->execute();
    $prow = $ps->get_result()->fetch_assoc();
    $ps->close();
    if ($prow) $place_name = $prow['activity_name'];
}

if (isset($_POST['updateBtn'])) {
    $rating = (int) $_POST['rating'];
    $desc   = $_POST['description'];

    $upd = $conn->prepare("UPDATE feedback SET rating = ?, feedback_description = ? WHERE feedback_id = ?");
    $upd->bind_param("isi", $rating, $desc, $id);
    if($upd->execute()){
        $upd->close();
        if (!empty($_FILES['photos']['name'][0])) {
            
            $old = $conn->prepare("SELECT feedback_photo_url FROM feedback_photo WHERE feedback_id = ?");
            $old->bind_param("i", $id);
            $old->execute();
            $old_result = $old->get_result();
            while ($old_photo = $old_result->fetch_assoc()) {
                $old_path = "uploads/feedback/" . $old_photo['feedback_photo_url'];
                if (file_exists($old_path)) unlink($old_path);
    }
    $old->close();

    $del = $conn->prepare("DELETE FROM feedback_photo WHERE feedback_id = ?");
    $del->bind_param("i", $id);
    $del->execute();
    $del->close();

   $upload_dir = "uploads/feedback/";
            if (!is_dir($upload_dir)) mkdir($upload_dir, 0755, true);

            $photo_stmt = $conn->prepare("INSERT INTO feedback_photo (feedback_id, feedback_photo_url) VALUES (?, ?)");
            foreach ($_FILES['photos']['tmp_name'] as $key => $tmp) {
                if ($_FILES['photos']['error'][$key] !== UPLOAD_ERR_OK) continue;
                
                $ext = pathinfo($_FILES['photos']['name'][$key], PATHINFO_EXTENSION);
                $new_name = uniqid('fb_', true) . '.' . strtolower($ext);
                
                if (move_uploaded_file($tmp, $upload_dir . $new_name)) {
                    $photo_stmt->bind_param("is", $id, $new_name);
                    $photo_stmt->execute();
                }
            }
            $photo_stmt->close();
        }

        header("Location: view_feedback.php");
        exit;
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8"/>
    <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
    <title>Edit Feedback</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="style.css">
    <style>
        :root {
            --bg: #f5f2ed;
            --accent: #b5834a;
            --card-bg: #ffffff;
            --text: #1c1c1c;
            --text-muted: #7a7068;
            --border: #ddd8d0;
            --error: #c0392b;
            --error-bg: #fdf0ef;
            --error-border: #e8a59e;
            --shadow: 0 4px 24px rgba(0,0,0,0.08);
            --radius: 12px;
        }

        *, *::before, *::after { margin: 0; padding: 0; box-sizing: border-box; }

        body {
            font-family: 'DM Sans', sans-serif;
            background: var(--bg);
            color: var(--text);
            min-height: 100vh;
            display: flex;
        }

        .main { flex: 1; display: flex; flex-direction: column; overflow: hidden; }

        .topbar {
            padding: 20px 36px 16px;
            background: var(--bg);
            border-bottom: 1px solid var(--border);
        }

        .search-wrap { position: relative; max-width: 380px; margin-left: 20px; }

        .search-wrap input {
            width: 100%;
            padding: 10px 16px 10px 42px;
            border: 1.5px solid var(--border);
            border-radius: 50px;
            background: var(--card-bg);
            font-family: 'DM Sans', sans-serif;
            font-size: 14px;
            outline: none;
            transition: border-color 0.2s, box-shadow 0.2s;
        }

        .search-wrap input:focus {
            border-color: var(--accent);
            box-shadow: 0 0 0 3px rgba(181,131,74,0.15);
        }

        .search-icon {
            position: absolute; left: 14px; top: 50%;
            transform: translateY(-50%);
            color: var(--text-muted); pointer-events: none;
        }

        .content {
            flex: 1; overflow-y: auto;
            padding: 40px 48px;
            display: flex; flex-direction: column; align-items: center;
        }

        .page-title {
            font-family: 'Playfair Display', serif;
            font-size: 30px; font-weight: 700;
            margin-bottom: 6px; text-align: center;
        }

        .page-subtitle {
            font-size: 14px; color: var(--text-muted);
            margin-bottom: 32px; text-align: center;
        }

        .feedback-card {
            background: var(--card-bg);
            border-radius: var(--radius);
            box-shadow: var(--shadow);
            padding: 48px; width: 100%; max-width: 860px;
        }

        .hotel-header {
            display: flex; align-items: flex-start; gap: 20px;
            margin-bottom: 28px; padding-bottom: 24px;
            border-bottom: 1px solid var(--border);
        }

        .hotel-thumb {
            width: 90px; height: 90px; border-radius: 10px;
            background: linear-gradient(135deg, #e8d9c0 0%, #c8b89a 100%);
            display: flex; align-items: center; justify-content: center;
            color: var(--accent); font-size: 28px; flex-shrink: 0;
        }

        .hotel-info h2 {
            font-family: 'Playfair Display', serif;
            font-size: 20px; font-weight: 700; margin-bottom: 6px;
        }
        .hotel-info p { font-size: 13px; color: var(--text-muted); }

        .form-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 32px; }
        .form-group { display: flex; flex-direction: column; gap: 10px; }
        .form-group.full { grid-column: 1 / -1; }

        label {
            font-size: 13px; font-weight: 500;
            color: var(--text-muted);
            text-transform: uppercase; letter-spacing: 0.6px;
        }

        .stars { display: flex; gap: 6px; }
        .stars label {
            font-size: 42px; cursor: pointer;
            transition: transform 0.15s; color: #ddd8d0;
        }
        .stars label:hover { transform: scale(1.15); }

        textarea {
            width: 100%; padding: 14px 16px;
            border: 1.5px solid var(--border); border-radius: 10px;
            font-family: 'DM Sans', sans-serif; font-size: 14px;
            background: var(--card-bg); resize: vertical; min-height: 150px;
            outline: none; transition: border-color 0.2s, box-shadow 0.2s;
        }
        textarea:focus { border-color: var(--accent); box-shadow: 0 0 0 3px rgba(181,131,74,0.15); }
        textarea.error { border-color: var(--error-border); background: var(--error-bg); }

        .existing-photos { display: flex; flex-wrap: wrap; gap: 8px; margin-bottom: 12px; }
        .existing-photos img {
            width: 80px; height: 80px; object-fit: cover;
            border-radius: 8px; border: 1.5px solid var(--border); opacity: 0.7;
        }

        .replace-notice {
            font-size: 13px; color: var(--text-muted);
            margin-bottom: 8px;
            padding: 8px 12px;
            background: #fff8ee;
            border: 1px solid #e8d9c0;
            border-radius: 8px;
        }

        .photo-upload-area {
            border: 2px dashed var(--border); border-radius: 10px;
            padding: 48px 20px; text-align: center; cursor: pointer;
            background: var(--bg); position: relative; overflow: hidden;
            transition: border-color 0.2s, background 0.2s;
        }
        .photo-upload-area:hover, .photo-upload-area.drag-over {
            border-color: var(--accent); background: rgba(181,131,74,0.05);
        }
        .photo-upload-area input[type="file"] {
            position: absolute; inset: 0; opacity: 0;
            cursor: pointer; width: 100%; height: 100%;
        }
        .upload-icon { font-size: 32px; margin-bottom: 8px; color: var(--accent); }
        .upload-label { font-size: 14px; color: var(--text-muted); }
        .upload-label strong { color: var(--accent); }
        .upload-hint { font-size: 12px; color: var(--text-muted); margin-top: 4px; }

        .photo-previews { display: flex; flex-wrap: wrap; gap: 10px; margin-top: 12px; }

        .photo-preview-item { position: relative; width: 80px; height: 80px; }
        .photo-preview-item img {
            width: 100%; height: 100%; object-fit: cover;
            border-radius: 8px; border: 1.5px solid var(--border);
        }
        .remove-photo {
            position: absolute; top: -6px; right: -6px;
            width: 20px; height: 20px; background: var(--error);
            color: white; border: none; border-radius: 50%;
            font-size: 10px; cursor: pointer;
            display: flex; align-items: center; justify-content: center;
        }

        .error-msg {
            font-size: 12px; color: var(--error);
            display: none; align-items: center; gap: 5px; margin-top: 2px;
        }
        .error-msg.visible { display: flex; }

        .form-actions {
            display: flex; align-items: center; gap: 12px;
            margin-top: 28px; padding-top: 24px;
            border-top: 1px solid var(--border);
        }

        .btn {
            padding: 11px 24px; border-radius: 8px;
            font-family: 'DM Sans', sans-serif; font-size: 14px; font-weight: 500;
            cursor: pointer; border: none; transition: all 0.2s;
            text-decoration: none; display: inline-block;
        }
        .btn-cancel {
            background: transparent;
            border: 1.5px solid var(--border); color: var(--text-muted);
        }
        .btn-cancel:hover { background: var(--bg); border-color: var(--accent); color: var(--accent); }
        .btn-submit { background: var(--accent); color: white; box-shadow: 0 2px 8px rgba(181,131,74,0.35); }
        .btn-submit:hover { background: #9e6e38; transform: translateY(-1px); }

        .content::-webkit-scrollbar { width: 6px; }
        .content::-webkit-scrollbar-track { background: transparent; }
        .content::-webkit-scrollbar-thumb { background: var(--border); border-radius: 4px; }
    </style>
</head>
<body>
    <?php include 'sidenav.php'; ?>
    <div class="main">
        <div class="topbar">
            <div class="search-wrap">
                <svg class="search-icon" width="16" height="16" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24">
                    <circle cx="11" cy="11" r="8"/>
                    <line x1="21" y1="21" x2="16.65" y2="16.65"/>
                </svg>
                <input type="text" placeholder="Search hotels, attraction..."/>
            </div>
        </div>

        <div class="content">
            <h1 class="page-title">Edit Feedback</h1>
            <p class="page-subtitle">Update your experience below</p>

            <div class="feedback-card">
                <div class="hotel-header">
                    <div class="hotel-thumb">🏨</div>
                    <div class="hotel-info">
                        <h2><?php echo htmlspecialchars($place_name); ?></h2>
                        <p>Edit your review below</p>
                    </div>
                </div>

                <form method="post" action="" id="feedbackForm" enctype="multipart/form-data" novalidate>
                    <div class="form-grid">

                        <div class="form-group star-group">
                            <label>Rating</label>
                            <div class="stars" id="starRow">
                                <label data-val="1">★</label>
                                <label data-val="2">★</label>
                                <label data-val="3">★</label>
                                <label data-val="4">★</label>
                                <label data-val="5">★</label>
                            </div>
                            <input type="hidden" name="rating" id="ratingInput"
                                   value="<?php echo (int)$row['rating']; ?>"/>
                            <span class="error-msg" id="ratingError">Please select a rating.</span>
                        </div>

                        <div class="form-group full">
                            <label for="descriptionInput">Description *</label>
                            <textarea id="descriptionInput" name="description" rows="5"
                                placeholder="Tell us about your stay..."><?php echo htmlspecialchars($row['feedback_description']); ?></textarea>
                            <span class="error-msg" id="descError">Description is required.</span>
                        </div>

                        <div class="form-group full">
                            <label>Photos</label>

                            <?php
                            $existing = $conn->prepare("SELECT feedback_photo_url FROM feedback_photo WHERE feedback_id = ?");
                            $existing->bind_param("i", $id);
                            $existing->execute();
                            $existing_photos = $existing->get_result();
                            ?>

                            <?php if ($existing_photos->num_rows > 0): ?>
                                <p class="replace-notice">
                                    ⚠️ Uploading new photos will <strong>replace</strong> the existing ones below.
                                </p>
                                <div class="existing-photos">
                                    <?php while ($ep = $existing_photos->fetch_assoc()): ?>
                                        <img src="uploads/feedback/<?php echo htmlspecialchars($ep['feedback_photo_url']); ?>"
                                             alt="Current photo">
                                    <?php endwhile; ?>
                                </div>
                            <?php endif; ?>
                            <?php $existing->close(); ?>

                            <div class="photo-upload-area" id="dropZone">
                                <input type="file" id="photoInput" name="photos[]" accept="image/*" multiple/>
                                <div class="upload-icon">📷</div>
                                <div class="upload-label"><strong>Click to upload</strong> or drag &amp; drop</div>
                                <div class="upload-hint">PNG, JPG, WEBP up to 10 MB each</div>
                            </div>
                            <div class="photo-previews" id="photoPreviews"></div>
                        </div>

                    </div>

                    <div class="form-actions">
                       <button type="button" class="btn btn-submit" onclick="updateFeedback()">✏️ Update Feedback</button>
                        <a href="view_feedback.php" class="btn btn-cancel">Cancel</a>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <script>
        const starRow     = document.getElementById('starRow');
        const ratingInput = document.getElementById('ratingInput');
        const stars       = Array.from(starRow.querySelectorAll('label'));
        let currentRating = parseInt(ratingInput.value) || 0;

        function paintStars(upTo) {
            stars.forEach((s, i) => {
                s.style.color = i < upTo ? '#b5834a' : '#ddd8d0';
            });
        }

        paintStars(currentRating);

        stars.forEach((star, idx) => {
            star.addEventListener('mouseenter', () => paintStars(idx + 1));
            star.addEventListener('mouseleave', () => paintStars(currentRating));
            star.addEventListener('click', () => {
                currentRating     = idx + 1;
                ratingInput.value = currentRating;
                paintStars(currentRating);
            });
        });

        const descInput = document.getElementById('descriptionInput');
        const descError = document.getElementById('descError');

        function validateDesc() {
            const empty = descInput.value.trim() === '';
            descInput.classList.toggle('error', empty);
            descError.classList.toggle('visible', empty);
            return !empty;
        }

        descInput.addEventListener('input', () => {
            if (descInput.value.trim() !== '') {
                descInput.classList.remove('error');
                descError.classList.remove('visible');
            }
        });
        descInput.addEventListener('blur', validateDesc);

        const photoInput    = document.getElementById('photoInput');
        const photoPreviews = document.getElementById('photoPreviews');
        const dropZone      = document.getElementById('dropZone');
        let uploadedFiles   = [];

        function syncFileInput() {
            const dt = new DataTransfer();
            uploadedFiles.forEach(f => dt.items.add(f));
            photoInput.files = dt.files;
        }

        function addFiles(files) {
            Array.from(files).forEach(file => {
                if (!file.type.startsWith('image/')) return;
                if (uploadedFiles.find(f => f.name === file.name && f.size === file.size)) return;
                uploadedFiles.push(file);
                const reader = new FileReader();
                reader.onload = e => {
                    const wrap = document.createElement('div');
                    wrap.className = 'photo-preview-item';
                    const img = document.createElement('img');
                    img.src = e.target.result;
                    img.alt = 'preview';
                    const btn = document.createElement('button');
                    btn.type      = 'button';
                    btn.className = 'remove-photo';
                    btn.textContent = '✕';
                    btn.addEventListener('click', () => {
                        uploadedFiles.splice(uploadedFiles.indexOf(file), 1);
                        wrap.remove();
                        syncFileInput();
                    });
                    wrap.appendChild(img);
                    wrap.appendChild(btn);
                    photoPreviews.appendChild(wrap);
                };
                reader.readAsDataURL(file);
            });
            syncFileInput();
        }

        photoInput.addEventListener('change', e => { addFiles(e.target.files); photoInput.value = ''; });
        dropZone.addEventListener('dragover',  e => { e.preventDefault(); dropZone.classList.add('drag-over'); });
        dropZone.addEventListener('dragleave', () => dropZone.classList.remove('drag-over'));
        dropZone.addEventListener('drop', e => {
            e.preventDefault();
            dropZone.classList.remove('drag-over');
            addFiles(e.dataTransfer.files);
        });

        function updateFeedback() {
    const formElement = document.getElementById('feedbackForm');
    const formData = new FormData(formElement);
    
    formData.append('updateBtn', 'true');

    formData.delete('photos[]'); 
    uploadedFiles.forEach(file => {
        formData.append('photos[]', file);
    });

    fetch(window.location.href, { 
        method: 'POST',
        body: formData
    })
    .then(response => response.text())
    .then(data => {
        console.log("Server Response:", data);
        window.location.href = 'view_feedback.php';
    })
    .catch(error => console.error('Error:', error));
}
    </script>
</body>
</html>