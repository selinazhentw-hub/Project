<?php
session_start(); 
require_once "db_connect.php"; 

if (!isset($_SESSION["user_email"])) {
    header("Location: login.php"); 
    exit();
}

$email = $_SESSION["user_email"];

// Get user ID
$user_sql = "SELECT user_id, user_name FROM user WHERE user_email = '$email'";
$user_result = $conn->query($user_sql);

if ($user_result && $user_result->num_rows > 0) {
    $user_row = $user_result->fetch_assoc();
    $user_id = $user_row['user_id']; 
} else {
    header("Location: login.php");
    exit();
}

// Get activity wishlist (Removed accommodation queries)
$activity_wishlist = $conn->query("SELECT w.wishlist_id, act.* FROM wishlist w 
    LEFT JOIN activity act ON w.activity_id = act.activity_id 
    WHERE w.user_id = $user_id 
    AND w.activity_id IS NOT NULL
    AND w.is_deleted = 0");
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>My Wishlist</title>
    <link rel="stylesheet" href="style.css">
    <?php include 'sidenav.php'; ?>
</head>

<style>
    /* Simplified styles - removed tab specific CSS */
    .wishlist-header {
        text-align: center;
        margin-bottom: 50px;
    }

    .location-container {
        display: flex;
        align-items: center;
        gap: 8px;
        margin-bottom: 15px;
    }

    .item-location {
        margin: 0;
        font-size: 16px;
        color: #333;
        display: inline;
    }

    .item-emoji {
        font-size: 18px;
        line-height: 1;
    }

    .item-image {
        width: 300px;
        height: 200px;
        object-fit: cover;
        border-radius: 8px;
        flex-shrink: 0;
    }

    .card-row {
        display: flex;
        align-items: flex-start;
        gap: 20px;
        max-width: 800px;
        margin: 0 auto 30px 40px;
        padding: 20px;
        background: white;
        border-radius: 10px;
        box-shadow: 0 2px 5px rgba(0,0,0,0.1);
    }

    .details-col {
        flex: 1;
        display: flex;
        flex-direction: column;
    }

    .delete-btn {
        background-color: #ff4444;
        border: none;
        color: white;
        padding: 6px 14px;
        border-radius: 4px;
        font-size: 14px;
        cursor: pointer;
        margin-top: 10px;
        width: 80px;
        text-align: center;
    }

    .delete-btn:hover {
        background-color: #cc0000;
    }
    
    .item-title {
        margin: 5px 0;
    }
    
    .empty-message {
        text-align: center;
        padding: 40px;
        color: #666;
    }
</style>

<body>
<div id="main-content">
    <div class="wishlist-header">
        <h2><?php echo htmlspecialchars($user_row['user_name']); ?>'s Wishlist</h2>
        
    </div>

    <div class="wishlist-wrapper">
        <?php if ($activity_wishlist && $activity_wishlist->num_rows > 0): ?>
            <?php while($item = $activity_wishlist->fetch_assoc()): ?>
            <div class="card-row">
                <div class="details-col"> 
                    <h3 class="item-title"><?php echo htmlspecialchars($item['activity_name'] ?? 'Unknown'); ?></h3>
                    <p class="item-title"><strong>Category:</strong> <?php echo htmlspecialchars($item['activity_category'] ?? 'N/A'); ?></p>
                    <p class="item-title"><strong>Description:</strong> <?php echo htmlspecialchars($item['activity_description'] ?? 'No description'); ?></p>
                    <p class="item-title"><strong>Price:</strong> RM <?php echo htmlspecialchars($item['activity_price'] ?? '0'); ?></p>

                    <div class="location-container">
                        <span class="item-emoji">📍</span>
                        <p class="item-location"><?php echo htmlspecialchars($item['activity_address'] ?? ''); ?>, <?php echo htmlspecialchars($item['activity_city'] ?? ''); ?>, <?php echo htmlspecialchars($item['activity_country'] ?? ''); ?></p>
                    </div>

                    <a href="delete_wishlist.php?id=<?php echo $item['wishlist_id']; ?>&type=activity" 
                       class="delete-btn" 
                       onclick="return confirm('Remove this activity?')">Delete</a>
                </div>
                <img src="images/<?php echo htmlspecialchars($item['activity_image'] ?? 'placeholder.jpg'); ?>" 
                     class="item-image" 
                     onerror="this.src='images/placeholder.jpg'">
            </div> 
            <?php endwhile; ?>
        <?php else: ?>
            <p class="empty-message">No activities in your wishlist yet.</p>
        <?php endif; ?>
    </div>
</div>
</body>
</html>