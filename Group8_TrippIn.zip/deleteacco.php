<?php
header('Content-Type: application/json');
require_once 'db_connect.php';
$input = json_decode(file_get_contents('php://input'), true);
$id = $input['acco_id'];
$sql = "DELETE FROM accommodation WHERE acco_id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $id);
if ($stmt->execute()) echo json_encode(["success" => true]);
else echo json_encode(["success" => false]);
?>