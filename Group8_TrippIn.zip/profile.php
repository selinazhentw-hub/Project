﻿<?php
session_start();

include 'db_connect.php';

// check if logged in
if (!isset($_SESSION["user_email"])) {
    header("Location: login.php");
    exit();
}

if (isset($_GET["logout"])) {
    session_destroy();
    header("Location: home.php");
    exit();
}

$email = $_SESSION["user_email"];

if (isset($_GET['current']) && isset($_GET['new'])) {

    $current = $_GET['current'];
    $new = $_GET['new'];

    if (strlen($new) < 8) {
    echo "<script>alert('Password must be at least 8 characters long'); window.location='profile.php';</script>";
    exit();
    }

    $sql = "SELECT user_password FROM user WHERE user_email='$email'";
    $result = $conn->query($sql);
    $row_check = $result->fetch_assoc();

    if ($row_check['user_password'] !== $current) {
        echo "<script>alert('Current password incorrect'); window.location='profile.php';</script>";
        exit();
    }

    if ($current === $new) {
        echo "<script>alert('New password cannot be the same as current password'); window.location='profile.php';</script>";
        exit();
    }

    $sql = "UPDATE user SET user_password='$new' WHERE user_email='$email'";
    $conn->query($sql);

    echo "<script>alert('Password updated successfully'); window.location='profile.php';</script>";
    exit();
}

//  Handle update
if (isset($_GET["field"]) && isset($_GET["value"])) {
    $field = $_GET["field"];
    $value = $_GET["value"];

    $allowed_fields = ["user_fullname", "user_name", "user_email", "user_gender", "user_phone", "user_password"];

    if (in_array($field, $allowed_fields)) {

    // check existing email
    if ($field == "user_email") {

        $check = "SELECT * FROM user 
                  WHERE user_email='$value' 
                  AND user_email != '$email'";

        $result_check = $conn->query($check);

        if ($result_check->num_rows > 0) {
            echo "<script>alert('Email is already in use'); window.location='profile.php';</script>";
            exit();
        }
    }

    // check existing username
    if ($field == "user_name") {

        $check = "SELECT * FROM user 
                  WHERE user_name='$value' 
                  AND user_email != '$email'";

        $result_check = $conn->query($check);

        if ($result_check->num_rows > 0) {
            echo "<script>alert('Username is already in use'); window.location='profile.php';</script>";
            exit();
        }
    }

    $sql = "UPDATE user SET $field='$value' WHERE user_email='$email'";
    $conn->query($sql);

    // update session email
    if ($field == "user_email") {
        $_SESSION["user_email"] = $value;
        }
    }

    header("Location: profile.php");
    exit();
}

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_FILES["profile_pic"])) {

    $file = $_FILES["profile_pic"];

    if ($file["error"] !== 0) {
        die("Upload failed");
    }

    $filename = $file["name"];
    $temp = $file["tmp_name"];

    // get file extension
    $ext = pathinfo($filename, PATHINFO_EXTENSION);

    $allowed = ["jpg", "jpeg", "png"];
    if (!in_array(strtolower($ext), $allowed)) {
        die("Only JPG, JPEG, PNG allowed");
    }

    // create unique name
    $newName = uniqid() . "." . $ext;

    // save to uploads folder
    $uploadPath = "uploads/" . $newName;

    move_uploaded_file($temp, $uploadPath);

    // save path to database
    $sql = "UPDATE user SET profile_pic='$uploadPath' WHERE user_email='$email'";
    $conn->query($sql);

    // refresh page
    header("Location: profile.php");
    exit();
}

$sql = "SELECT * FROM user WHERE user_email='$email'";
$result = $conn->query($sql);
$row = $result->fetch_assoc();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <?php include 'sidenav.php'; ?>
    <link rel="stylesheet" href="style.css">

</head>

<body>
    <div id="main-content">
        <h2>Profile</h2>

        <!-- Profile Picture -->
        <div class="profile-picture-container">
            <form method="POST" enctype="multipart/form-data">
                <div class="profile-picture">
                    <label for="fileInput">
                        <img src="<?php echo $row['profile_pic'] ? $row['profile_pic'] : 'profile-icon.png'; ?>">
                    </label>
                    <input type="file" id="fileInput" name="profile_pic" style="display:none;" onchange="this.form.submit()">
                </div>
            </form>
        </div>

        <!-- Profile Info Table -->
        <div class="profile-table-container">
            <table class="profile-table">

                <tr>
                    <th>Fullname</th>
                    <th>Username</th>
                    <th>Email</th>
                    <th>Gender</th>
                    <th>Phone No.</th>
                    <th>Password</th>
                </tr>

                <tr>
                    <td onclick="editField('user_fullname', '<?php echo $row["user_fullname"]; ?>')">
                        <?php echo $row["user_fullname"]; ?>
                    </td>

                    <td onclick="editField('user_name', '<?php echo $row["user_name"]; ?>')">
                        <?php echo $row["user_name"]; ?>
                    </td>

                    <td onclick="editField('user_email', '<?php echo $row["user_email"]; ?>')">
                        <?php echo $row["user_email"]; ?>
                    </td>

                    <td onclick="editField('user_gender', '<?php echo $row["user_gender"]; ?>')">
                        <?php echo $row["user_gender"]; ?>
                    </td>

                    <td onclick="editField('user_phone', '<?php echo $row["user_phone"]; ?>')">
                        <?php echo $row["user_phone"]; ?>
                    </td>

                    <td>
                        <span class="change-password" onclick="openPasswordModal()">
                            Change Password
                        </span>
                    </td>

                </tr>
            </table>
        </div>

        <div class="logout-container">
            <button class="logout-btn" onclick="window.location.href='profile.php?logout=1'">
                Logout
            </button>
        </div>

    </div>

    <script>
        let currentField = "";

        function editField(field, currentValue) {
            currentField = field;

            document.getElementById("modalTitle").innerText = "Edit " + field.replace("user_", "");
            
            let input = document.getElementById("editInput");
            let select = document.getElementById("editSelect");

            if (field === "user_gender") {
                input.style.display = "none";
                select.style.display = "block";
                select.value = currentValue;
            } else {
                input.style.display = "block";
                select.style.display = "none";
                input.value = currentValue;
            }

            document.getElementById("editModal").style.display = "flex";
        }

        function closeModal() {
            document.getElementById("editModal").style.display = "none";
        }

        function submitEdit() {
            let newValue;

            if (currentField === "user_gender") {
                newValue = document.getElementById("editSelect").value;
            } else {
                newValue = document.getElementById("editInput").value;
            }

            if (currentField === "user_phone") {

                let phonePattern = /^[0-9+\-]+$/;

                if (!phonePattern.test(newValue)) {
                    alert("Phone number can only contain numbers, + and -");
                    return;
                }

                if (newValue.length < 7) {
                    alert("Phone number must be at least 7 characters long");
                    return;
                }
            }

            if (newValue === "") return;

            window.location.href = "profile.php?field=" + currentField + "&value=" + encodeURIComponent(newValue);
        }

    </script>

    <script>
    function submitPassword() {
        let current = document.getElementById("currentPassword").value;
        let newPass = document.getElementById("newPassword").value;
        let confirm = document.getElementById("confirmPassword").value;

        if (current === "" || newPass === "" || confirm === "") {
            alert("Please fill in all fields");
            return;
        }

        if (newPass !== confirm) {
            alert("New passwords do not match");
            return;
        }

        window.location.href = "profile.php?current=" + encodeURIComponent(current) +
                           "&new=" + encodeURIComponent(newPass);
    }
    </script>

    <script>
    function openPasswordModal() {
        document.getElementById("passwordModal").style.display = "flex";
    }

    function closePasswordModal() {
        document.getElementById("passwordModal").style.display = "none";
    }
    </script>

    <!-- Edit Modal -->
    <div id="editModal" class="modal">
        <div class="modal-content">
            <h3 id="modalTitle">Edit</h3>

            <input type="text" id="editInput">

            <select id="editSelect" style="display:none;">
                <option value="Male">Male</option>
                <option value="Female">Female</option>
                <option value="Prefer not to say">Prefer not to say</option>
            </select>

            <div style="margin-top: 15px;">
                <button class="close-btn" onclick="submitEdit()">Confirm</button>
                <button class="close-btn" onclick="closeModal()">Cancel</button>
            </div>
        </div>
    </div>

    <div id="passwordModal" class="modal">
        <div class="modal-content">
            <h3>Change Password</h3>

            <input type="password" id="currentPassword" placeholder="Current password">
            <input type="password" id="newPassword" placeholder="New password">
            <input type="password" id="confirmPassword" placeholder="Confirm new password">

            <div class="modal-buttons">
                <button class="close-btn" onclick="submitPassword()">Confirm</button>
                <button class="close-btn" onclick="closePasswordModal()">Cancel</button>
            </div>
        </div>
    </div>

</body>

</html>
