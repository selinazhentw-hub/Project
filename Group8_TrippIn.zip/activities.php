<?php 
session_start(); 
include 'db_connect.php'; 

$is_logged_in = isset($_SESSION['user_email']) ? 'true' : 'false'; 

$wishlist_ids = [];
if (isset($_SESSION['user_email'])) {
    $user_email = $_SESSION['user_email'];
    $user_query = "SELECT user_id FROM user WHERE user_email = '$user_email'";
    $user_result = mysqli_query($conn, $user_query);
    
    if ($user_row = mysqli_fetch_assoc($user_result)) {
        $user_id = (int)$user_row['user_id'];
        $w_query = "SELECT activity_id FROM wishlist WHERE user_id = $user_id AND activity_id IS NOT NULL AND is_deleted = 0";
        $w_res = mysqli_query($conn, $w_query);
        while ($w_row = mysqli_fetch_assoc($w_res)) {
            $wishlist_ids[] = $w_row['activity_id'];
        }
    }
}

$filter_country = isset($_GET['country']) ? mysqli_real_escape_string($conn, $_GET['country']) : '';
$filter_city = isset($_GET['city']) ? mysqli_real_escape_string($conn, $_GET['city']) : '';
$filter_price = (isset($_GET['price']) && $_GET['price'] !== '') ? (float)$_GET['price'] : '';
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>TrippIn - Activities</title>
    <link rel="stylesheet" href="style.css">
    <?php include 'sidenav.php'; ?>
</head>

<body>
    <div id="main-content">
        <h2>Activities</h2>

        <div class="filter-container">
            <form method="GET" action="activities.php">
                <input type="text" name="country" placeholder="Country" value="<?php echo htmlspecialchars($filter_country); ?>">
                <input type="text" name="city" placeholder="City" value="<?php echo htmlspecialchars($filter_city); ?>">
                <input type="number" name="price" placeholder="Max Price" value="<?php echo htmlspecialchars($filter_price); ?>">
                <button type="submit" class="filter-btn">Filter</button>
                <a href="activities.php" style="font-size: 0.8em; margin-left: 10px;">Clear Filters</a>
            </form>
        </div>

        <div class="content-box">
            <?php
            $query = "SELECT activity_id, activity_image, activity_name, activity_country, activity_city, activity_price, activity_address, activity_description FROM activity WHERE 1=1";

            if ($filter_country != '') {
                $query .= " AND activity_country LIKE '%$filter_country%'";
            }
            if ($filter_city != '') {
                $query .= " AND activity_city LIKE '%$filter_city%'";
            }
            if ($filter_price != '') {
                $query .= " AND activity_price <= $filter_price";
            }

            $result = mysqli_query($conn, $query);

            if ($result && mysqli_num_rows($result) > 0) {
                while($row = mysqli_fetch_assoc($result)) {
                    $is_active = in_array($row['activity_id'], $wishlist_ids) ? 'active' : '';
                    ?>
                    <div class="activities-boxes">
                        <div class="activity-img-container">
                            <img src="images/<?php echo $row['activity_image']; ?>" alt="Activity" style="width:100%; height:200px; object-fit:cover;">
                        </div>
                        
                        <p><strong><?php echo htmlspecialchars($row['activity_name']); ?></strong><br>
                        <?php echo htmlspecialchars($row['activity_city']) . ", " . htmlspecialchars($row['activity_country']); ?><br>
                        Price: RM<?php echo $row['activity_price']; ?></p>

                        <div class="box-footer">
                            <a href="javascript:void(0)" class="view-details"
                               onclick="showDetails(
                                   '<?php echo addslashes($row['activity_name']); ?>', 
                                   '<?php echo $row['activity_price']; ?>', 
                                   '<?php echo addslashes($row['activity_address']); ?>', 
                                   '<?php echo addslashes($row['activity_description']); ?>'
                               )">View Details</a>

                            <form action="addwishlist.php" method="POST" style="display:inline;" onsubmit="return validateWishlist()">
                                <input type="hidden" name="activity_id" value="<?php echo $row['activity_id']; ?>">
                                <button type="submit" class="wishlist-btn <?php echo $is_active; ?>">❤</button>
                            </form>
                        </div>
                    </div>
                    <?php
                }
            } else {
                echo "<p>No activities available matching your criteria.</p>";
            }
            ?>
        </div>
    </div>

    <div id="details-overlay" class="overlay-hidden" style="display:none;">
        <div class="overlay-content">
            <span class="close-overlay" onclick="hideDetails()">&times;</span>
            <h3 id="overlay-title"></h3>
            <p><strong>Price:</strong> RM<span id="overlay-price"></span></p>
            <p><strong>Address:</strong> <span id="overlay-address"></span></p>
            <hr>
            <p id="overlay-description"></p>
        </div>
    </div>

<script>

function validateWishlist() {
    var loggedIn = <?php echo $is_logged_in; ?>;
    
    if (!loggedIn) {
        alert("Please login to use the wishlist feature.");
        return false; 
    return true; 
}
}
function showDetails(name, price, address, desc) {
    document.getElementById('overlay-title').innerText = name;
    document.getElementById('overlay-price').innerText = price;
    document.getElementById('overlay-address').innerText = address;
    document.getElementById('overlay-description').innerText = desc;
    document.getElementById('details-overlay').style.display = 'flex';
}

function hideDetails() {
    document.getElementById('details-overlay').style.display = 'none';
}
</script>

</body>
</html>