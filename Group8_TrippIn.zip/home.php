<!DOCTYPE html>
<html lang="en">
<head>
    <title>TrippIn</title>
    <link rel="stylesheet" href="style.css">
    <?php include 'sidenav.php'; ?>

</head>

<body>

<div id="main-content">

    <div class="hero-section">
        <div class="hero-content">
            <h1>Discover Your Trip</h1>
            <p>Find accommodation and activities in your destination</p>

            <!-- 🔥 SEARCH FORM -->
            <div class="search-box">
                <form action="search_result.php" method="GET">

                    <input type="text" 
                           name="city" 
                           placeholder="Enter city (e.g. Kuala Lumpur)" 
                           required>

                    <button type="submit">Search</button>

                </form>
            </div>

        </div>
    </div>

</div>

</body>
</html>