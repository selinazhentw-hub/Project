<?php
session_start();
require_once 'db_connect.php';

if (!isset($_SESSION["admin_name"])) {
    echo json_encode(["success" => false, "message" => "Unauthorized"]);
    exit();
}

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_FILES["image"])) {
    $file = $_FILES["image"];
    
    if ($file["error"] !== UPLOAD_ERR_OK) {
        echo json_encode(["success" => false, "message" => "Upload failed: " . $file["error"]]);
        exit();
    }
    
    $allowed = ["jpg", "jpeg", "png", "gif"];
    $ext = strtolower(pathinfo($file["name"], PATHINFO_EXTENSION));
    if (!in_array($ext, $allowed)) {
        echo json_encode(["success" => false, "message" => "Only JPG, PNG, GIF allowed"]);
        exit();
    }
    
    if ($file["size"] > 5 * 1024 * 1024) {
        echo json_encode(["success" => false, "message" => "File too large (max 5MB)"]);
        exit();
    }
    
    $newFileName = uniqid() . "." . $ext;
    $uploadDir = "images/";
    
    if (!file_exists($uploadDir)) {
        mkdir($uploadDir, 0777, true);
    }
    
    $uploadPath = $uploadDir . $newFileName;
    
    if (move_uploaded_file($file["tmp_name"], $uploadPath)) {
        echo json_encode(["success" => true, "filename" => $newFileName, "path" => $uploadPath]);
    } else {
        echo json_encode(["success" => false, "message" => "Failed to save file"]);
    }
} else {
    echo json_encode(["success" => false, "message" => "No file uploaded"]);
}
?>