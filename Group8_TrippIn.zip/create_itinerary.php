<?php
session_start();
include 'db_connect.php';

$wishlist = [];

if (!isset($_SESSION["user_email"])) {
    header("Location: login.php"); 
    exit();
}

$email = $_SESSION["user_email"];

$user_sql = "SELECT user_id, user_name FROM user WHERE user_email = '$email'";
$user_result = $conn->query($user_sql);

if ($user_result && $user_result->num_rows > 0) {
    $user_row = $user_result->fetch_assoc();
    $user_id = $user_row['user_id']; 
} else {
    header("Location: login.php");
    exit();
}

$query = "
SELECT 
    wishlist.wishlist_id,
    activity.activity_id,

    activity.activity_name AS activity_name,
    activity.activity_price AS activity_price,
    activity.activity_city AS activity_city,
    activity.activity_country AS activity_country

    FROM wishlist
    LEFT JOIN activity ON wishlist.activity_id = activity.activity_id
    WHERE wishlist.user_id = $user_id
";

$result = $conn->query($query);

while ($row = $result->fetch_assoc()) {

    if (!is_null($row['activity_id'])) {
        $wishlist[] = [
            'id' => $row['activity_id'],
            'name' => $row['activity_name'],
            'type' => 'Activity',
            'price' => $row['activity_price'],
            'city' => $row['activity_city'],
            'country' => $row['activity_country']
        ];
    }

}

$max_budget = $_POST['budget'] ?? 500;
$selected_ids = $_POST['selected_items'] ?? [];
$final_itinerary = [];

$budget_filtered_list = array_filter($wishlist, fn($item) => $item['price'] <= $max_budget);

if (isset($_POST['generate']) && !empty($selected_ids)) {
    $picked_items = array_filter($wishlist, fn($item) => in_array($item['id'], $selected_ids));
    $cities = array_unique(array_column($picked_items, 'city'));
    $countries = array_unique(array_column($picked_items, 'country'));
    $prices = array_column($picked_items, 'price');
    $min_p = min($prices);
    $max_p = max($prices);
    $buffer = 30; 
    
    $final_itinerary = array_filter($wishlist, function($item) use ($min_p, $max_p, $buffer, $cities) {
        $price_match = ($item['price'] >= ($min_p - $buffer) && $item['price'] <= ($max_p + $buffer));
        $location_match = in_array($item['city'], $cities);

        if ($location_match && $price_match) return true;


        if ($location_match && $item['price'] <= $max_p) return true;

        return false;
    });
    usort($final_itinerary, fn($a, $b) => $a['price'] <=> $b['price']);
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Itinerary - TrippIn</title>
    <link rel="stylesheet" href="style.css">
    <style>

        #itinerary-wrapper {
            padding: 40px;
            display: flex;
            flex-direction: column;
            gap: 20px;
        }

        .itinerary-grid {
            display: flex;
            gap: 30px;
            align-items: flex-start;
        }

        .white-box {
            background-color: #ffffff;
            border: 5px solid #ffba26;
            border-radius: 10px;
            padding: 25px;
            flex: 1;
        }

        .budget-slider-box {
            background-color: #ffba26;
            padding: 15px;
            border-radius: 10px;
            margin-bottom: 20px;
            font-family: "Red Rose", serif;
        }

        .item-card {
            display: flex;
            justify-content: space-between;
            align-items: center;
            background: #fff;
            border: 2px solid #eee;
            padding: 12px;
            margin-bottom: 10px;
            border-radius: 8px;
            font-family: "Montserrat", sans-serif;
        }

        .item-card.picked {
            border-color: #ffba26;
            background-color: #fffdf5;
        }

                .item-card {
            flex-direction: column; 
            align-items: flex-start; 
            transition: border-color 0.3s ease, background-color 0.3s ease;
            cursor: pointer;
        }

        .item-card.active {
            border-color: #ffba26;
            background-color: #fffdf5;
        }
        .item-details {
            max-height: 0;
            overflow: hidden;
            transition: max-height 0.3s ease, margin-top 0.3s ease;
            width: 100%;
            font-size: 0.9em;
            color: #555;
        }

        .item-card.active .item-details {
            max-height: 100px;
            margin-top: 10px;
            border-top: 1px solid #eee;
            padding-top: 10px;
        }

        .badge {
            background: #ffba26;
            padding: 2px 8px;
            border-radius: 5px;
            font-size: 12px;
            font-weight: bold;
        }

        .gen-btn {
            background-color: #ffba26;
            border: none;
            padding: 15px;
            width: 100%;
            border-radius: 50px;
            cursor: pointer;
            font-family: "Red Rose", serif;
            font-size: 18px;
            margin-top: 10px;
        }

        .gen-btn:hover {
            background-color: #e5a722;
        }

        input[type=range] { width: 100%; cursor: pointer; }
    </style>
</head>
<body>

    <?php 
        include 'sidenav.php'; 
        include('db_connect.php');

        if (isset($_POST['final_approve']) && !empty($_POST['final_ids'])) {
            //$user_id = $_SESSION['user_id']; 
            $final_ids = $_POST['final_ids'];
            
            $total_price = 0;
            foreach ($final_ids as $id) {
                $key = array_search($id, array_column($wishlist, 'id'));
                if ($key !== false) $total_price += $wishlist[$key]['price'];
            }

            $find_old = $conn->query("SELECT group_id FROM itinerary WHERE user_id = $user_id");
            if ($find_old->num_rows > 0) {
                while($row = $find_old->fetch_assoc()) {
                    $old_group = $row['group_id'];
                    $conn->query("DELETE FROM itinerary_items WHERE group_id = $old_group");
                }
                $conn->query("DELETE FROM itinerary WHERE user_id = $user_id");
            }

            $stmt = $conn->prepare("INSERT INTO itinerary (est_total, user_id, group_id) VALUES (?, ?, 0)");
            $stmt->bind_param("di", $total_price, $user_id);
            
            if ($stmt->execute()) {
                $new_id = $conn->insert_id; 

                $conn->query("UPDATE itinerary SET group_id = $new_id WHERE itinerary_id = $new_id");

                $item_stmt = $conn->prepare("INSERT INTO itinerary_items (group_id, item_id, item_category) VALUES (?, ?, ?)");

                foreach ($final_ids as $id) {
                    $key = array_search($id, array_column($wishlist, 'id'));
                    $category = ($key !== false) ? $wishlist[$key]['type'] : 'Unknown'; 

                    $item_stmt->bind_param("iis", $new_id, $id, $category);
                    $item_stmt->execute();
                }

                echo "<script>alert('Successfully generated new itinerary!'); window.location.href='itinerary.php';</script>";
            } else {
                echo "Error: " . $conn->error;
            }
        }
    ?>

    <div id="main-content">
        <header style="text-align: center; padding-top: 40px;">
            <h2>Create New Itinerary</h2>
            <p>Combine your wishlist picks with our smart suggestions.</p>
        </header>

        <div id="itinerary-wrapper">
            <form method="POST" class="itinerary-grid">

                <div class="white-box">
                    <h1 style="font-size: 24px; text-align: left;">1. Selection</h1>
                    
                    <div class="budget-slider-box">
                        <label>Max Price: <strong>RM<?= $max_budget ?></strong></label>
                        <input type="range" name="budget" min="0" max="500" step="10" value="<?= $max_budget ?>" onchange="this.form.submit()">
                    </div>

                    <div style="max-height: 400px; overflow-y: auto;">
                        <?php foreach ($budget_filtered_list as $item): ?>
                            <label class="item-card js-card">
                                <div style="display: flex; justify-content: space-between; width: 100%; align-items: center;">
                                    <div>
                                        <input type="checkbox" name="selected_items[]" value="<?= $item['id'] ?>" 
                                            class="js-checkbox"
                                            <?= in_array($item['id'], $selected_ids) ? 'checked' : '' ?>>
                                        <strong><?= $item['name'] ?></strong>
                                    </div>
                                    <span class="price">RM<?= $item['price'] ?></span>
                                </div>

                                <div class="item-details">
                                    <p>Location: <?= $item['city'] ?>, <?= $item['country'] ?></p>
                                    <p><?= $item['type'] ?></p>
                                </div>
                            </label>
                        <?php endforeach; ?>
                    </div>
                    <button type="submit" name="generate" class="gen-btn">Generate Trip</button>
                </div>

                <div class="white-box">
                    <h1 style="font-size: 24px; text-align: left;">2. Your Journey</h1>
                    <?php if (!empty($final_itinerary)): ?>
                        <?php foreach ($final_itinerary as $item): 
                            $is_picked = in_array($item['id'], $selected_ids); ?>
                            <input type="hidden" name="final_ids[]" value="<?= $item['id'] ?>">
                            <div class="item-card <?= $is_picked ? 'picked' : '' ?>">
                                <div>
                                    <span class="badge"><?= $is_picked ? 'PICKED' : 'SUGGESTED' ?></span><br>
                                    <strong style="font-size: 1.1em;"><?= $item['name'] ?></strong><br>
                                    <small><?= $item['city'] ?> • <?= $item['type'] ?></small>
                                </div>
                                <span class="price" style="color: #ffba26; font-size: 20px;">RM<?= $item['price'] ?></span>
                            </div>
                        <?php endforeach; ?>

                        <button type="submit" name="final_approve" class="gen-btn" style="background-color: #28a745; color: white; margin-top: 20px;">
                            Confirm & Save Itinerary
                        </button>

                    <?php else: ?>
                        <p style="text-align: center; color: #888; margin-top: 50px;">Select items from the left to build your trip plan.</p>
                    <?php endif; ?>
                </div>

            </form>
        </div>
    </div>
    <script>
    document.querySelectorAll('.js-checkbox').forEach(checkbox => {
        if (checkbox.checked) {
            checkbox.closest('.js-card').classList.add('active');
        }

        checkbox.addEventListener('change', function() {
            const card = this.closest('.js-card');
            if (this.checked) {
                card.classList.add('active');
            } else {
                card.classList.remove('active');
            }
        });
    });
    </script>
</body>
</html>