<?php
session_start();
require_once "db_connect.php";

$search_query = "";

if (isset($_POST['search_btn']) && !empty($_POST['search_input'])) {
    $search_query = $conn->real_escape_string($_POST['search_input']);

    $sql_acco = "SELECT acco_id as id, acco_name as name, acco_address as address, acco_city as city, 'Accommodation' as type 
                 FROM accommodation 
                 WHERE acco_name LIKE '%$search_query%' OR acco_city LIKE '%$search_query%'";

    $sql_act  = "SELECT activity_id as id, activity_name as name, activity_address as address, activity_city as city, 'Activity' as type 
                 FROM activity 
                 WHERE activity_name LIKE '%$search_query%' OR activity_city LIKE '%$search_query%'";
} else {
    $sql_acco = "SELECT acco_id as id, acco_name as name, acco_address as address, acco_city as city, 'Accommodation' as type FROM accommodation LIMIT 5";
    $sql_act  = "SELECT activity_id as id, activity_name as name, activity_address as address, activity_city as city, 'Activity' as type FROM activity LIMIT 5";
}

$res_acco = $conn->query($sql_acco);
$res_act  = $conn->query($sql_act);

// Capture selected place IDs (passed via GET from "Rate This" links)
$selected_acco_id     = isset($_GET['acco_id'])     ? (int)$_GET['acco_id']     : 0;
$selected_activity_id = isset($_GET['activity_id']) ? (int)$_GET['activity_id'] : 0;
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8"/>
    <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
    <title>Leave Feedback - TrippIn</title>
    
    <link rel="stylesheet" href="style.css">
    <style>
        .topbar {
            background: #fff;
            padding: 15px 20px;
            border-radius: 12px;
            margin: 20px;
            box-shadow: 0 2px 5px rgba(0,0,0,0.05);
        }

        .search-wrap {
            display: flex;
            align-items: center;
            gap: 10px;
            max-width: 500px;
            margin: 0 auto;
        }

        .search-wrap input {
            flex: 1;
            padding: 10px 15px;
            border: 1px solid #ddd;
            border-radius: 25px;
            font-size: 14px;
            outline: none;
        }

        .search-wrap input:focus {
            border-color: #ffba26;
        }

        .search-wrap button {
            background: #ffba26;
            border: none;
            padding: 10px 20px;
            border-radius: 25px;
            cursor: pointer;
            font-weight: bold;
        }

        .content {
            padding: 0 20px 20px 20px;
        }

        .page-title {
            font-family: 'Playfair Display', serif;
            font-size: 2rem;
            margin-bottom: 5px;
            text-align: center;
        }

        .page-subtitle {
            text-align: center;
            color: #666;
            margin-bottom: 30px;
        }

        .feedback-list {
            display: flex;
            flex-direction: column;
            gap: 15px;
            margin-bottom: 40px;
        }

        .feedback-card {
            background: white;
            border: 1px solid #e4ded4;
            border-radius: 12px;
            padding: 20px;
            display: flex;
            align-items: center;
            justify-content: space-between;
            transition: box-shadow 0.2s;
        }

        .feedback-card:hover {
            box-shadow: 0 4px 12px rgba(0,0,0,0.08);
        }

        .hotel-info h2 {
            font-size: 1.2rem;
            margin: 0 0 5px 0;
            font-family: 'DM Sans', sans-serif;
        }

        .hotel-info p {
            margin: 0;
            color: #666;
            font-size: 0.85rem;
        }

        .btn-edit {
            background: #ffba26;
            padding: 8px 20px;
            border-radius: 20px;
            text-decoration: none;
            color: #1c1c1e;
            font-weight: 500;
            transition: background 0.2s;
        }

        .btn-edit:hover {
            background: #e6a500;
        }

        /* Feedback Form Card */
        .form-card {
            background: white;
            border-radius: 16px;
            border: 1px solid #e4ded4;
            padding: 30px;
            margin-top: 20px;
        }

        .form-grid {
            display: flex;
            flex-direction: column;
            gap: 25px;
        }

        .form-group label {
            display: block;
            font-weight: 600;
            margin-bottom: 10px;
            font-size: 0.9rem;
        }

        .stars {
            display: flex;
            gap: 8px;
        }

        .stars label {
            font-size: 42px;
            cursor: pointer;
            color: #ddd8d0;
            transition: transform 0.15s;
        }

        .stars label:hover {
            transform: scale(1.1);
        }

        textarea {
            width: 100%;
            padding: 12px;
            border: 1.5px solid #e4ded4;
            border-radius: 10px;
            font-family: inherit;
            font-size: 14px;
            resize: vertical;
            min-height: 120px;
            outline: none;
        }

        textarea:focus {
            border-color: #ffba26;
        }

        textarea.error {
            border-color: #e8a59e;
            background: #fdf0ef;
        }

        .photo-upload-area {
            border: 2px dashed #e4ded4;
            border-radius: 12px;
            padding: 40px 20px;
            text-align: center;
            cursor: pointer;
            background: #fafaf8;
            transition: all 0.2s;
            position: relative;
        }

        .photo-upload-area:hover,
        .photo-upload-area.drag-over {
            border-color: #ffba26;
            background: #fffdf5;
        }

        .photo-upload-area input[type="file"] {
            position: absolute;
            inset: 0;
            opacity: 0;
            cursor: pointer;
        }

        .upload-icon {
            font-size: 40px;
            margin-bottom: 10px;
        }

        .upload-label strong {
            color: #ffba26;
        }

        .upload-hint {
            font-size: 12px;
            color: #888;
            margin-top: 5px;
        }

        .photo-previews {
            display: flex;
            flex-wrap: wrap;
            gap: 10px;
            margin-top: 15px;
        }

        .photo-preview-item {
            position: relative;
            width: 80px;
            height: 80px;
        }

        .photo-preview-item img {
            width: 100%;
            height: 100%;
            object-fit: cover;
            border-radius: 8px;
            border: 1.5px solid #ffba26;
        }

        .remove-photo {
            position: absolute;
            top: -6px;
            right: -6px;
            width: 22px;
            height: 22px;
            background: #ff4444;
            color: white;
            border: none;
            border-radius: 50%;
            font-size: 12px;
            cursor: pointer;
            display: flex;
            align-items: center;
            justify-content: center;
        }

        .error-msg {
            color: #e74c3c;
            font-size: 12px;
            display: none;
            align-items: center;
            gap: 5px;
            margin-top: 5px;
        }

        .error-msg.visible {
            display: flex;
        }

        .form-actions {
            margin-top: 25px;
            text-align: center;
        }

        .btn-submit {
            background: #ffba26;
            border: none;
            padding: 12px 35px;
            border-radius: 30px;
            font-size: 16px;
            font-weight: bold;
            cursor: pointer;
            transition: background 0.2s;
        }

        .btn-submit:hover {
            background: #e6a500;
        }

        .toast {
            position: fixed;
            bottom: 30px;
            right: 30px;
            background: #28a745;
            color: white;
            padding: 12px 20px;
            border-radius: 8px;
            opacity: 0;
            transition: opacity 0.3s;
            z-index: 1000;
        }

        .toast.show {
            opacity: 1;
        }

        hr {
            margin: 20px 0;
            border: none;
            border-top: 2px solid #ffba26;
        }
    </style>
</head>
<body>

    <?php include 'sidenav.php'; ?>

    <div id="main-content">
        <div class="topbar">
            <form method="POST" action="">
                <div class="search-wrap">
                    <input type="text" name="search_input"
                           placeholder="Search hotels or activities..."
                           value="<?php echo htmlspecialchars($search_query); ?>">
                    <button type="submit" name="search_btn">Search</button>
                </div>
            </form>
        </div>

        <div class="content">
            <h1 class="page-title">Leave a Feedback</h1>
            <p class="page-subtitle">Share your experience with us!</p> 

            <div class="feedback-list">
                <?php while ($item = $res_acco->fetch_assoc()): ?>
                    <div class="feedback-card">
                        <div class="hotel-info">
                            <h2><?php echo htmlspecialchars($item['name']); ?></h2>
                            <p>🏨 <?php echo htmlspecialchars($item['type']); ?> • <?php echo htmlspecialchars($item['city']); ?></p>
                        </div>
                        <a href="feedback.php?acco_id=<?php echo $item['id']; ?>" class="btn-edit">Rate This</a>
                    </div>
                <?php endwhile; ?>

                <?php while ($item = $res_act->fetch_assoc()): ?>
                    <div class="feedback-card">
                        <div class="hotel-info">
                            <h2><?php echo htmlspecialchars($item['name']); ?></h2>
                            <p>🎡 <?php echo htmlspecialchars($item['type']); ?> • <?php echo htmlspecialchars($item['city']); ?></p>
                        </div>
                        <a href="feedback.php?activity_id=<?php echo $item['id']; ?>" class="btn-edit">Rate This</a>
                    </div>
                <?php endwhile; ?>
            </div>

            <?php if ($selected_acco_id || $selected_activity_id): ?>
            <hr>
            <div class="form-card">
                <form id="feedbackForm" method="POST" action="save_feedback.php" enctype="multipart/form-data">

                    <input type="hidden" name="acco_id"     value="<?php echo $selected_acco_id; ?>">
                    <input type="hidden" name="activity_id" value="<?php echo $selected_activity_id; ?>">

                    <div class="form-grid">
                        <!-- Rating Section -->
                        <div class="form-group star-group">
                            <label>Rating</label>
                            <div class="stars" id="starRow">
                                <label data-val="1">★</label>
                                <label data-val="2">★</label>
                                <label data-val="3">★</label>
                                <label data-val="4">★</label>
                                <label data-val="5">★</label>
                            </div>
                            <input type="hidden" name="rating" id="ratingInput" value="0"/>
                            <span class="error-msg" id="ratingError">
                                Please select a rating.
                            </span>
                        </div>

                        <!-- Description Section -->
                        <div class="form-group">
                            <label for="descriptionInput">Description *</label>
                            <textarea id="descriptionInput" name="description"
                                      placeholder="Describe your experience here..."></textarea>
                            <span class="error-msg" id="descError">
                                Description is required.
                            </span>
                        </div>

                        <!-- Photos Section -->
                        <div class="form-group">
                            <label>Photos</label>
                            <div class="photo-upload-area" id="dropZone">
                                <input type="file" id="photoInput" name="photos[]" accept="image/*" multiple/>
                                <div class="upload-icon">📷</div>
                                <div class="upload-label"><strong>Click to upload</strong> or drag &amp; drop</div>
                                <div class="upload-hint">PNG, JPG, WEBP up to 10 MB each</div>
                            </div>
                            <div class="photo-previews" id="photoPreviews"></div>
                            <span class="error-msg" id="photoError">
                                Please upload at least one photo.
                            </span>
                        </div>
                    </div>

                    <div class="form-actions">
                        <button type="button" class="btn-submit" onclick="submitFeedback()">Submit Feedback</button>
                    </div>

                </form>
            </div>
            <?php endif; ?>
        </div>
    </div>

    <div class="toast" id="toast"></div>

    <script>
        // Star rating logic
        const starRow = document.getElementById('starRow');
        const ratingInput = document.getElementById('ratingInput');
        const stars = Array.from(starRow.querySelectorAll('label'));
        let currentRating = 0;

        function paintStars(upTo) {
            stars.forEach((s, i) => {
                s.style.color = i < upTo ? '#ffba26' : '#ddd8d0';
            });
        }

        stars.forEach((star, idx) => {
            star.addEventListener('mouseenter', () => paintStars(idx + 1));
            star.addEventListener('mouseleave', () => paintStars(currentRating));
            star.addEventListener('click', () => {
                currentRating = idx + 1;
                ratingInput.value = currentRating;
                paintStars(currentRating);
                
                // Hide error if rating is selected
                document.getElementById('ratingError').classList.remove('visible');
            });
        });

        // Description validation
        const descInput = document.getElementById('descriptionInput');
        const descError = document.getElementById('descError');

        function validateDesc() {
            const empty = descInput.value.trim() === '';
            descInput.classList.toggle('error', empty);
            descError.classList.toggle('visible', empty);
            return !empty;
        }

        descInput.addEventListener('input', () => {
            if (descInput.value.trim() !== '') {
                descInput.classList.remove('error');
                descError.classList.remove('visible');
            }
        });
        descInput.addEventListener('blur', validateDesc);

        // Photo upload logic
        const photoInput = document.getElementById('photoInput');
        const photoPreviews = document.getElementById('photoPreviews');
        const dropZone = document.getElementById('dropZone');
        let uploadedFiles = [];

        function addFiles(files) {
            Array.from(files).forEach(file => {
                if (!file.type.startsWith('image/')) return;

                if (uploadedFiles.find(f => f.name === file.name && f.size === file.size)) return;

                uploadedFiles.push(file);

                const reader = new FileReader();
                reader.onload = e => {
                    const wrap = document.createElement('div');
                    wrap.className = 'photo-preview-item';

                    const img = document.createElement('img');
                    img.src = e.target.result;
                    img.alt = 'preview';

                    const btn = document.createElement('button');
                    btn.type = 'button';
                    btn.className = 'remove-photo';
                    btn.textContent = '✕';
                    btn.addEventListener('click', () => {
                        const idx = uploadedFiles.indexOf(file);
                        if (idx > -1) uploadedFiles.splice(idx, 1);
                        wrap.remove();
                        syncFileInput();
                        
                        // Hide photo error if files exist
                        if (uploadedFiles.length > 0) {
                            document.getElementById('photoError').classList.remove('visible');
                            dropZone.style.borderColor = '';
                        }
                    });

                    wrap.appendChild(img);
                    wrap.appendChild(btn);
                    photoPreviews.appendChild(wrap);
                };
                reader.readAsDataURL(file);
            });

            syncFileInput();
        }

        function syncFileInput() {
            const dt = new DataTransfer();
            uploadedFiles.forEach(f => dt.items.add(f));
            photoInput.files = dt.files;
        }

        photoInput.addEventListener('change', e => {
            addFiles(e.target.files);
        });

        dropZone.addEventListener('dragover', e => {
            e.preventDefault();
            dropZone.classList.add('drag-over');
        });
        dropZone.addEventListener('dragleave', () => dropZone.classList.remove('drag-over'));
        dropZone.addEventListener('drop', e => {
            e.preventDefault();
            dropZone.classList.remove('drag-over');
            addFiles(e.dataTransfer.files);
        });

        // Toast notification
        const toast = document.getElementById('toast');
        function showToast(msg) {
            toast.textContent = msg;
            toast.classList.add('show');
            setTimeout(() => toast.classList.remove('show'), 3200);
        }

        // Submit feedback
        function submitFeedback() {
            let valid = true;

            if (currentRating === 0) {
                document.getElementById('ratingError').classList.add('visible');
                valid = false;
            } else {
                document.getElementById('ratingError').classList.remove('visible');
            }

            if (!validateDesc()) valid = false;

            if (uploadedFiles.length === 0) {
                document.getElementById('photoError').classList.add('visible');
                dropZone.style.borderColor = '#e8a59e';
                valid = false;
            } else {
                document.getElementById('photoError').classList.remove('visible');
                dropZone.style.borderColor = '';
            }

            if (!valid) return;

            const formElement = document.getElementById('feedbackForm');
            const formData = new FormData(formElement);

            // Clear existing photos and add new ones
            formData.delete('photos[]');
            uploadedFiles.forEach(file => {
                formData.append('photos[]', file);
            });

            fetch('save_feedback.php', {
                method: 'POST',
                body: formData
            })
            .then(response => response.text())
            .then(data => {
                console.log("Server Response:", data);
                showToast('Feedback submitted successfully!');
                setTimeout(() => { 
                    window.location.href = 'view_feedback.php'; 
                }, 1500);
            })
            .catch(error => {
                console.error('Error:', error);
                alert('Submission failed. Please try again.');
            });
        }
    </script>

</body>
</html>