<!DOCTYPE html>
<html lang="en">
<head>

</head>
<body>
    <?php include 'adminsidenav.php'; ?>
    
    <div id="main-content">
        <h2>Welcome to TrippIn!</h2>
        <p>This is the admin page. You may edit available listings as necessary.
        <p><<< Use the navigations on the side bar.</p>


</body>
</html>