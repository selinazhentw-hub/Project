<?php
include 'sidenav.php';
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <title>Find Accommodation</title>

    <style>
        body {
            margin: 0;
            font-family: Arial, sans-serif;

            background: url('https://images.unsplash.com/photo-1507525428034-b723cf961d3e') no-repeat center center fixed;
            background-size: cover;
        }

        body::before {
            content: "";
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0,0,0,0.45);
            z-index: -1;
        }

        #main-content {
            display: flex;
            justify-content: center;
            align-items: center;
            height: 90vh;
        }

        .search-box {
            background: rgba(255, 255, 255, 0.08);
            backdrop-filter: blur(12px);
            padding: 40px;
            border-radius: 15px;
            width: 400px;
            box-shadow: 0 10px 25px rgba(0,0,0,0.3);
            color: white;
        }

        .search-box h2 {
            text-align: center;
            margin-bottom: 20px;
            color: white;
        }

        .search-box label {
            font-weight: bold;
        }

        .search-box input {
            width: 100%;
            padding: 10px;
            margin-top: 5px;
            margin-bottom: 15px;
            border-radius: 8px;
            border: 1px solid rgba(255,255,255,0.4);
            background: rgba(255,255,255,0.1);
            color: white;
        }

        .search-box input::placeholder {
            color: #ddd;
        }

        .search-box input:focus {
            outline: none;
            border: 1px solid #4facfe;
        }

        /* BUTTON */
        .search-box button {
            width: 100%;
            padding: 12px;
            background: rgba(0, 123, 255, 0.8);
            color: white;
            border: none;
            border-radius: 10px;
            font-size: 16px;
            cursor: pointer;
            transition: 0.3s;
        }

        .search-box button:hover {
            background: rgba(0, 123, 255, 1);
        }
    </style>
</head>

<body>

<?php
date_default_timezone_set("Asia/Kuala_Lumpur");
$today = date('Y-m-d');
?>

<div id="main-content">
    <div class="search-box">
        <h2>Find Your Stay</h2>

        <form action="accommodation_result.php" method="GET">

            <label>Country</label>
            <input type="text" name="country" placeholder="e.g. Malaysia" required>

            <label>City</label>
            <input type="text" name="city" placeholder="e.g. Kuala Lumpur" required>

            <label>Check-in</label>
            <input type="date" name="checkin" min="<?php echo $today; ?>" required>

            <label>Check-out</label>
            <input type="date" name="checkout" min="<?php echo $today; ?>" required>

            <button type="submit">Search</button>

        </form>
    </div>
</div>

</body>
</html>