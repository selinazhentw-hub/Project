<?php
require_once 'db_connect.php';
$result = $conn->query("SELECT * FROM accommodation ORDER BY acco_id DESC");
$data = [];
while ($row = $result->fetch_assoc()) { $data[] = $row; }
echo json_encode(["success" => true, "data" => $data]);
?>