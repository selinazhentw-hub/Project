<?php
session_start();
require_once "db_connect.php";

if (!isset($_SESSION["admin_name"])) {
    die("Access Denied: Admins Only.");
}

$sql = "SELECT f.*, u.user_name, u.user_email, a.acco_name, act.activity_name,
        GROUP_CONCAT(p.feedback_photo_url) as photos
        FROM feedback f
        JOIN user u ON f.user_id = u.user_id
        LEFT JOIN accommodation a ON f.acco_id = a.acco_id
        LEFT JOIN activity act ON f.activity_id = act.activity_id
        LEFT JOIN feedback_photo p ON f.feedback_id = p.feedback_id
        GROUP BY f.feedback_id
        ORDER BY f.feedback_id DESC";

$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Feedback - TrippIn</title>
    <style>
        body { display: flex; margin: 0; font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; background-color: #f5f2ed; color: #333; }
        #main-content { flex: 1; margin-left: 250px; padding: 40px; }
        
        h2 { color: #b5834a; margin-bottom: 25px; font-weight: 600; }

        .admin-table {
            width: 100%;
            border-collapse: collapse;
            background: white;
            box-shadow: 0 4px 15px rgba(0,0,0,0.08);
            border-radius: 8px;
            overflow: hidden;
        }
        
        .admin-table th { 
            background-color: #b5834a; 
            color: white; 
            text-align: left; 
            padding: 18px 15px;
            font-size: 0.9rem;
            text-transform: uppercase;
            letter-spacing: 1px;
        }

        .admin-table td { 
            padding: 15px; 
            border-bottom: 1px solid #eee; 
            vertical-align: middle;
        }

        .admin-table tr:hover { background-color: #fcfaf7; }

        /* Rating Stars */
        .stars { color: #f1c40f; font-size: 1.1rem; letter-spacing: 2px; }

        /* Photo Gallery in Table */
        .feedback-photos { display: flex; gap: 8px; flex-wrap: wrap; max-width: 200px; }
        .feedback-photos img { 
            width: 50px; 
            height: 50px; 
            object-fit: cover; 
            border-radius: 6px; 
            border: 1px solid #eee;
            transition: transform 0.2s;
        }
        .feedback-photos img:hover { transform: scale(1.1); }

        /* Delete Button Style */
        .btn-delete {
            background-color: #ff4757;
            color: white;
            padding: 8px 12px;
            text-decoration: none;
            border-radius: 4px;
            font-size: 0.85rem;
            font-weight: bold;
            transition: background 0.3s;
        }
        .btn-delete:hover { background-color: #ff6b81; }

        .no-photo { color: #bbb; font-size: 0.8rem; font-style: italic; }
    </style>
</head>
<body>

    <?php include 'adminsidenav.php'; ?>

    <div id="main-content">
        <h2>User Feedback Management</h2>
        
        <table class="admin-table">
            <thead>
                <tr>
                    <th>User</th>
                    <th>Place</th>
                    <th>Rating</th>
                    <th>Photos</th> 
                    <th>Comment</th>
                    <th style="text-align: center;">Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php while($row = $result->fetch_assoc()): ?>
                <tr>
                    <td>
                        <?php echo htmlspecialchars($row['user_name']); ?><br>
                        <small style="color: #888;"><?php echo htmlspecialchars($row['user_email']); ?></small>
                    </td>
                    <td><?php echo htmlspecialchars($row['acco_name'] ?? $row['activity_name'] ?? 'N/A'); ?></td>
                    <td><span class="stars"><?php echo str_repeat('★', (int)$row['rating']); ?></span></td>
                    
                    <td>
                        <div class="feedback-photos">
                            <?php 
                            if (!empty($row['photos'])) {
                                $photo_array = explode(',', $row['photos']);
                                foreach ($photo_array as $photo_url) {
                                    echo '<img src="uploads/feedback/' . htmlspecialchars(trim($photo_url)) . '" alt="Feedback">';
                                }
                            } else {
                                echo '<span class="no-photo">No photos</span>';
                            }
                            ?>
                        </div>
                    </td>

                    <td style="max-width: 300px; line-height: 1.4;">
                        <?php echo nl2br(htmlspecialchars($row['feedback_description'])); ?>
                    </td>
                    
                    <td style="text-align: center;">
                        <a href="delete_display_feedback.php?id=<?php echo $row['feedback_id']; ?>" 
                           class="btn-delete"
                           onclick="return confirm('Are you sure you want to delete this review?')">Delete</a>
                    </td>
                </tr>
                <?php endwhile; ?>
            </tbody>
        </table>
    </div>
</body>
</html>