<?php
if (session_status() === PHP_SESSION_NONE) { session_start(); }
require_once "db_connect.php";



if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $user_email = $_SESSION['user_email'] ?? '';
    if (empty($user_email)) { header("Location: login.php"); exit; }

    $stmt = $conn->prepare("SELECT user_id FROM user WHERE user_email = ?");
    $stmt->bind_param("s", $user_email);
    $stmt->execute();
    $user_data = $stmt->get_result()->fetch_assoc();
    $user_id = $user_data['user_id'];
    $stmt->close();

    $rating      = intval($_POST['rating']);
    $description = $_POST['description']; 
    $acco_id     = (!empty($_POST['acco_id']) && $_POST['acco_id'] != 0) ? intval($_POST['acco_id']) : null;
    $activity_id = (!empty($_POST['activity_id']) && $_POST['activity_id'] != 0) ? intval($_POST['activity_id']) : null;

    $stmt = $conn->prepare("INSERT INTO feedback (user_id, acco_id, activity_id, rating, feedback_description) VALUES (?, ?, ?, ?, ?)");
    $stmt->bind_param("iiiss", $user_id, $acco_id, $activity_id, $rating, $description);

    if ($stmt->execute()) {
        $new_id = $conn->insert_id;
        $stmt->close(); 

        
       $upload_dir = "uploads/feedback/"; 
        if (!is_dir($upload_dir)) { 
            mkdir($upload_dir, 0755, true); 
        }

        if (!empty($_FILES['photos']['name'][0])) {
            $photo_stmt = $conn->prepare("INSERT INTO feedback_photo (feedback_id, feedback_photo_url) VALUES (?, ?)");
            foreach ($_FILES['photos']['tmp_name'] as $key => $tmp_name) {
                if ($_FILES['photos']['error'][$key] !== UPLOAD_ERR_OK) continue;

                $ext = pathinfo($_FILES['photos']['name'][$key], PATHINFO_EXTENSION);
                
                $new_name = uniqid('fb_', true) . '.' . strtolower($ext);
                
                if (move_uploaded_file($tmp_name, $upload_dir . $new_name)) {
                    $photo_stmt->bind_param("is", $new_id, $new_name);
                    $photo_stmt->execute();
                }
            }
}
        
        header("Location: view_feedback.php");
        exit(); 
    } else {
        die("Error inserting feedback: " . $stmt->error);
    }
}
?>
