<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=yes">
    <title>Admin - Manage Activities | TrippIn</title>
    <link rel="stylesheet" href="style.css">
    <style>
        .admin-panel-container {
            margin-left: 250px;
            padding: 30px 40px;
            background-color: #f5f5dc; 
            min-height: 100vh;
            width: calc(100% - 250px); 
            box-sizing: border-box;
            font-family: 'Montserrat', sans-serif;
        }
        .admin-header {
            text-align: center;
            margin-bottom: 32px;
            border-bottom: 3px solid #ffba26;
            padding-bottom: 20px;
        }

        .admin-header h2 {
            font-family: 'Londrina Shadow', sans-serif;
            font-size: 48px;
            margin: 0 0 8px 0;
            color: #2c2c2c;
            letter-spacing: 2px;
        }

        .admin-header p {
            margin: 0;
            font-size: 1rem;
            color: #5e5e5e;
        }

        .add-btn-wrapper {
            text-align: center;
            margin-bottom: 30px;
        }

        .add-new-btn {
            background-color: #ffba26;
            border: none;
            border-radius: 50px;
            padding: 12px 32px;
            font-family: 'Red Rose', serif;
            font-weight: bold;
            font-size: 1rem;
            cursor: pointer;
            transition: all 0.2s ease;
            box-shadow: 0 2px 8px rgba(0,0,0,0.1);
            display: inline-flex;
            align-items: center;
            gap: 10px;
        }

        .add-new-btn:hover {
            background-color: #e6a500;
            transform: translateY(-2px);
        }

        .toolbar-row {
            display: flex;
            flex-wrap: wrap;
            justify-content: center;
            align-items: center;
            gap: 20px;
            margin: 20px auto 35px auto;
            background: #fff8ed;
            padding: 16px 28px;
            border-radius: 60px;
            border: 1px solid #ffdfa5;
            max-width: 800px;
        }

        .search-filter {
            display: flex;
            gap: 12px;
            flex-wrap: wrap;
            align-items: center;
            justify-content: center;
        }

        .search-filter input, .search-filter select {
            border: 1px solid #e2d5bc;
            border-radius: 50px;
            padding: 10px 20px;
            font-family: 'Montserrat', sans-serif;
            background: white;
            outline: none;
        }

        .search-filter input {
            width: 240px;
        }

        .stats-badge {
            background: #ffba2633;
            border-radius: 40px;
            padding: 8px 20px;
            font-size: 0.85rem;
            font-weight: 500;
            color: #4a3b1a;
        }

        .admin-activities-grid {
            display: grid;
            grid-template-columns: repeat(2, 1fr); 
            gap: 24px;
            margin-top: 20px;
            width: 100%;
        }

        .activity-admin-card {
            background: white;
            border-radius: 24px;
            border: 1px solid #f0e2cc;
            transition: all 0.25s ease;
            display: flex;
            flex-direction: row;
            align-items: center;
            justify-content: space-between;
            padding: 20px 24px;
            box-shadow: 0 2px 8px rgba(0,0,0,0.04);
        }

        .activity-admin-card:hover {
            box-shadow: 0 10px 25px rgba(0,0,0,0.1);
            border-color: #ffba2680;
            transform: translateY(-3px);
        }

        .card-info {
            display: flex;
            gap: 18px;
            align-items: center;
            flex: 2;
        }

        .card-img {
            width: 85px;
            height: 85px;
            background-color: #f9efdf;
            border-radius: 20px;
            object-fit: cover;
            border: 2px solid #ffba26;
        }

        .card-details h4 {
            margin: 0 0 8px 0;
            font-family: 'Red Rose', serif;
            font-size: 1.2rem;
        }

        .card-details .category {
            display: inline-block;
            background: #ffba2633;
            padding: 2px 10px;
            border-radius: 20px;
            font-size: 0.7rem;
            margin-bottom: 6px;
        }

        .card-details .location {
            font-size: 0.8rem;
            color: #7c6e51;
            display: flex;
            gap: 15px;
            flex-wrap: wrap;
            margin-bottom: 8px;
        }

        .price-tag {
            font-weight: bold;
            background: #fff0db;
            display: inline-block;
            padding: 4px 14px;
            border-radius: 30px;
            font-size: 0.8rem;
        }

        .card-actions {
            display: flex;
            gap: 12px;
            align-items: center;
            flex-shrink: 0;
        }

        .edit-btn, .delete-btn {
            border: none;
            background: transparent;
            font-family: 'Red Rose', serif;
            font-size: 0.85rem;
            padding: 8px 18px;
            border-radius: 40px;
            cursor: pointer;
            transition: all 0.2s;
            font-weight: 500;
        }

        .edit-btn {
            background-color: #ffba26;
            color: #1e1e1e;
        }

        .edit-btn:hover {
            background-color: #e6a500;
        }

        .delete-btn {
            background-color: #f9e2db;
            color: #b34a3a;
        }

        .delete-btn:hover {
            background-color: #f3ccc2;
            color: #8b2c1c;
        }

        .empty-message {
            text-align: center;
            background: white;
            padding: 60px;
            border-radius: 40px;
            margin-top: 30px;
            color: #a7a08a;
            grid-column: span 2;
        }

        .image-preview-area {
            margin-top: 10px;
            margin-bottom: 10px;
        }

        .current-image {
            display: inline-flex;
            align-items: center;
            gap: 10px;
            background: #f5f5dc;
            padding: 8px 15px;
            border-radius: 30px;
            font-size: 0.8rem;
        }

        .current-image img {
            width: 40px;
            height: 40px;
            object-fit: cover;
            border-radius: 10px;
        }

        .preview-img {
            margin-top: 10px;
            max-width: 150px;
            max-height: 100px;
            border-radius: 12px;
            border: 2px solid #ffba26;
        }

        @media (max-width: 900px) {
            .admin-activities-grid {
                grid-template-columns: 1fr;
            }
            .empty-message {
                grid-column: span 1;
            }
        }

        @media (max-width: 700px) {
            .admin-panel-container {
                margin-left: 200px;
                padding: 20px;
            }
            .activity-admin-card {
                flex-direction: column;
                align-items: flex-start;
                gap: 15px;
            }
            .card-actions {
                width: 100%;
                justify-content: flex-end;
            }
        }

        .admin-modal {
            display: none;
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background-color: rgba(0,0,0,0.6);
            z-index: 10000;
            justify-content: center;
            align-items: center;
            backdrop-filter: blur(2px);
        }

        .admin-modal .modal-card {
            background: #ffffff;
            border-radius: 32px;
            width: 600px;
            max-width: 92%;
            padding: 28px 30px;
            border-top: 8px solid #ffba26;
            box-shadow: 0 20px 35px rgba(0,0,0,0.2);
            font-family: 'Montserrat', sans-serif;
            max-height: 90vh;
            overflow-y: auto;
        }

        .modal-card h3 {
            font-family: 'Red Rose', serif;
            margin-top: 0;
            margin-bottom: 20px;
            font-size: 1.7rem;
        }

        .modal-card label {
            display: block;
            margin: 12px 0 5px;
            font-weight: 600;
            font-size: 0.85rem;
        }

        .modal-card input, .modal-card select, .modal-card textarea {
            width: 100%;
            padding: 10px 14px;
            border-radius: 20px;
            border: 1px solid #ddd5c4;
            font-family: 'Montserrat', sans-serif;
            background: #fefcf8;
            outline: none;
        }

        .modal-card input[type="file"] {
            padding: 8px;
        }

        .modal-card textarea {
            resize: vertical;
            min-height: 80px;
        }

        .form-row {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 15px;
        }

        .modal-actions {
            display: flex;
            justify-content: flex-end;
            gap: 14px;
            margin-top: 28px;
        }

        .modal-actions button {
            padding: 9px 25px;
            border-radius: 50px;
            border: none;
            cursor: pointer;
            font-weight: bold;
            font-family: 'Red Rose', serif;
        }

        .modal-save { background-color: #ffba26; }
        .modal-cancel { background-color: #eae0d0; }

        .toast-msg {
            position: fixed;
            bottom: 30px;
            right: 30px;
            background: #2c2c2c;
            color: #ffefcf;
            padding: 10px 20px;
            border-radius: 60px;
            font-size: 0.85rem;
            z-index: 10001;
        }
    </style>
</head>
<body>
    <?php include 'adminsidenav.php'; ?>
    
    <div class="admin-panel-container">
        <div class="admin-header">
            <h2>Manage Activities</h2>
            <p>Add, edit or remove touristic activities</p>
        </div>

        <div class="add-btn-wrapper">
            <button class="add-new-btn" id="openAddActivityBtn">+ New Activity</button>
        </div>

        <div class="toolbar-row">
            <div class="search-filter">
                <input type="text" id="searchActivityInput" placeholder="🔍 Search by name, city...">
                <select id="categoryFilterSelect" class="filter-select">
                    <option value="">All Categories</option>
                </select>
                <select id="countryFilterSelect" class="filter-select">
                    <option value="">All Countries</option>
                </select>
            </div>
            <div class="stats-badge" id="activityCountBadge">0 activities</div>
        </div>

        <div id="activitiesListContainer" class="admin-activities-grid">
            <div class="empty-message">Loading activities...</div>
        </div>
    </div>

    <div id="activityModal" class="admin-modal">
        <div class="modal-card">
            <h3 id="modalTitle">Add Activity</h3>
            <form id="activityForm">
                <input type="hidden" id="editActivityId" value="">
                <input type="hidden" id="existingImage" value="">
                
                <div class="form-row">
                    <div>
                        <label>Activity Name *</label>
                        <input type="text" id="actName" required>
                    </div>
                    <div>
                        <label>Category *</label>
                        <select id="actCategory" required>
                            <option value="">Select</option>
                            <option value="Adventure">Adventure</option>
                            <option value="Cultural">Cultural</option>
                            <option value="Nature">Nature</option>
                            <option value="Food">Food & Drink</option>
                            <option value="Shopping">Shopping</option>
                            <option value="Sightseeing">Sightseeing</option>
                            <option value="Wellness">Wellness</option>
                        </select>
                    </div>
                </div>

                <div class="form-row">
                    <div>
                        <label>Country *</label>
                        <input type="text" id="actCountry" required>
                    </div>
                    <div>
                        <label>City *</label>
                        <input type="text" id="actCity" required>
                    </div>
                </div>

                <label>Address</label>
                <input type="text" id="actAddress" placeholder="Full address">

                <div class="form-row">
                    <div>
                        <label>Price (RM) *</label>
                        <input type="number" id="actPrice" step="0.01" placeholder="0.00" required>
                    </div>
                </div>

                <label>Description</label>
                <textarea id="actDescription" placeholder="Describe the experience..."></textarea>

                <label>Activity Image</label>
                <input type="file" id="actImage" accept="image/jpeg,image/png,image/jpg,image/gif">
                <small style="font-size: 12px; color: #776b4f;">Supported file format: JPG, PNG, GIF, maximum 5MB.</small>
            
                <div id="imagePreviewArea" class="image-preview-area"></div>

                <div class="modal-actions">
                    <button type="button" class="modal-cancel" id="closeModalBtn">Cancel</button>
                    <button type="submit" class="modal-save">Save Activity</button>
                </div>
            </form>
        </div>
    </div>

    <script>
        let activitiesData = [];
        let currentSearchTerm = '';
        let currentCategoryFilter = '';
        let currentCountryFilter = '';

        async function loadActivitiesFromServer() {
            try {
                const response = await fetch('api_get_activities.php');
                const result = await response.json();
                if (result.success) {
                    activitiesData = result.data;
                    renderActivitiesList();
                    populateFilters();
                } else {
                    activitiesData = [];
                    renderActivitiesList();
                }
            } catch (error) {
                console.error('Error:', error);
                activitiesData = [];
                renderActivitiesList();
            }
        }

        async function saveActivityToServer(activity, isEdit, imageFile = null) {
            let formData = new FormData();
            formData.append('action', isEdit ? 'update' : 'add');
            if (isEdit) formData.append('activity_id', activity.activity_id);
            formData.append('activity_name', activity.activity_name);
            formData.append('activity_category', activity.activity_category);
            formData.append('activity_country', activity.activity_country);
            formData.append('activity_city', activity.activity_city);
            formData.append('activity_price', activity.activity_price);
            formData.append('activity_address', activity.activity_address || '');
            formData.append('activity_description', activity.activity_description || '');
            formData.append('existing_image', activity.activity_image || '');
            
            if (imageFile) {
                formData.append('image', imageFile);
            }
            
            const response = await fetch('api_save_activity.php', {
                method: 'POST',
                body: formData
            });
            return await response.json();
        }

        async function deleteActivityFromServer(id) {
            const response = await fetch('api_delete_activity.php', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ activity_id: id })
            });
            return await response.json();
        }

        function renderActivitiesList() {
            const container = document.getElementById('activitiesListContainer');
            if (!container) return;
            
            let filtered = [...activitiesData];
            
            if (currentSearchTerm.trim() !== '') {
                const term = currentSearchTerm.toLowerCase();
                filtered = filtered.filter(act => 
                    act.activity_name.toLowerCase().includes(term) ||
                    act.activity_city.toLowerCase().includes(term)
                );
            }
            
            if (currentCategoryFilter !== '') {
                filtered = filtered.filter(act => act.activity_category === currentCategoryFilter);
            }
            
            if (currentCountryFilter !== '') {
                filtered = filtered.filter(act => act.activity_country === currentCountryFilter);
            }
            
            const badge = document.getElementById('activityCountBadge');
            if (badge) badge.innerText = `${filtered.length} ${filtered.length === 1 ? 'activity' : 'activities'}`;
            
            if (filtered.length === 0) {
                container.innerHTML = `<div class="empty-message">✨ No activities found. Click "New Activity" to add one.</div>`;
                return;
            }
            
            let html = '';
            filtered.forEach(act => {
                let imgSrc = act.activity_image ? `images/${act.activity_image}` : 'images/placeholder.jpg';
                if (!act.activity_image) imgSrc = 'https://cdn-icons-png.flaticon.com/512/1995/1995572.png';
                
                html += `
                    <div class="activity-admin-card" data-id="${act.activity_id}">
                        <div class="card-info">
                            <img class="card-img" src="${imgSrc}" onerror="this.src='https://cdn-icons-png.flaticon.com/512/1995/1995572.png'">
                            <div class="card-details">
                                <h4>${escapeHtml(act.activity_name)}</h4>
                                <span class="category">${escapeHtml(act.activity_category)}</span>
                                <div class="location">
                                    <span>📍 ${escapeHtml(act.activity_city)}, ${escapeHtml(act.activity_country)}</span>
                                    <span class="price-tag">💰 RM ${parseFloat(act.activity_price).toFixed(2)}</span>
                                </div>
                            </div>
                        </div>
                        <div class="card-actions">
                            <button class="edit-btn" data-id="${act.activity_id}">✏️ Edit</button>
                            <button class="delete-btn" data-id="${act.activity_id}">🗑️ Delete</button>
                        </div>
                    </div>
                `;
            });
            container.innerHTML = html;
            
            document.querySelectorAll('.edit-btn').forEach(btn => {
                btn.addEventListener('click', () => {
                    const id = btn.getAttribute('data-id');
                    openEditModal(parseInt(id));
                });
            });
            document.querySelectorAll('.delete-btn').forEach(btn => {
                btn.addEventListener('click', async () => {
                    if (confirm('Delete this activity permanently?')) {
                        const result = await deleteActivityFromServer(parseInt(btn.dataset.id));
                        if (result.success) {
                            showToast('Activity deleted');
                            loadActivitiesFromServer();
                        } else {
                            showToast('Delete failed: ' + (result.message || 'Unknown error'));
                        }
                    }
                });
            });
        }
        
        function populateFilters() {
            const categorySelect = document.getElementById('categoryFilterSelect');
            const countrySelect = document.getElementById('countryFilterSelect');
            
            const categories = [...new Set(activitiesData.map(a => a.activity_category).filter(c => c))];
            categorySelect.innerHTML = '<option value="">All Categories</option>' + 
                categories.map(c => `<option value="${escapeHtml(c)}">${escapeHtml(c)}</option>`).join('');
            
            const countries = [...new Set(activitiesData.map(a => a.activity_country).filter(c => c))];
            countrySelect.innerHTML = '<option value="">All Countries</option>' + 
                countries.map(c => `<option value="${escapeHtml(c)}">${escapeHtml(c)}</option>`).join('');
        }
        
        function setupImagePreview() {
            const fileInput = document.getElementById('actImage');
            fileInput.onchange = function() {
                const previewArea = document.getElementById('imagePreviewArea');
                if (fileInput.files && fileInput.files[0]) {
                    const reader = new FileReader();
                    reader.onload = e => previewArea.innerHTML = `<img src="${e.target.result}" class="preview-img">`;
                    reader.readAsDataURL(fileInput.files[0]);
                }
            };
        }
        
        async function saveActivityFromModal(isEditMode, activityId = null) {
            const activity = {
                activity_name: document.getElementById('actName').value.trim(),
                activity_category: document.getElementById('actCategory').value,
                activity_country: document.getElementById('actCountry').value.trim(),
                activity_city: document.getElementById('actCity').value.trim(),
                activity_price: parseFloat(document.getElementById('actPrice').value),
                activity_address: document.getElementById('actAddress').value.trim(),
                activity_description: document.getElementById('actDescription').value.trim(),
                activity_image: document.getElementById('existingImage').value
            };
            
            if (!activity.activity_name || !activity.activity_category || !activity.activity_country || 
                !activity.activity_city || isNaN(activity.activity_price) || activity.activity_price <= 0) {
                alert('Please fill all required fields (Name, Category, Country, City, Price)');
                return false;
            }
            
            if (isEditMode && activityId) activity.activity_id = activityId;
            
            const imageFile = document.getElementById('actImage').files[0];
            const result = await saveActivityToServer(activity, isEditMode, imageFile);
            
            if (result.success) {
                showToast(isEditMode ? 'Activity updated!' : 'Activity added!');
                closeModal();
                loadActivitiesFromServer();
            } else {
                alert('Save failed: ' + (result.message || 'Unknown error'));
            }
            return result.success;
        }
        
        function openEditModal(id) {
            const numericId = parseInt(id);
            const activity = activitiesData.find(a => parseInt(a.activity_id) === numericId);
            
            if (!activity) {
                showToast('Activity not found');
                return;
            }
            
            document.getElementById('modalTitle').innerText = 'Edit Activity';
            document.getElementById('editActivityId').value = activity.activity_id;
            document.getElementById('existingImage').value = activity.activity_image || '';
            document.getElementById('actName').value = activity.activity_name || '';
            document.getElementById('actCategory').value = activity.activity_category || '';
            document.getElementById('actCountry').value = activity.activity_country || '';
            document.getElementById('actCity').value = activity.activity_city || '';
            document.getElementById('actPrice').value = activity.activity_price || '';
            document.getElementById('actAddress').value = activity.activity_address || '';
            document.getElementById('actDescription').value = activity.activity_description || '';
            document.getElementById('actImage').value = '';
            
            const previewArea = document.getElementById('imagePreviewArea');
            if (previewArea) {
                if (activity.activity_image) {
                    previewArea.innerHTML = `<div class="current-image"><img src="images/${activity.activity_image}"><span>Current: ${activity.activity_image}</span></div>`;
                } else {
                    previewArea.innerHTML = '<p style="font-size:12px;">No image</p>';
                }
            }
            
            const modal = document.getElementById('activityModal');
            if (modal) {
                modal.style.display = 'flex';
            }
        }
                
        function openAddModal() {
            document.getElementById('modalTitle').innerText = 'Add New Activity';
            document.getElementById('editActivityId').value = '';
            document.getElementById('existingImage').value = '';
            document.getElementById('actName').value = '';
            document.getElementById('actCategory').value = '';
            document.getElementById('actCountry').value = '';
            document.getElementById('actCity').value = '';
            document.getElementById('actPrice').value = '';
            document.getElementById('actAddress').value = '';
            document.getElementById('actDescription').value = '';
            document.getElementById('actImage').value = '';
            const previewArea = document.getElementById('imagePreviewArea');
            if (previewArea) {
                previewArea.innerHTML = '<p style="font-size:12px;">Select image to preview</p>';
            }
            document.getElementById('activityModal').style.display = 'flex';
        }
        
        function closeModal() { 
            document.getElementById('activityModal').style.display = 'none'; 
        }
        
        function showToast(msg) {
            let toast = document.querySelector('.toast-msg');
            if (toast) toast.remove();
            const div = document.createElement('div');
            div.className = 'toast-msg';
            div.innerText = msg;
            document.body.appendChild(div);
            setTimeout(() => div.remove(), 2500);
        }
        
        function escapeHtml(str) { 
            return str ? String(str).replace(/[&<>]/g, m => ({'&':'&amp;','<':'&lt;','>':'&gt;'})[m]) : ''; 
        }
        
        document.addEventListener('DOMContentLoaded', () => {
            loadActivitiesFromServer();
            setupImagePreview();
            document.getElementById('openAddActivityBtn').onclick = openAddModal;
            document.getElementById('closeModalBtn').onclick = closeModal;
            document.getElementById('activityForm').onsubmit = async (e) => {
                e.preventDefault();
                const editId = document.getElementById('editActivityId').value;
                await saveActivityFromModal(!!editId, editId ? parseInt(editId) : null);
            };
            document.getElementById('searchActivityInput').oninput = (e) => {
                currentSearchTerm = e.target.value;
                renderActivitiesList();
            };
            document.getElementById('categoryFilterSelect').onchange = (e) => {
                currentCategoryFilter = e.target.value;
                renderActivitiesList();
            };
            document.getElementById('countryFilterSelect').onchange = (e) => {
                currentCountryFilter = e.target.value;
                renderActivitiesList();
            };
            window.onclick = (e) => { 
                if (e.target === document.getElementById('activityModal')) closeModal(); 
            };
        });
    </script>
</body>
</html>