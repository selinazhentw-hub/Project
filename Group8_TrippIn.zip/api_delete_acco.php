<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

header('Content-Type: application/json');
require_once 'db_connect.php';

if ($conn->connect_error) {
    echo json_encode(["success" => false, "message" => "Database connection failed: " . $conn->connect_error]);
    exit;
}

$response = ["success" => false, "message" => "Unknown error"];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $input = json_decode(file_get_contents('php://input'), true);
    $id = isset($input['acco_id']) ? intval($input['acco_id']) : 0;
    
    if ($id > 0) {
        $imgStmt = $conn->prepare("SELECT acco_image FROM accommodation WHERE acco_id = ?");
        $imgStmt->bind_param("i", $id);
        $imgStmt->execute();
        $imgResult = $imgStmt->get_result();
        $row = $imgResult->fetch_assoc();
        
        if ($row && !empty($row['acco_image'])) {
            $imagePath = 'images/' . $row['acco_image'];
            if (file_exists($imagePath)) {
                unlink($imagePath);
            }
        }
        $imgStmt->close();
        
        $stmt = $conn->prepare("DELETE FROM accommodation WHERE acco_id = ?");
        $stmt->bind_param("i", $id);
        
        if ($stmt->execute()) {
            $response = ["success" => true];
        } else {
            $response = ["success" => false, "message" => "Delete failed: " . $stmt->error];
        }
        $stmt->close();
    } else {
        $response = ["success" => false, "message" => "Invalid ID"];
    }
} else {
    $response = ["success" => false, "message" => "POST method required"];
}

echo json_encode($response);
exit;
?>