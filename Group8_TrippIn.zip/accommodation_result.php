<?php
include 'db_connect.php';

error_reporting(E_ALL);
ini_set('display_errors', 1);

if (!isset($_GET['country'], $_GET['city'], $_GET['checkin'], $_GET['checkout'])) {
    die("No search data received.");
}

$country = $_GET['country'];
$city = $_GET['city'];
$checkin = $_GET['checkin'];
$checkout = $_GET['checkout'];

$days = (strtotime($checkout) - strtotime($checkin)) / (60 * 60 * 24);
if ($days <= 0) $days = 1;

$sql = "SELECT * FROM accommodation
        WHERE acco_country LIKE '%$country%' 
        AND acco_city LIKE '%$city%'";

$result = $conn->query($sql);

if (!$result) {
    die("SQL Error: " . $conn->error);
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
<title>Search Results</title>
<?php include 'sidenav.php'; ?>

<style>
body {
    margin: 0;
    font-family: Arial, sans-serif;
    background: url('https://images.unsplash.com/photo-1507525428034-b723cf961d3e') no-repeat center center fixed;
    background-size: cover;
}

body::before {
    content: "";
    position: fixed;
    width: 100%;
    height: 100%;
    background: rgba(0,0,0,0.45);
    z-index: -1;
}

#main-content {
    padding: 30px;
}

h2 {
    text-align: center;
    color: white;
}

.info {
    text-align: center;
    color: #ddd;
    margin-bottom: 20px;
}

.card-container {
    display: grid;
    grid-template-columns: repeat(auto-fill, minmax(300px, 1fr));
    gap: 20px;
    align-items: start;
}

.card {
    background: rgba(255, 255, 255, 0.08);
    backdrop-filter: blur(12px);
    border-radius: 15px;
    overflow: hidden;
    box-shadow: 0 8px 25px rgba(0,0,0,0.3);
}

.card-img {
    width: 100%;
    height: 180px;
    background-size: cover;
    background-position: center;
    background-repeat: no-repeat;
    display: block;
}

.card-content {
    padding: 15px;
    color: white;
}

.card-content h3 {
    margin-bottom: 5px;
}

.card-content p {
    margin: 4px 0;
}

.price, .total {
    color: white;
    font-weight: bold;
}

.btn {
    display: block;
    text-align: center;
    padding: 10px;
    margin-top: 10px;
    color: white;
    background: rgba(0, 123, 255, 0.85);
    border-radius: 8px;
    cursor: pointer;
    transition: 0.2s;
}

.btn:hover {
    background: rgba(0, 123, 255, 1);
}

.extra {
    display: none;
    margin-top: 10px;
    border-top: 1px solid rgba(255,255,255,0.3);
    padding-top: 10px;
}

.extra.show {
    display: block;
}

.description-text {
    color: white;
    line-height: 1.6;
    font-size: 14px;
    margin-top: 8px;
    text-align: justify;
    max-height: 180px;
    overflow-y: auto;
    padding-right: 5px;
}

.description-text::-webkit-scrollbar {
    width: 4px;
}

.description-text::-webkit-scrollbar-thumb {
    background: rgba(255,255,255,0.4);
    border-radius: 5px;
}

.no-result {
    text-align: center;
    color: white;
}
</style>



</head>

<body>

<div id="main-content">

<h2>Available Accommodation</h2>

<div class="info">
<?php echo "$city, $country"; ?><br>
Stay: <?php echo $days; ?> day(s)
</div>

<div class="card-container">

<?php
$index = 0;

if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {

        $total = $row['acco_price'] * $days;
?>

<div class="card">

<div class="card-img" style="background-image: url('images/<?php echo $row['acco_image'] ?: 'placeholder.jpg'; ?>');"></div>

<div class="card-content">

<h3><?php echo $row['acco_name']; ?></h3>

<p><?php echo $row['acco_city'] . ", " . $row['acco_country']; ?></p>

<p class="price">RM <?php echo $row['acco_price']; ?> / day</p>

<p class="total">Total: RM <?php echo $total; ?></p>

<div class="compare-wrapper">
    <a href="#" class="compare-link"
       onclick="openCompare(<?php echo $row['group_id']; ?>); return false;">
        Compare Prices
    </a>
</div>

<div class="btn" onclick="toggleDetails(<?php echo $index; ?>, this)">
View More
</div>

<div class="extra" id="extra-<?php echo $index; ?>">

<p><strong>Description:</strong></p>

<p class="description-text">
<?php 
echo !empty($row['acco_description']) 
? nl2br($row['acco_description']) 
: "No description available.";
?>
</p>

<p><strong>Stay:</strong> <?php echo $days; ?> day(s)</p>


</div>

</div>
</div>

<?php
        $index++;
    }
} else {
    echo "<div class='no-result'>No accommodation found</div>";
}
?>

</div>

</div>

<script>
    function openCompare(group_id) {
        fetch("compare.php?group_id=" + group_id)
            .then(res => res.text())
            .then(data => {
                document.getElementById("compareContent").innerHTML = data;
                document.getElementById("compareModal").style.display = "flex";
            });
    }

    function closeCompare() {
        document.getElementById("compareModal").style.display = "none";
    }
</script>

<div id="compareModal" class="compare-modal">
    <div class="compare-modal-content">

        <button type="button" class="close-x" onclick="closeCompare()">✕</button>

        <h3>Price Comparison</h3>

        <div id="compareContent"></div>

    </div>
</div>

</body>
</html>