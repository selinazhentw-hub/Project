<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

header('Content-Type: application/json');
require_once 'db_connect.php';

if ($conn->connect_error) {
    echo json_encode(["success" => false, "message" => "Database connection failed: " . $conn->connect_error]);
    exit;
}

$response = ["success" => false, "message" => "Unknown error"];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = isset($_POST['action']) ? $_POST['action'] : '';
    $imageName = isset($_POST['existing_image']) ? $_POST['existing_image'] : '';

    if (isset($_FILES['image']) && $_FILES['image']['error'] === UPLOAD_ERR_OK) {
        $ext = pathinfo($_FILES['image']['name'], PATHINFO_EXTENSION);
        $imageName = uniqid() . '.' . $ext;
        $uploadPath = 'images/' . $imageName;
        
        if (!file_exists('images')) {
            mkdir('images', 0777, true);
        }
        
        move_uploaded_file($_FILES['image']['tmp_name'], $uploadPath);
    }

    $name = isset($_POST['acco_name']) ? $_POST['acco_name'] : '';
    $city = isset($_POST['acco_city']) ? $_POST['acco_city'] : '';
    $country = isset($_POST['acco_country']) ? $_POST['acco_country'] : '';
    $price = isset($_POST['acco_price']) ? floatval($_POST['acco_price']) : 0;
    $desc = isset($_POST['acco_description']) ? $_POST['acco_description'] : '';
    $userGroup = isset($_POST['group_id']) ? $_POST['group_id'] : '';
    $admin_id = 1;
    $acco_type = 'Accommodation';
    $address = $city . ', ' . $country;

    if ($action === 'add') {
        if (empty($userGroup)) {
            $group = uniqid();
        } else {
            $group = $userGroup . '_' . uniqid();
        }
        
        $stmt = $conn->prepare("INSERT INTO accommodation (acco_name, acco_city, acco_country, acco_price, acco_description, acco_image, group_id, admin_id, acco_type, acco_address) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
        $stmt->bind_param("sssdsssiss", $name, $city, $country, $price, $desc, $imageName, $group, $admin_id, $acco_type, $address);
        
        if ($stmt->execute()) {
            $response = ["success" => true];
        } else {
            $response = ["success" => false, "message" => "Execute error: " . $stmt->error];
        }
        $stmt->close();
    } else if ($action === 'update') {
        $id = isset($_POST['acco_id']) ? intval($_POST['acco_id']) : 0;
        $group = $userGroup; 
        
        $stmt = $conn->prepare("UPDATE accommodation SET acco_name=?, acco_city=?, acco_country=?, acco_price=?, acco_description=?, acco_image=?, admin_id=?, acco_type=?, acco_address=? WHERE acco_id=?");
        $stmt->bind_param("sssdssissi", $name, $city, $country, $price, $desc, $imageName, $admin_id, $acco_type, $address, $id);
        
        if ($stmt->execute()) {
            $response = ["success" => true];
        } else {
            $response = ["success" => false, "message" => "Execute error: " . $stmt->error];
        }
        $stmt->close();
    } else {
        $response = ["success" => false, "message" => "Invalid action: " . $action];
    }
} else {
    $response = ["success" => false, "message" => "POST method required"];
}

echo json_encode($response);
exit;
?>