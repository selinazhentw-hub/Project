<?php
    session_start();
    include 'db_connect.php';

    if (!isset($_SESSION["user_email"])) {
        header("Location: login.php"); 
        exit();
    }

    $email = $_SESSION["user_email"];

    $user_sql = "SELECT user_id, user_name FROM user WHERE user_email = '$email'";
    $user_result = $conn->query($user_sql);

    if ($user_result && $user_result->num_rows > 0) {
        $user_row = $user_result->fetch_assoc();
        $user_id = $user_row['user_id']; 
    } else {
        header("Location: login.php");
        exit();
    }
    $current_itinerary = $_SESSION['current_itinerary'] ?? [];
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>My Itinerary - TrippIn</title>
    <link rel="stylesheet" href="style.css">
    <style>
        body {
            background-image: url('uploads/itinerary_bg.jpg');
            background-size: cover;
        }

        #main-content { 
            padding: 40px; 
            align-items: center;
        }

        .itinerary-container {
            width: 80%;
            max-width: 900px;
            background: transparent;
            border: none;
            padding: 30px;
            margin-bottom: 40px;
        }

        .itinerary-item {
            display: flex;
            align-items: stretch;
            padding: 0;
            border: none;
            margin-bottom: 0;
        }

        .timeline-visual {
            display: flex;
            flex-direction: column;
            align-items: center;
            margin-right: 20px;
            width: 40px;
        }

        .circle {
            width: 35px;
            height: 35px;
            background-color: #ffba26;
            color: #000;
            border: 3px solid #000;
            border-radius: 50%;
            display: flex;
            justify-content: center;
            align-items: center;
            font-weight: bold;
            font-family: "Red Rose", serif;
            z-index: 2;
        }

        .line {
            flex-grow: 1;
            width: 4px;
            background-color: #000;
            margin: -5px 0; 
        }

        .itinerary-item:last-child .line {
            display: none;
        }

        .item-details {
            background: white;
            border: 3px solid #000;
            border-radius: 12px;
            padding: 20px;
            margin-bottom: 20px;
            flex-grow: 1;
            display: flex;
            gap: 20px;
            box-shadow: 5px 5px 0px rgba(0,0,0,0.1);
            font-family: "Montserrat", sans-serif;
        }

        .item-image-placeholder {
            width: 120px;
            height: 120px;
            background-color: #f0f0f0;
            border: 2px solid #ccc;
            border-radius: 8px;
            display: flex;
            justify-content: center;
            align-items: center;
            color: #888;
            font-size: 0.9rem;
            flex-shrink: 0;
        }

        .item-info {
            flex-grow: 1;
        }

        .item-title {
            font-size: 1.2rem;
            font-weight: bold;
            color: #000;
        }

        .item-location {
            color: #666;
            font-size: 0.9rem;
            margin: 4px 0;
        }

        .item-description {
            font-size: 0.9rem;
            color: #333;
            margin: 8px 0;
            line-height: 1.4;
        }

        .category-pill {
            display: inline-block;
            margin-top: 5px;
            background: #f5f5dc;
            padding: 2px 10px;
            border-radius: 5px;
            font-size: 0.8rem;
            text-transform: uppercase;
            letter-spacing: 1px;
            font-weight: bold;
        }

        .price-tag {
            font-weight: bold;
            color: #000;
            background: #ffba26;
            padding: 5px 15px;
            border-radius: 20px;
            font-size: 0.95rem;
            align-self: flex-start;
            border: 2px solid #000;
        }

        .create-btn-container {
            text-align: center;
            margin-top: 20px;
        }

        .big-gen-btn {
            background-color: #ffba26;
            color: #000;
            border: 3px solid #000;
            padding: 20px 50px;
            font-family: "Red Rose", serif;
            font-size: 22px;
            border-radius: 50px;
            cursor: pointer;
            text-decoration: none;
            display: inline-block;
            transition: transform 0.2s, box-shadow 0.2s;
        }

        .big-gen-btn:hover {
            transform: scale(1.05);
            box-shadow: 0 10px 20px rgba(0,0,0,0.1);
            background-color: #f5f5dc;
        }

        .empty-state {
            text-align: center;
            font-family: "Montserrat", sans-serif;
            color: #888;
            padding: 50px 0;
        }
    </style>
</head>
<body>

    <?php include 'sidenav.php'; ?>

    <div id="main-content">
        
        <h2>My Current Itinerary</h2>

        <div class="itinerary-container">
            <?php
            if (empty($current_itinerary)) {
                $target_user = $user_id;
                
                $query = "SELECT 
                            it.ITEMS_ID, it.ITEM_ID, it.ITEM_CATEGORY,
                            
                            act.activity_name, act.activity_country, act.activity_city, 
                            act.activity_address, act.activity_description, act.activity_price,
                            act.activity_image
                            
                        FROM ITINERARY_ITEMS it
                        JOIN ITINERARY i ON it.GROUP_ID = i.GROUP_ID
                        LEFT JOIN ACTIVITY act 
                        ON it.ITEM_ID = act.activity_id 
                        AND LOWER(it.ITEM_CATEGORY) = 'activity'

                        WHERE i.USER_ID = $target_user";
                
                $result = mysqli_query($conn, $query);
                if ($result && mysqli_num_rows($result) > 0) {
                    while ($row = mysqli_fetch_assoc($result)) {
                        $current_itinerary[] = $row;
                    }
                }
            }

            if (!empty($current_itinerary)): 
                $count = 1;
                foreach ($current_itinerary as $item): 
                    
                    $is_activity = strtolower($item['ITEM_CATEGORY']) === 'activity';
                    
                    $name        = $is_activity ? $item['activity_name']        : null;
                    $country     = $is_activity ? $item['activity_country']     : null;
                    $city        = $is_activity ? $item['activity_city']        : null;
                    $address     = $is_activity ? $item['activity_address']     : null;
                    $description = $is_activity ? $item['activity_description'] : null;
                    $price       = $is_activity ? $item['activity_price']       : 0.00;
                    $image       = $is_activity ? $item['activity_image']       : 'default.jpg';
                ?>
                    <div class="itinerary-item">
                        <div class="timeline-visual">
                            <div class="circle"><?= $count++ ?></div>
                            <div class="line"></div>
                        </div>

                        <div class="item-details">
                            <div class="item-image-placeholder">
                                <img src="images/<?= htmlspecialchars($image) ?>" 
                                    alt="Image"
                                    style="width:100%; height:100%; object-fit:cover; border-radius:8px;">
                            </div>
                            
                            <div class="item-info">
                                <div class="item-title"><?= htmlspecialchars($name ?? 'Unknown Place') ?></div>
                                <div class="item-location">
                                    📍 <?= htmlspecialchars($city) ?>, <?= htmlspecialchars($country) ?> 
                                    <br>
                                    <small><?= htmlspecialchars($address) ?></small>
                                </div>
                                <p class="item-description"><?= $description ?></p>
                                <span class="category-pill"><?= htmlspecialchars($item['ITEM_CATEGORY']) ?></span>
                            </div>

                            <div class="price-tag">
                                RM<?= number_format((float)$price, 2) ?>
                            </div>
                        </div>
                    </div>
                <?php endforeach; ?>
            <?php else: ?>
                <div class="empty-state" style="background-color: white; outline: 2px solid #ffba26; border-radius: 8px;">
                    <p style="font-size: 1rem; font-weight: bold; color: black;">You haven't generated an itinerary yet.</p>
                </div>
            <?php endif; ?>
        </div>

        <div class="create-btn-container">
            <a href="create_itinerary.php" class="big-gen-btn">
                + Create New Itinerary
            </a>
        </div>

    </div>

</body>
</html>