<?php
session_start();
include 'db_connect.php';

if (!isset($_SESSION['user_email'])) {
    header("Location: login.php");
    exit();
}

$user_email = $_SESSION['user_email'];
$user_query = "SELECT user_id FROM user WHERE user_email = '$user_email'";
$user_result = mysqli_query($conn, $user_query);
$user_row = mysqli_fetch_assoc($user_result);
$user_id = (int)$user_row['user_id'];

if (isset($_POST['activity_id'])) {
    $activity_id = (int)$_POST['activity_id'];

    $check_query = "SELECT * FROM wishlist WHERE user_id = $user_id AND activity_id = $activity_id AND is_deleted = 0";
    $check_result = mysqli_query($conn, $check_query);

    if (mysqli_num_rows($check_result) == 0) {
        $insert_query = "INSERT INTO wishlist (user_id, activity_id) VALUES ($user_id, $activity_id)";
        if (mysqli_query($conn, $insert_query)) {
            echo "<script>alert('Added to wishlist!'); window.location.href='activities.php';</script>";
        } else {
            echo "<script>alert('Database error: " . addslashes(mysqli_error($conn)) . "'); window.location.href='activities.php';</script>";
        }
    } else {
        echo "<script>alert('Already in your wishlist!'); window.location.href='activities.php';</script>";
    }
} else {
    header("Location: activities.php");
    exit();
}
?>