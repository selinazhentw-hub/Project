<?php
session_start();
require_once "db_connect.php";

if (!isset($_SESSION["admin_name"])) {
    die("Unauthorized.");
}

if (isset($_GET['id'])) {
    $feedback_id = (int)$_GET['id'];

    $photo_stmt = $conn->prepare("SELECT feedback_photo_url FROM feedback_photo WHERE feedback_id = ?");
    $photo_stmt->bind_param("i", $feedback_id);
    $photo_stmt->execute();
    $photo_res = $photo_stmt->get_result();

    while ($photo = $photo_res->fetch_assoc()) {
        $file_path = "uploads/feedback/" . $photo['feedback_photo_url'];
        if (file_exists($file_path)) {
            unlink($file_path); 
        }
    }
    $photo_stmt->close();
    $del_photos = $conn->prepare("DELETE FROM feedback_photo WHERE feedback_id = ?");
    $del_photos->bind_param("i", $feedback_id);
    $del_photos->execute();
    $del_photos->close();

    $del_feedback = $conn->prepare("DELETE FROM feedback WHERE feedback_id = ?");
    $del_feedback->bind_param("i", $feedback_id);
    
    if ($del_feedback->execute()) {
        header("Location: display_feedback.php?msg=deleted");
        exit();
    } else {
        echo "Error deleting record: " . $conn->error;
    }
}
?>