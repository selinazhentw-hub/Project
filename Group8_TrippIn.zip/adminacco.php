<?php
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin - Manage Accommodation | TrippIn</title>
    <link rel="stylesheet" href="style.css">
    <style>
        .admin-panel-container {
            margin-left: 250px;
            padding: 30px 40px;
            background-color: #f5f5dc; 
            min-height: 100vh;
            width: calc(100% - 250px); 
            box-sizing: border-box;
            font-family: 'Montserrat', sans-serif;
        }
        .admin-header {
            text-align: center;
            margin-bottom: 32px;
            border-bottom: 3px solid #ffba26;
            padding-bottom: 20px;
        }
        .admin-header h2 {
            font-family: 'Londrina Shadow', sans-serif;
            font-size: 48px;
            margin: 0 0 8px 0;
            color: #2c2c2c;
            letter-spacing: 2px;
        }
        .admin-header p {
            margin: 0;
            font-size: 1rem;
            color: #5e5e5e;
        }
        .add-new-btn {
            background-color: #ffba26;
            border: none;
            border-radius: 50px;
            padding: 12px 32px;
            font-family: 'Red Rose', serif;
            font-weight: bold;
            font-size: 1rem;
            cursor: pointer;
            transition: all 0.2s ease;
            box-shadow: 0 2px 8px rgba(0,0,0,0.1);
            display: inline-flex;
            align-items: center;
            gap: 10px;
            margin-bottom: 30px;
        }
        .add-new-btn:hover {
            background-color: #e6a500;
            transform: translateY(-2px);
        }
        .toolbar-row {
            display: flex;
            flex-wrap: wrap;
            justify-content: center;
            align-items: center;
            gap: 20px;
            margin: 20px auto 35px auto;
            background: #fff8ed;
            padding: 16px 28px;
            border-radius: 60px;
            border: 1px solid #ffdfa5;
            max-width: 800px;
        }
        .search-filter {
            display: flex;
            gap: 12px;
            flex-wrap: wrap;
            align-items: center;
            justify-content: center;
        }
        .search-filter input, .search-filter select {
            border: 1px solid #e2d5bc;
            border-radius: 50px;
            padding: 10px 20px;
            font-family: 'Montserrat', sans-serif;
            background: white;
            outline: none;
        }
        .search-filter input {
            width: 240px;
        }
        .stats-badge {
            background: #ffba2633;
            border-radius: 40px;
            padding: 8px 20px;
            font-size: 0.85rem;
            font-weight: 500;
            color: #4a3b1a;
        }
        .admin-accommodation-grid {
            display: grid;
            grid-template-columns: repeat(2, 1fr); 
            gap: 24px;
            margin-top: 20px;
            width: 100%;
        }
        .activity-admin-card {
            background: white;
            border-radius: 24px;
            border: 1px solid #f0e2cc;
            transition: all 0.25s ease;
            display: flex;
            flex-direction: row;
            align-items: center;
            justify-content: space-between;
            padding: 20px 24px;
            box-shadow: 0 2px 8px rgba(0,0,0,0.04);
        }
        .activity-admin-card:hover {
            box-shadow: 0 10px 25px rgba(0,0,0,0.1);
            border-color: #ffba2680;
            transform: translateY(-3px);
        }
        .card-img {
            width: 85px;
            height: 85px;
            background-color: #f9efdf;
            border-radius: 20px;
            object-fit: cover;
            border: 2px solid #ffba26;
        }
        .card-actions {
            display: flex;
            gap: 10px;
        }
        .edit-btn, .delete-btn {
            border: none;
            background: transparent;
            font-family: 'Red Rose', serif;
            font-size: 0.85rem;
            padding: 8px 18px;
            border-radius: 40px;
            cursor: pointer;
            transition: all 0.2s;
            font-weight: 500;
        }
        .edit-btn {
            background-color: #ffba26;
            color: #1e1e1e;
        }
        .edit-btn:hover {
            background-color: #e6a500;
        }
        .delete-btn {
            background-color: #f9e2db;
            color: #b34a3a;
        }
        .delete-btn:hover {
            background-color: #f3ccc2;
            color: #8b2c1c;
        }
        .empty-message {
            text-align: center;
            background: white;
            padding: 60px;
            border-radius: 40px;
            margin-top: 30px;
            color: #a7a08a;
            grid-column: span 2;
        }
        .admin-modal {
            display: none;
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background-color: rgba(0,0,0,0.6);
            z-index: 10000;
            justify-content: center;
            align-items: center;
            backdrop-filter: blur(2px);
        }
        .admin-modal .modal-card {
            background: #ffffff;
            border-radius: 32px;
            width: 600px;
            max-width: 92%;
            padding: 28px 30px;
            border-top: 8px solid #ffba26;
            box-shadow: 0 20px 35px rgba(0,0,0,0.2);
            font-family: 'Montserrat', sans-serif;
            max-height: 90vh;
            overflow-y: auto;
        }
        .modal-card h3 {
            font-family: 'Red Rose', serif;
            margin-top: 0;
            margin-bottom: 20px;
            font-size: 1.7rem;
        }
        .modal-card label {
            display: block;
            margin: 12px 0 5px;
            font-weight: 600;
            font-size: 0.85rem;
        }
        .modal-card input, .modal-card select, .modal-card textarea {
            width: 100%;
            padding: 10px 14px;
            border-radius: 20px;
            border: 1px solid #ddd5c4;
            font-family: 'Montserrat', sans-serif;
            background: #fefcf8;
            outline: none;
        }
        .modal-card textarea {
            resize: vertical;
            min-height: 80px;
        }
        .form-row {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 15px;
        }
        .toast-msg {
            position: fixed;
            bottom: 30px;
            right: 30px;
            background: #2c2c2c;
            color: #ffefcf;
            padding: 10px 20px;
            border-radius: 60px;
            font-size: 0.85rem;
            z-index: 10001;
        }
        @media (max-width: 900px) {
            .admin-accommodation-grid {
                grid-template-columns: 1fr;
            }
            .empty-message {
                grid-column: span 1;
            }
        }
        @media (max-width: 700px) {
            .admin-panel-container {
                margin-left: 200px;
                padding: 20px;
            }
            .activity-admin-card {
                flex-direction: column;
                align-items: flex-start;
                gap: 15px;
            }
            .card-actions {
                width: 100%;
                justify-content: flex-end;
            }
        }
    </style>
</head>
<body>
    <?php include 'adminsidenav.php'; ?>
    
    <div class="admin-panel-container">
        <div class="admin-header">
            <h2>Manage Accommodations</h2>
            <p>Add, edit or remove hotels and stays</p>
        </div>

        <div style="text-align: center;">
            <button class="add-new-btn" onclick="openAddModal()">+ New Accommodation</button>
        </div>

        <div class="toolbar-row">
            <div class="search-filter">
                <input type="text" id="searchAccoInput" placeholder="🔍 Search by name or city...">
                <select id="countryFilterSelect">
                    <option value="">All Countries</option>
                </select>
            </div>
            <div id="accoCountBadge" class="stats-badge">0 accommodations</div>
        </div>

        <div id="accoListContainer" class="admin-accommodation-grid">
            <div class="empty-message">Loading accommodations...</div>
        </div>
    </div>

    <!-- Modal Form -->
    <div id="accoModal" class="admin-modal">
        <div class="modal-card">
            <h3 id="modalTitle">Add Accommodation</h3>
            <form id="accoForm" onsubmit="return false;">
                <input type="hidden" id="editAccoId">
                <input type="hidden" id="existingImage">
                
                <label>Accommodation Name *</label>
                <input type="text" id="accoName" required>
                
                <div class="form-row">
                    <div>
                        <label>City *</label>
                        <input type="text" id="accoCity" required>
                    </div>
                    <div>
                        <label>Country *</label>
                        <input type="text" id="accoCountry" required>
                    </div>
                </div>

                <div class="form-row">
                    <div>
                        <label>Price per Day *</label>
                        <input type="number" id="accoPrice" required>
                    </div>
                    <div>
                        <label>Group ID (Comparison)</label>
                        <input type="number" id="groupId">
                    </div>
                </div>

                <label>Description</label>
                <textarea id="accoDesc"></textarea>

                <label>Image</label>
                <input type="file" id="accoImage" accept="image/*">
                <div id="imagePreviewArea" style="margin-top:10px;"></div>

                <div style="display:flex; justify-content:flex-end; gap:14px; margin-top:20px;">
                    <button type="button" onclick="closeModal()" style="background:#eae0d0; padding:10px 20px; border-radius:50px; border:none; cursor:pointer;">Cancel</button>
                    <button type="button" onclick="saveAccommodation()" style="background:#ffba26; padding:10px 20px; border-radius:50px; border:none; font-weight:bold; cursor:pointer;">Save Changes</button>
                </div>
            </form>
        </div>
    </div>

    <script>
        let accoData = [];
        let currentSearchTerm = '';
        let currentCountryFilter = '';

        async function loadAcco() {
            try {
                const res = await fetch('api_get_acco.php');
                const result = await res.json();
                if (result.success) {
                    accoData = result.data;
                    populateCountryFilter();
                    renderList();
                } else {
                    console.error('Failed to load data');
                }
            } catch (error) {
                console.error('Error loading data:', error);
                document.getElementById('accoListContainer').innerHTML = '<div class="empty-message">Error loading data. Please check console.</div>';
            }
        }

        function populateCountryFilter() {
            const countrySelect = document.getElementById('countryFilterSelect');
            if (!countrySelect) return;
            
            const countries = [...new Set(accoData.map(a => a.acco_country).filter(c => c && c.trim() !== ''))];
            countrySelect.innerHTML = '<option value="">All Countries</option>' + 
                countries.map(c => `<option value="${escapeHtml(c)}">${escapeHtml(c)}</option>`).join('');
        }

        function renderList() {
            const container = document.getElementById('accoListContainer');
            if (!container) return;
            
            let filtered = [...accoData];
            if (currentSearchTerm.trim() !== '') {
                const term = currentSearchTerm.toLowerCase();
                filtered = filtered.filter(a => 
                    a.acco_name.toLowerCase().includes(term) ||
                    a.acco_city.toLowerCase().includes(term)
                );
            }
            
            if (currentCountryFilter !== '') {
                filtered = filtered.filter(a => a.acco_country === currentCountryFilter);
            }
            
            const badge = document.getElementById('accoCountBadge');
            if (badge) badge.innerText = `${filtered.length} accommodations`;
            
            if (filtered.length === 0) {
                container.innerHTML = `<div class="empty-message">✨ No accommodations found. Click "New Accommodation" to add one.</div>`;
                return;
            }
            
            let html = '';
            filtered.forEach(a => {
                let imgSrc = a.acco_image ? `images/${a.acco_image}` : 'images/placeholder.jpg';
                if (!a.acco_image) imgSrc = 'https://cdn-icons-png.flaticon.com/512/1995/1995572.png';
                
                html += `
                    <div class="activity-admin-card">
                        <div style="display:flex; gap:18px; align-items:center;">
                            <img class="card-img" src="${imgSrc}" onerror="this.src='https://cdn-icons-png.flaticon.com/512/1995/1995572.png'">
                            <div>
                                <h4 style="margin:0; font-family:'Red Rose';">${escapeHtml(a.acco_name)}</h4>
                                <p style="margin:5px 0; font-size:0.8rem; color:#7c6e51;">📍 ${escapeHtml(a.acco_city)}, ${escapeHtml(a.acco_country)}</p>
                                <span style="background:#fff0db; padding:4px 14px; border-radius:30px; font-size:0.8rem;">💰 RM ${a.acco_price}</span>
                            </div>
                        </div>
                        <div class="card-actions">
                            <button class="edit-btn" onclick="openEditModal(${a.acco_id})">✏️ Edit</button>
                            <button class="delete-btn" onclick="deleteAcco(${a.acco_id})">🗑️ Delete</button>
                        </div>
                    </div>
                `;
            });
            container.innerHTML = html;
        }

        function openAddModal() {
            document.getElementById('accoForm').reset();
            document.getElementById('editAccoId').value = '';
            document.getElementById('existingImage').value = '';
            document.getElementById('modalTitle').innerText = "Add New Accommodation";
            document.getElementById('imagePreviewArea').innerHTML = '';
            document.getElementById('accoModal').style.display = 'flex';
        }

        function openEditModal(id) {
            const a = accoData.find(item => item.acco_id == id);
            if (!a) return;
            document.getElementById('editAccoId').value = a.acco_id;
            document.getElementById('accoName').value = a.acco_name;
            document.getElementById('accoCity').value = a.acco_city;
            document.getElementById('accoCountry').value = a.acco_country;
            document.getElementById('accoPrice').value = a.acco_price;
            document.getElementById('groupId').value = a.group_id;
            document.getElementById('accoDesc').value = a.acco_description;
            document.getElementById('existingImage').value = a.acco_image;
            document.getElementById('modalTitle').innerText = "Edit Accommodation";
            document.getElementById('imagePreviewArea').innerHTML = a.acco_image ? `<div class="current-image"><img src="images/${a.acco_image}"><span>Current: ${a.acco_image}</span></div>` : '';
            document.getElementById('accoModal').style.display = 'flex';
        }

        async function saveAccommodation() {
            const editId = document.getElementById('editAccoId').value;
            const formData = new FormData();
            formData.append('action', editId ? 'update' : 'add');
            if (editId) formData.append('acco_id', editId);
            formData.append('acco_name', document.getElementById('accoName').value);
            formData.append('acco_city', document.getElementById('accoCity').value);
            formData.append('acco_country', document.getElementById('accoCountry').value);
            formData.append('acco_price', document.getElementById('accoPrice').value);
            formData.append('acco_description', document.getElementById('accoDesc').value);
            formData.append('group_id', document.getElementById('groupId').value);
            formData.append('existing_image', document.getElementById('existingImage').value);
            
            const imageFile = document.getElementById('accoImage').files[0];
            if (imageFile) formData.append('image', imageFile);

            try {
                const res = await fetch('api_save_acco.php', {
                    method: 'POST',
                    body: formData
                });
                const result = await res.json();
                if (result.success) {
                    closeModal();
                    loadAcco();
                    showToast(editId ? "Updated successfully!" : "Added successfully!");
                } else {
                    showToast("Error: " + (result.message || "Unknown error"));
                }
            } catch (error) {
                console.error('Error:', error);
                showToast("Request failed: " + error.message);
            }
        }

        async function deleteAcco(id) {
            if (confirm("Are you sure you want to delete this accommodation?")) {
                try {
                    const res = await fetch('api_delete_acco.php', {
                        method: 'POST',
                        headers: {'Content-Type': 'application/json'},
                        body: JSON.stringify({acco_id: id})
                    });
                    const result = await res.json();
                    if (result.success) {
                        loadAcco();
                        showToast("Deleted successfully.");
                    } else {
                        showToast("Delete failed.");
                    }
                } catch (error) {
                    console.error('Error:', error);
                    showToast("Delete request failed.");
                }
            }
        }

        function closeModal() { 
            document.getElementById('accoModal').style.display = 'none'; 
        }

        function showToast(msg) { 
            const t = document.createElement('div'); 
            t.className = 'toast-msg'; 
            t.innerText = msg; 
            document.body.appendChild(t); 
            setTimeout(() => t.remove(), 3000); 
        }

        function escapeHtml(str) { 
            if (!str) return '';
            return String(str).replace(/[&<>]/g, m => ({'&':'&amp;','<':'&lt;','>':'&gt;'})[m]); 
        }

        document.getElementById('searchAccoInput').addEventListener('input', (e) => {
            currentSearchTerm = e.target.value;
            renderList();
        });
        
        document.getElementById('countryFilterSelect').addEventListener('change', (e) => {
            currentCountryFilter = e.target.value;
            renderList();
        });
        
        document.getElementById('accoImage').addEventListener('change', function(e) {
            const previewArea = document.getElementById('imagePreviewArea');
            if (this.files && this.files[0]) {
                const reader = new FileReader();
                reader.onload = function(ev) {
                    previewArea.innerHTML = `<img src="${ev.target.result}" style="max-width:150px; max-height:100px; border-radius:12px; border:2px solid #ffba26;">`;
                };
                reader.readAsDataURL(this.files[0]);
            }
        });
        
        window.onload = loadAcco;
    </script>
</body>
</html>