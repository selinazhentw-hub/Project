<?php
session_start();
require_once "db_connect.php";

if (isset($_GET['id'])) {
    $feedback_id = (int)$_GET['id'];

    if (!isset($_SESSION['user_email'])) {
        die("Error: You must be logged in to delete feedback.");
    }

    $email = $_SESSION['user_email'];

    $stmt = $conn->prepare("SELECT f.feedback_id FROM feedback f JOIN user u ON f.user_id = u.user_id WHERE f.feedback_id = ? AND u.user_email = ?");
    $stmt->bind_param("is", $feedback_id, $email);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        $stmt->close();

        $photo_query = $conn->prepare("SELECT feedback_photo_url FROM feedback_photo WHERE feedback_id = ?");
        $photo_query->bind_param("i", $feedback_id);
        $photo_query->execute();
        $photos = $photo_query->get_result();
        
        while ($p = $photos->fetch_assoc()) {
            $file_path = "uploads/feedback/" . $p['feedback_photo_url'];
            if (file_exists($file_path)) {
                unlink($file_path);
            }
        }
        $photo_query->close();

        $del_photos = $conn->prepare("DELETE FROM feedback_photo WHERE feedback_id = ?");
        $del_photos->bind_param("i", $feedback_id);
        $del_photos->execute();
        $del_photos->close();

        $delete_stmt = $conn->prepare("DELETE FROM feedback WHERE feedback_id = ?");
        $delete_stmt->bind_param("i", $feedback_id);
        $delete_stmt->execute();
        $delete_stmt->close();
        
        header("Location: view_feedback.php?msg=deleted");
        exit();
    } else {
        echo "Unauthorized action.";
    }
}
?>